import { request, requestStream } from "tur:net";
import { decodeUtf8, encodeUtf8 } from "tur:std";
import { hostRpc, viewRpc } from "tur:rpc";
import { context as external_ease_context, db, secret } from "ease";
// The require scope
var __webpack_require__ = {};

// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ backend_start)
});

;// CONCATENATED MODULE: external "tur:net"

;// CONCATENATED MODULE: ../infra/string-polyfill.ts
// ECMAScript Annex-B / legacy builtin polyfill for the tur (boa) runtime.
//
// boa skips deprecated Annex-B extras that real-world npm packages still
// call. Import this module FIRST from every bundle entry (side-effect
// import), before any dependency that might rely on these.
//
// Found the hard way: fast-xml-parser's `readTagExp` calls
// `String.prototype.substr` on every namespace-prefixed tag — with
// `removeNSPrefix: true` that is EVERY tag of a WebDAV multistatus body —
// and the resulting TypeError (swallowed by a `catch { return [] }` at the
// time) turned every WebDAV `storage:list` into a silent empty directory
// on device.
// --- String.prototype.substr (Annex B; absent in boa) ----------------------
//
// Spec semantics: NaN start → 0; negative start counts from the end;
// start >= length → ""; omitted length → to the end; NaN / negative / zero
// length → "". Installed via defineProperty so the lib's (deprecated) TS
// declaration is untouched.
if (typeof String.prototype.substr !== "function") {
    Object.defineProperty(String.prototype, "substr", {
        value: function substr(start, length) {
            const s = String(this);
            const size = s.length;
            let begin = Number(start);
            if (Number.isNaN(begin)) begin = 0;
            if (begin < 0) begin = Math.max(size + begin, 0);
            if (begin >= size) return "";
            let end = size;
            if (length !== undefined) {
                const len = Number(length);
                if (Number.isNaN(len) || len <= 0) return "";
                end = Math.min(begin + len, size);
            }
            return s.substring(begin, end);
        },
        writable: true,
        configurable: true,
        enumerable: false
    });
}


;// CONCATENATED MODULE: external "tur:std"

;// CONCATENATED MODULE: ../infra/text-polyfill.ts
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// TextEncoder / TextDecoder polyfill for the tur (boa) runtime.
//
// boa implements ECMAScript but not the Web Platform text codecs. `tur:std`
// already ships the UTF-8 primitives (`encodeUtf8` / `decodeUtf8`), so these
// classes are thin WHATWG-shaped wrappers over them instead of another
// hand-rolled encoder. Import this module FIRST from every bundle entry
// (side-effect import) — npm dependencies bundled after it see the globals.
//
// Semantics notes:
// - `encode`: WHATWG replaces lone surrogates with U+FFFD; boa's
//   `encodeUtf8` renders them as literal `\uD800` text, so the input is
//   normalized with `String.prototype.toWellFormed()` (ES2024, implemented
//   by boa) first.
// - `encodeInto`: never splits a code point's multi-byte sequence — the cut
//   is walked back to a UTF-8 lead-byte boundary.
// - `decode`: `decodeUtf8` is strict (throws on invalid bytes), which maps
//   1:1 to the `fatal: true` option; the default non-fatal mode replaces
//   each invalid byte with U+FFFD by greedily re-decoding the longest valid
//   prefix (binary search).
// - `decode(bytes, { stream: true })` decodes each chunk independently (no
//   cross-call decoder state) — the same trade-off the common
//   `fast-text-encoding` polyfill makes.
// - UTF-8 labels only; any other label throws `RangeError`.

const UTF8_LABELS = [
    "utf-8",
    "utf8",
    "unicode-1-1-utf-8",
    "unicode11utf8",
    "unicode20utf8",
    "x-unicode20utf8"
];
/** View of a BufferSource as bytes, honoring byteOffset / byteLength. */ function toBytes(input) {
    if (input instanceof ArrayBuffer) return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
}
/** `String.prototype.toWellFormed()` (ES2024) — implemented by boa, but not
 *  declared in the ES2020 lib the plugins typecheck against, hence the
 *  local cast instead of a program-wide lib bump. */ function wellFormed(s) {
    return s.toWellFormed();
}
/** Non-fatal decode: U+FFFD per invalid byte, via longest-valid-prefix
 *  binary search over `decodeUtf8` (which is strict). */ function decodeLossy(bytes) {
    try {
        return decodeUtf8(bytes);
    } catch  {
        let out = "";
        let start = 0;
        while(start < bytes.length){
            let lo = 0;
            let hi = bytes.length - start;
            while(lo < hi){
                const mid = lo + hi + 1 >> 1;
                let ok = true;
                try {
                    decodeUtf8(bytes.subarray(start, start + mid));
                } catch  {
                    ok = false;
                }
                if (ok) lo = mid;
                else hi = mid - 1;
            }
            if (lo > 0) {
                out += decodeUtf8(bytes.subarray(start, start + lo));
                start += lo;
            } else {
                out += "\uFFFD";
                start += 1;
            }
        }
        return out;
    }
}
if (typeof globalThis.TextEncoder === "undefined") {
    class TextEncoder {
        get encoding() {
            return "utf-8";
        }
        encode(input) {
            const s = input == null ? "" : String(input);
            return encodeUtf8(wellFormed(s));
        }
        encodeInto(source, destination) {
            if (!(destination instanceof Uint8Array)) {
                throw new TypeError("encodeInto: destination must be a Uint8Array");
            }
            const bytes = encodeUtf8(wellFormed(String(source ?? "")));
            // Cut at a lead-byte boundary so no code point splits; a
            // continuation byte matches 10xxxxxx (0xC0 mask).
            let n = Math.min(bytes.length, destination.length);
            while(n > 0 && n < bytes.length && (bytes[n] & 0xc0) === 0x80)n--;
            destination.set(bytes.subarray(0, n));
            return {
                read: n === 0 ? 0 : decodeUtf8(bytes.subarray(0, n)).length,
                written: n
            };
        }
    }
    globalThis.TextEncoder = TextEncoder;
}
if (typeof globalThis.TextDecoder === "undefined") {
    class TextDecoder {
        get encoding() {
            return "utf-8";
        }
        decode(input, _options) {
            if (input == null) return "";
            let bytes = toBytes(input);
            if (!this.ignoreBOM && bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
                bytes = bytes.subarray(3);
            }
            return this.fatal ? decodeUtf8(bytes) : decodeLossy(bytes);
        }
        constructor(label, options){
            _define_property(this, "fatal", void 0);
            _define_property(this, "ignoreBOM", void 0);
            const norm = String(label ?? "utf-8").trim().toLowerCase();
            if (!UTF8_LABELS.includes(norm)) {
                throw new RangeError(`TextDecoder: unsupported encoding label '${label}' (UTF-8 only)`);
            }
            this.fatal = !!options?.fatal;
            this.ignoreBOM = !!options?.ignoreBOM;
        }
    }
    globalThis.TextDecoder = TextDecoder;
}

;// CONCATENATED MODULE: external "tur:rpc"

;// CONCATENATED MODULE: ../infra/host-ops.ts
// Host contract op sigs — the typed catalog of ops the Rust host invokes on
// plugin backends (`hostRpc.registerHandler` / `hostRpc.registerStream`).
// Each sig binds the wire op string to its args and result shapes, so
// providers register without hand-declaring arg types; extract a shape
// elsewhere via `EaseRpcOpArg<typeof StorageListSig>` /
// `EaseRpcOpResult<typeof StorageListSig>`.
//
// SOURCE OF TRUTH: the shapes mirror the Rust call sites —
// - storage contract: `rust-libs/ease-js-storage/src/lib.rs` (args, entry
//   decode, stream meta decode),
// - OAuth flow: `rust-libs/ease-client-backend/src/bridge/dispatch.rs`
//   (`oauth.url` / `oauth.exchange` arms),
// - lyric parsing: `rust-libs/ease-client-backend/src/services/lyrics/mod.rs`
// — update both sides together. Ops are contract literals, identical names
// for every provider; identity (`pluginId`, `storageId`, `oauthId`) rides
// the payload, typed `string` (the host routes it — a provider-side literal
// guard would only restate the manifest id).
//
// This module is plain bundled TS (imported relatively by plugins, like the
// polyfills): the runtime value of a sig is just `{ op }`, so no host
// provisioning is involved.
// ---------------------------------------------------------------------------
// Host op sigs
// ---------------------------------------------------------------------------
/** `storage:list` — directory listing. */ const StorageListSig = {
    op: "storage:list"
};
/** `storage:get` — streaming byte-range download; the Result slot is the
 *  stream meta shape (see `registerStream`). */ const StorageGetSig = {
    op: "storage:get"
};
/** `storage:removeInstance` — drop this instance's config + secrets; the
 *  host ignores the reply. */ const StorageRemoveInstanceSig = {
    op: "storage:removeInstance"
};
/** `oauth:url` — the authorize URL for the host to open in the browser. */ const OauthUrlSig = (/* unused pure expression or super */ null && ({
    op: "oauth:url"
}));
/** `oauth:exchange` — redeem the browser callback's code; the host reads the
 *  minted `storageId` back to (re)bind the storage row. */ const OauthExchangeSig = (/* unused pure expression or super */ null && ({
    op: "oauth:exchange"
}));
/** `lyric:parse` — parse candidate lyric bytes; `null` means "not mine /
 *  unrecognized content" and the host falls through to the next parser. */ const LyricParseSig = (/* unused pure expression or super */ null && ({
    op: "lyric:parse"
}));

;// CONCATENATED MODULE: ./src/rpc.ts
// Plugin-private RPC sigs — the single source of this plugin's view↔backend
// op contracts (mirrors the WebDAV plugin's `rpc.ts`). Both `backend.ts`
// (viewRpc registrations) and `view.ts` (`ease.rpc.call`) import from here,
// so the args/result shapes are declared exactly once.
const S3TestSig = {
    op: "s3:test"
};
const S3ConnectSig = {
    op: "s3:connect"
};

;// CONCATENATED MODULE: external "ease"

;// CONCATENATED MODULE: ./node_modules/.pnpm/uuid@14.0.2/node_modules/uuid/dist/rng.js
const rnds8 = new Uint8Array(16);
function rng() {
    return crypto.getRandomValues(rnds8);
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/uuid@14.0.2/node_modules/uuid/dist/stringify.js

const byteToHex = [];
for (let i = 0; i < 256; ++i) {
    byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] +
        byteToHex[arr[offset + 1]] +
        byteToHex[arr[offset + 2]] +
        byteToHex[arr[offset + 3]] +
        '-' +
        byteToHex[arr[offset + 4]] +
        byteToHex[arr[offset + 5]] +
        '-' +
        byteToHex[arr[offset + 6]] +
        byteToHex[arr[offset + 7]] +
        '-' +
        byteToHex[arr[offset + 8]] +
        byteToHex[arr[offset + 9]] +
        '-' +
        byteToHex[arr[offset + 10]] +
        byteToHex[arr[offset + 11]] +
        byteToHex[arr[offset + 12]] +
        byteToHex[arr[offset + 13]] +
        byteToHex[arr[offset + 14]] +
        byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset);
    if (!validate(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
/* export default */ const dist_stringify = ((/* unused pure expression or super */ null && (stringify)));

;// CONCATENATED MODULE: ./node_modules/.pnpm/uuid@14.0.2/node_modules/uuid/dist/v4.js


function v4(options, buf, offset) {
    if (!buf && !options && crypto.randomUUID) {
        return crypto.randomUUID();
    }
    return _v4(options, buf, offset);
}
function _v4(options, buf, offset) {
    options = options || {};
    const rnds = options.random ?? options.rng?.() ?? rng();
    if (rnds.length < 16) {
        throw new Error('Random bytes length must be >= 16');
    }
    rnds[6] = (rnds[6] & 0x0f) | 0x40;
    rnds[8] = (rnds[8] & 0x3f) | 0x80;
    if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
            throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return unsafeStringify(rnds);
}
/* export default */ const dist_v4 = (v4);

;// CONCATENATED MODULE: ./node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/_u64.js
const U32_MASK64 = /* @__PURE__ */ (() => BigInt(2 ** 32 - 1))();
const _32n = /* @__PURE__ */ BigInt(32);
// Split bigint into two 32-bit halves. With `le=true`, returned fields become `{ h: low, l: high
// }` to match little-endian word order rather than the property names.
function fromBig(n, le = false) {
    if (le)
        return { h: Number(n & U32_MASK64), l: Number((n >> _32n) & U32_MASK64) };
    return { h: Number((n >> _32n) & U32_MASK64) | 0, l: Number(n & U32_MASK64) | 0 };
}
// Split bigint list into `[highWords, lowWords]` when `le=false`; with `le=true`, the first array
// holds the low halves because `fromBig(...)` swaps the semantic meaning of `h` and `l`.
function split(lst, le = false) {
    const len = lst.length;
    let Ah = new Uint32Array(len);
    let Al = new Uint32Array(len);
    for (let i = 0; i < len; i++) {
        const { h, l } = fromBig(lst[i], le);
        [Ah[i], Al[i]] = [h, l];
    }
    return [Ah, Al];
}
// Combine explicit `(high, low)` 32-bit halves into a bigint; `>>> 0` normalizes signed JS
// bitwise results back to uint32 first, and little-endian callers must swap.
const toBig = (h, l) => (BigInt(h >>> 0) << _32n) | BigInt(l >>> 0);
// Split a JS number into u32 halves without a BigInt allocation. Exact only for integers
// `0 <= n < 2**53`; callers use it on byte / bit counters, which JS length math caps far below
// that (an ArrayBuffer cannot exceed 2**53 - 1 bytes).
const fromNumH = (n) => (n / 2 ** 32) | 0;
const fromNumL = (n) => n >>> 0;
// Drop-in replacement for `view.setBigUint64(byteOffset, BigInt(n), isLE)` without the per-call
// BigInt allocation. Same `n < 2**53` precondition as `fromNumH`/`fromNumL`.
function setU64FromNum(view, byteOffset, n, isLE) {
    const h = fromNumH(n);
    const l = fromNumL(n);
    view.setUint32(byteOffset, isLE ? l : h, isLE);
    view.setUint32(byteOffset + 4, isLE ? h : l, isLE);
}
// High 32-bit half of a 64-bit logical right shift for `s` in `0..31`.
const shrSH = (h, _l, s) => h >>> s;
// Low 32-bit half of a 64-bit logical right shift, valid for `s` in `1..31`.
const shrSL = (h, l, s) => (h << (32 - s)) | (l >>> s);
// High 32-bit half of a 64-bit right rotate, valid for `s` in `1..31`.
const rotrSH = (h, l, s) => (h >>> s) | (l << (32 - s));
// Low 32-bit half of a 64-bit right rotate, valid for `s` in `1..31`.
const rotrSL = (h, l, s) => (h << (32 - s)) | (l >>> s);
// High 32-bit half of a 64-bit right rotate, valid for `s` in `33..63`; `32` uses `rotr32*`.
const rotrBH = (h, l, s) => (h << (64 - s)) | (l >>> (s - 32));
// Low 32-bit half of a 64-bit right rotate, valid for `s` in `33..63`; `32` uses `rotr32*`.
const rotrBL = (h, l, s) => (h >>> (s - 32)) | (l << (64 - s));
// High 32-bit half of a 64-bit right rotate for `s === 32`; this is just the swapped low half.
const rotr32H = (_h, l) => l;
// Low 32-bit half of a 64-bit right rotate for `s === 32`; this is just the swapped high half.
const rotr32L = (h, _l) => h;
// 64-bit left rotates (rotl*) are not defined here: sha3.ts, their only consumer, keeps
// local copies so V8 inlines them into keccakP.
// Add two split 64-bit words and return the split `{ h, l }` sum.
// JS uses 32-bit signed integers for bitwise operations, so we cannot simply shift the carry out
// of the low sum and instead use division.
function add(Ah, Al, Bh, Bl) {
    const l = (Al >>> 0) + (Bl >>> 0);
    return { h: (Ah + Bh + ((l / 2 ** 32) | 0)) | 0, l: l | 0 };
}
// Addition with more than 2 elements
// Unmasked low-word accumulator for 3-way addition; pass the raw result into `add3H(...)`.
const add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
// High-word finalize step for 3-way addition; `low` must be the untruncated output of `add3L(...)`.
const add3H = (low, Ah, Bh, Ch) => (Ah + Bh + Ch + ((low / 2 ** 32) | 0)) | 0;
// Unmasked low-word accumulator for 4-way addition; pass the raw result into `add4H(...)`.
const add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
// High-word finalize step for 4-way addition; `low` must be the untruncated output of `add4L(...)`.
const add4H = (low, Ah, Bh, Ch, Dh) => (Ah + Bh + Ch + Dh + ((low / 2 ** 32) | 0)) | 0;
// Unmasked low-word accumulator for 5-way addition; pass the raw result into `add5H(...)`.
const add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
// High-word finalize step for 5-way addition; `low` must be the untruncated output of `add5L(...)`.
const add5H = (low, Ah, Bh, Ch, Dh, Eh) => (Ah + Bh + Ch + Dh + Eh + ((low / 2 ** 32) | 0)) | 0;
// prettier-ignore


;// CONCATENATED MODULE: ./node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/utils.js
/**
 * Checks if something is Uint8Array. Be careful: nodejs Buffer will return true.
 * @param a - value to test
 * @returns `true` when the value is a Uint8Array-compatible view.
 * @example
 * Check whether a value is a Uint8Array-compatible view.
 * ```ts
 * isBytes(new Uint8Array([1, 2, 3]));
 * ```
 */
function isBytes(a) {
    // Plain `instanceof Uint8Array` is too strict for some Buffer / proxy / cross-realm cases.
    // The fallback still requires a real ArrayBuffer view, so plain
    // JSON-deserialized `{ constructor: ... }` spoofing is rejected, and
    // `BYTES_PER_ELEMENT === 1` keeps the fallback on byte-oriented views.
    return (a instanceof Uint8Array ||
        (ArrayBuffer.isView(a) &&
            a.constructor.name === 'Uint8Array' &&
            'BYTES_PER_ELEMENT' in a &&
            a.BYTES_PER_ELEMENT === 1));
}
// Shared error-message prefix builder. Only called on throw paths, so assert
// success paths never pay for the string concatenation.
const atitle = (title) => (title ? `"${title}" ` : '');
/**
 * Asserts something is a non-negative integer.
 * @param n - number to validate
 * @param title - label included in thrown errors
 * @returns The validated number.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * Validate a non-negative integer option.
 * ```ts
 * anumber(32, 'length');
 * ```
 */
function anumber(n, title = '') {
    if (typeof n !== 'number')
        throw new TypeError(atitle(title) + 'expected number, got ' + typeof n);
    if (!Number.isSafeInteger(n) || n < 0)
        throw new RangeError(atitle(title) + 'expected integer >= 0, got ' + n);
    return n;
}
/**
 * Asserts something is a boolean.
 * @param value - value to validate
 * @param title - label included in thrown errors
 * @returns The validated boolean.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Validate a boolean option.
 * ```ts
 * abool(true, 'enableXOF');
 * ```
 */
function abool(value, title = '') {
    if (typeof value !== 'boolean')
        throw new TypeError(atitle(title) + 'expected boolean, got type=' + typeof value);
    return value;
}
/**
 * Asserts something is Uint8Array.
 * @param value - value to validate
 * @param length - optional exact length constraint
 * @param title - label included in thrown errors
 * @returns The validated byte array.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * Validate that a value is a byte array.
 * ```ts
 * abytes(new Uint8Array([1, 2, 3]));
 * ```
 */
function abytes(value, length, title = '') {
    // Success path first: this runs at the start of every update() / digestInto(), and the
    // common `abytes(data)` form must not pay for length handling it does not use.
    if (isBytes(value) && (length === undefined || value.length === length))
        return value;
    // Error path: recompute freely to build the exact message.
    if (length !== undefined)
        anumber(length, 'length');
    const bytes = isBytes(value);
    const ofLen = length !== undefined ? ` of length ${length}` : '';
    const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
    const message = atitle(title) + 'expected Uint8Array' + ofLen + ', got ' + got;
    if (!bytes)
        throw new TypeError(message);
    throw new RangeError(message);
}
/**
 * Copies bytes into a fresh Uint8Array.
 * Buffer-style slices can alias the same backing store, so callers that need ownership should copy.
 * @param bytes - source bytes to clone
 * @returns Freshly allocated copy of `bytes`.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Clone a byte array before mutating it.
 * ```ts
 * const copy = copyBytes(new Uint8Array([1, 2, 3]));
 * ```
 */
function copyBytes(bytes) {
    // `Uint8Array.from(...)` would also accept arrays / other typed arrays. Keep this helper strict
    // because callers use it at byte-validation boundaries before mutating the detached copy.
    return Uint8Array.from(abytes(bytes));
}
/**
 * Asserts something is a wrapped hash constructor.
 * @param h - hash constructor to validate
 * @throws On wrong argument types or invalid hash wrapper shape. {@link TypeError}
 * @throws On invalid hash metadata ranges or values. {@link RangeError}
 * @throws If the hash metadata allows empty outputs or block sizes. {@link Error}
 * @example
 * Validate a callable hash wrapper.
 * ```ts
 * import { ahash } from '@noble/hashes/utils.js';
 * import { sha256 } from '@noble/hashes/sha2.js';
 * ahash(sha256);
 * ```
 */
function ahash(h) {
    if (typeof h !== 'function' || typeof h.create !== 'function')
        throw new TypeError('expected hash wrapped by utils.createHasher');
    anumber(h.outputLen);
    anumber(h.blockLen);
    // HMAC and KDF callers treat these as real byte lengths; allowing zero lets fake wrappers pass
    // validation and can produce empty outputs instead of failing fast.
    if (h.outputLen < 1 || h.blockLen < 1)
        throw new Error('hash blockLen / outputLen must be >= 1');
}
const aobject = (value, label) => {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        throw new TypeError((label === 'object' ? '' : `"${label}" `) + 'expected object, got type=' + typeof value);
};
const aopts = (value, label) => {
    aobject(value, label);
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null)
        throw new TypeError(`"${label}" expected plain object`);
    // Object.assign() treats an own "__proto__" source key as a write to the target's legacy
    // prototype setter. Reject it before merging so inherited option values cannot be injected.
    if (Object.hasOwn(value, '__proto__'))
        throw new TypeError(`"${label}.__proto__" is not allowed`);
};
/**
 * Asserts a hash instance has not been destroyed or finished.
 * @param instance - hash instance to validate
 * @param checkFinished - whether to reject finalized instances
 * @throws If the hash instance has already been destroyed or finalized. {@link Error}
 * @example
 * Validate that a hash instance is still usable.
 * ```ts
 * import { aexists } from '@noble/hashes/utils.js';
 * import { sha256 } from '@noble/hashes/sha2.js';
 * const hash = sha256.create();
 * aexists(hash);
 * ```
 */
function aexists(instance, checkFinished = true) {
    // Runs on every update()/digestInto(); the flags are library-owned booleans, so only their
    // truthiness is checked - re-validating their type per call was pure hot-path overhead.
    if (instance.destroyed)
        throw new Error('hash was destroyed');
    if (checkFinished && instance.finished)
        throw new Error('digest() was already called');
}
/**
 * Asserts output is a sufficiently-sized byte array.
 * @param out - destination buffer
 * @param instance - hash instance providing output length
 * Oversized buffers are allowed; downstream code only promises to fill the first `outputLen` bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * Validate a caller-provided digest buffer.
 * ```ts
 * import { aoutput } from '@noble/hashes/utils.js';
 * import { sha256 } from '@noble/hashes/sha2.js';
 * const hash = sha256.create();
 * aoutput(new Uint8Array(hash.outputLen), hash);
 * ```
 */
function aoutput(out, instance) {
    abytes(out, undefined, 'output');
    // `outputLen` is a library-owned readonly number; the negated comparison keeps failing fast
    // when it is missing/NaN (comparisons with undefined/NaN are false) without an anumber() call.
    const min = instance.outputLen;
    if (!(out.length >= min)) {
        throw new RangeError('"output" expected length >= ' + min);
    }
}
/**
 * Casts a typed array view to Uint8Array.
 * @param arr - source typed array
 * @returns Uint8Array view over the same buffer.
 * @example
 * Reinterpret a typed array as bytes.
 * ```ts
 * u8(new Uint32Array([1, 2]));
 * ```
 */
function u8(arr) {
    return new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
}
/**
 * Casts a typed array view to Uint32Array.
 * `arr.byteOffset` must already be 4-byte aligned or the platform
 * Uint32Array constructor will throw.
 * @param arr - source typed array
 * @returns Uint32Array view over the same buffer.
 * @example
 * Reinterpret a byte array as 32-bit words.
 * ```ts
 * u32(new Uint8Array(8));
 * ```
 */
function u32(arr) {
    return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
/**
 * Zeroizes typed arrays in place. Warning: JS provides no guarantees.
 * @param arrays - arrays to overwrite with zeros
 * @example
 * Zeroize sensitive buffers in place.
 * ```ts
 * clean(new Uint8Array([1, 2, 3]));
 * ```
 */
function clean(...arrays) {
    for (let i = 0; i < arrays.length; i++) {
        arrays[i].fill(0);
    }
}
/**
 * Creates a DataView for byte-level manipulation.
 * @param arr - source typed array
 * @returns DataView over the same buffer region.
 * @example
 * Create a DataView over an existing buffer.
 * ```ts
 * createView(new Uint8Array(4));
 * ```
 */
function createView(arr) {
    return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
/**
 * Rotate-right operation for uint32 values.
 * @param word - source word
 * @param shift - shift amount in bits
 * @returns Rotated word.
 * @example
 * Rotate a 32-bit word to the right.
 * ```ts
 * rotr(0x12345678, 8);
 * ```
 */
function rotr(word, shift) {
    return (word << (32 - shift)) | (word >>> shift);
}
/**
 * Rotate-left operation for uint32 values.
 * @param word - source word
 * @param shift - shift amount in bits
 * @returns Rotated word.
 * @example
 * Rotate a 32-bit word to the left.
 * ```ts
 * rotl(0x12345678, 8);
 * ```
 */
function rotl(word, shift) {
    return (word << shift) | ((word >>> (32 - shift)) >>> 0);
}
/** Whether the current platform is little-endian. */
const utils_isLE = /* @__PURE__ */ (/* unused pure expression or super */ null && ((() => new Uint8Array(new Uint32Array([0x11223344]).buffer)[0] === 0x44)()));
/**
 * Byte-swap operation for uint32 values.
 * @param word - source word
 * @returns Word with reversed byte order.
 * @example
 * Reverse the byte order of a 32-bit word.
 * ```ts
 * byteSwap(0x11223344);
 * ```
 */
function byteSwap(word) {
    return (((word << 24) & 0xff000000) |
        ((word << 8) & 0xff0000) |
        ((word >>> 8) & 0xff00) |
        ((word >>> 24) & 0xff));
}
/**
 * Conditionally byte-swaps one 32-bit word on big-endian platforms.
 * @param n - source word
 * @returns Original or byte-swapped word depending on platform endianness.
 * @example
 * Normalize a 32-bit word for host endianness.
 * ```ts
 * swap8IfBE(0x11223344);
 * ```
 */
const swap8IfBE = (/* unused pure expression or super */ null && (utils_isLE
    ? (n) => n
    : (n) => byteSwap(n) >>> 0));
/**
 * Byte-swaps every word of a Uint32Array in place.
 * @param arr - array to mutate
 * @returns The same array after mutation; callers pass live state arrays here.
 * @example
 * Reverse the byte order of every word in place.
 * ```ts
 * byteSwap32(new Uint32Array([0x11223344]));
 * ```
 */
function byteSwap32(arr) {
    for (let i = 0; i < arr.length; i++) {
        arr[i] = byteSwap(arr[i]);
    }
    return arr;
}
/**
 * Conditionally byte-swaps a Uint32Array on big-endian platforms.
 * @param u - array to normalize for host endianness
 * @returns Original or byte-swapped array depending on platform endianness.
 *   On big-endian runtimes this mutates `u` in place via `byteSwap32(...)`.
 * @example
 * Normalize a word array for host endianness.
 * ```ts
 * swap32IfBE(new Uint32Array([0x11223344]));
 * ```
 */
const swap32IfBE = (/* unused pure expression or super */ null && (utils_isLE
    ? (u) => u
    : byteSwap32));
// Built-in hex conversion https://caniuse.com/mdn-javascript_builtins_uint8array_fromhex
const hasHexBuiltin = /* @__PURE__ */ (() => 
// @ts-ignore
typeof Uint8Array.from([]).toHex === 'function' && typeof Uint8Array.fromHex === 'function')();
// Array where index 0xf0 (240) is mapped to string 'f0'
const hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, '0'));
/**
 * Convert byte array to hex string.
 * Uses the built-in function when available and assumes it matches the tested
 * fallback semantics.
 * @param bytes - bytes to encode
 * @returns Lowercase hexadecimal string.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Convert bytes to lowercase hexadecimal.
 * ```ts
 * bytesToHex(Uint8Array.from([0xca, 0xfe, 0x01, 0x23])); // 'cafe0123'
 * ```
 */
function bytesToHex(bytes) {
    abytes(bytes);
    // @ts-ignore
    if (hasHexBuiltin)
        return bytes.toHex();
    // pre-caching improves the speed 6x
    let hex = '';
    for (let i = 0; i < bytes.length; i++) {
        hex += hexes[bytes[i]];
    }
    return hex;
}
// Strict ASCII nibble parser: non-ASCII hex lookalikes are rejected as undefined.
// ASCII codes: '0'..'9' = 48..57, 'A'..'F' = 65..70, 'a'..'f' = 97..102.
// prettier-ignore
function asciiToBase16(ch) {
    return ch >= 48 && ch <= 57 ? ch - 48 // '2' => 50-48
        : ch >= 65 && ch <= 70 ? ch - (65 - 10) // 'B' => 66-(65-10)
            : ch >= 97 && ch <= 102 ? ch - (97 - 10) // 'b' => 98-(97-10)
                : undefined;
}
/**
 * Convert hex string to byte array. Uses built-in function, when available.
 * @param hex - hexadecimal string to decode
 * @returns Decoded bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * Decode lowercase hexadecimal into bytes.
 * ```ts
 * hexToBytes('cafe0123'); // Uint8Array.from([0xca, 0xfe, 0x01, 0x23])
 * ```
 */
function hexToBytes(hex) {
    if (typeof hex !== 'string')
        throw new TypeError('hex string expected, got ' + typeof hex);
    if (hasHexBuiltin) {
        try {
            return Uint8Array.fromHex(hex);
        }
        catch (error) {
            if (error instanceof SyntaxError)
                throw new RangeError(error.message);
            throw error;
        }
    }
    const hl = hex.length;
    const al = hl / 2;
    if (hl % 2)
        throw new RangeError('hex string expected, got unpadded hex of length ' + hl);
    const array = new Uint8Array(al);
    for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
        const n1 = asciiToBase16(hex.charCodeAt(hi)); // parse first char, multiply it by 16
        const n2 = asciiToBase16(hex.charCodeAt(hi + 1)); // parse second char
        if (n1 === undefined || n2 === undefined) {
            const char = hex[hi] + hex[hi + 1];
            throw new RangeError('hex string expected, got non-hex character "' + char + '" at index ' + hi);
        }
        array[ai] = n1 * 16 + n2; // example: 'A9' => 10*16 + 9
    }
    return array;
}
/**
 * Yields to the host task scheduler so timers, I/O, and rendering can make progress.
 * Uses the Web Scheduling API when available or `setTimeout` as a cross-platform fallback.
 * Host-task yields are much slower than microtasks (roughly 1ms with the timer fallback), so
 * async loops should use `asyncTick >= 10` to amortize scheduling overhead to about 10% while
 * still allowing other event-loop work to proceed.
 * @param onReject - optional cleanup invoked only if the host yield fails
 * @example
 * Yield to the next scheduler tick.
 * ```ts
 * await nextTick();
 * ```
 */
function nextTick(onReject) {
    const host = globalThis;
    if (typeof host.scheduler?.yield === 'function') {
        const promise = host.scheduler.yield();
        // Keep the original scheduler rejection; this handler exists only for cleanup.
        if (onReject)
            promise.catch(onReject);
        return promise;
    }
    return new Promise((resolve) => host.setTimeout(resolve, 0));
}
/**
 * Returns control to the host event loop every `tick` milliseconds to avoid blocking long loops.
 * @param iters - number of loop iterations to run
 * @param tick - maximum time slice in milliseconds
 * @param cb - callback executed on each iteration
 * @param onReject - optional cleanup invoked only if a host yield fails
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @example
 * Run a loop that periodically yields back to the event loop.
 * ```ts
 * await asyncLoop(2, 0, () => {});
 * ```
 */
async function asyncLoop(iters, tick, cb, onReject) {
    anumber(iters, 'iters');
    anumber(tick, 'tick');
    if (typeof cb !== 'function')
        throw new TypeError('callback must be a function');
    // Callback is synchronous by contract; asyncLoop only yields between sync work windows.
    let ts = Date.now();
    for (let i = 0; i < iters; i++) {
        cb(i);
        // Date.now() is not monotonic, so in case if clock goes backwards we return return control too
        const diff = Date.now() - ts;
        if (diff >= 0 && diff < tick)
            continue;
        await nextTick(onReject);
        // Track only synchronous work time; scheduler delay after yielding is outside our budget.
        ts = Date.now();
    }
}
/**
 * Converts string to bytes using UTF8 encoding.
 * Built-in doesn't validate input to be string: we do the check.
 * Non-ASCII details are delegated to the platform `TextEncoder`.
 * @param str - string to encode
 * @returns UTF-8 encoded bytes.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Encode a string as UTF-8 bytes.
 * ```ts
 * utf8ToBytes('abc'); // Uint8Array.from([97, 98, 99])
 * ```
 */
function utf8ToBytes(str) {
    if (typeof str !== 'string')
        throw new TypeError('string expected');
    const encoded = new TextEncoder().encode(str);
    try {
        // Copy into the current realm for Firefox extension contexts. Callers that own the returned
        // buffer can then wipe it independently of TextEncoder's temporary result.
        return new Uint8Array(encoded); // https://bugzil.la/1681809
    }
    finally {
        clean(encoded);
    }
}
/**
 * Helper for KDFs: consumes Uint8Array or string.
 * String inputs are UTF-8 encoded; byte-array inputs stay aliased to the caller buffer.
 * @param data - user-provided KDF input
 * @param errorTitle - label included in thrown errors
 * @returns Byte representation of the input.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Normalize KDF input to bytes.
 * ```ts
 * kdfInputToBytes('password');
 * ```
 */
function kdfInputToBytes(data, errorTitle = '') {
    if (typeof data === 'string')
        return utf8ToBytes(data);
    return abytes(data, undefined, errorTitle);
}
/**
 * Copies several Uint8Arrays into one.
 * @param arrays - arrays to concatenate
 * @returns Concatenated byte array.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Concatenate multiple byte arrays.
 * ```ts
 * concatBytes(new Uint8Array([1]), new Uint8Array([2]));
 * ```
 */
function concatBytes(...arrays) {
    let sum = 0;
    for (let i = 0; i < arrays.length; i++) {
        const a = arrays[i];
        abytes(a);
        sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i = 0, pad = 0; i < arrays.length; i++) {
        const a = arrays[i];
        res.set(a, pad);
        pad += a.length;
    }
    return res;
}
/**
 * Validates declared required and optional field types on a plain object.
 * This walks field schemas and formats detailed errors, so avoid it on hot paths; use direct
 * one-line guards such as `abytes()`, `abool()`, or `anumber()` instead.
 * @param object - object to validate
 * @param fields - map of required field names to expected types
 * @param optFields - map of optional field names to expected types
 * @param title - label included in thrown errors
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Validate required and optional option fields.
 * ```ts
 * validateObject({ N: 1024, dkLen: 32 }, { N: 'number' }, { dkLen: 'number' });
 * ```
 */
const validateObject = (object, fields = {}, optFields = {}, title = 'object') => {
    aobject(object, title);
    aobject(fields, 'fields');
    aobject(optFields, 'optFields');
    function checkField(fieldName, expectedType, isOpt) {
        const label = title === 'object' ? `param "${String(fieldName)}"` : `"${title}.${String(fieldName)}"`;
        // Config fields must be explicit own properties. Optional inherited values are rejected too
        // because callers keep reading the same options object after validation.
        const val = object[fieldName];
        // Runtime objects such as Field instances intentionally satisfy required method slots
        // via their shared prototype.
        if (!Object.hasOwn(object, fieldName) &&
            (isOpt ? val !== undefined : expectedType !== 'function')) {
            throw new TypeError(`${label} is invalid: expected own property`);
        }
        if (isOpt && val === undefined)
            return;
        const current = typeof val;
        if (current !== expectedType || val === null)
            throw new TypeError(`${label} is invalid: expected ${expectedType}, got ${current}`);
    }
    const iter = (f, isOpt) => Object.entries(f).forEach(([k, v]) => checkField(k, v, isOpt));
    iter(fields, false);
    iter(optFields, true);
};
/**
 * Merges default options and passed options.
 * @param defaults - base option object
 * @param opts - user overrides
 * @param title - label included in thrown override errors
 * @returns Fresh merged option object with a null prototype.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Merge user overrides onto default options.
 * ```ts
 * checkOpts({ dkLen: 32 }, { asyncTick: 10 });
 * ```
 */
function checkOpts(defaults, opts, title = 'opts') {
    aopts(defaults, 'defaults');
    if (opts !== undefined)
        aopts(opts, title);
    // Callers read optional fields directly, so omitted values must not fall through to ambient
    // Object.prototype pollution (for example a forged `dkLen` changing SHAKE's default output).
    const merged = Object.assign(Object.create(null), defaults, opts);
    return merged;
}
/**
 * Creates a callable hash function from a stateful class constructor.
 * @param hashCons - hash constructor or factory
 * @param info - optional metadata such as DER OID
 * @returns Frozen callable hash wrapper with `.create()`.
 *   Wrapper construction eagerly calls `hashCons(undefined)` once to read
 *   `outputLen` / `blockLen`, so constructor side effects happen at module
 *   init time.
 * @throws On wrong argument types. {@link TypeError}
 * @example
 * Wrap a stateful hash constructor into a callable helper.
 * ```ts
 * import { createHasher } from '@noble/hashes/utils.js';
 * import { sha256 } from '@noble/hashes/sha2.js';
 * const wrapped = createHasher(sha256.create, { oid: sha256.oid });
 * wrapped(new Uint8Array([1]));
 * ```
 */
function utils_createHasher(hashCons, info = {}) {
    if (typeof hashCons !== 'function')
        throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
    info = checkOpts({}, info, 'info');
    const hashC = (msg, opts) => hashCons(opts)
        .update(msg)
        .digest();
    const tmp = hashCons(undefined);
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.canXOF = tmp.canXOF;
    hashC.create = (opts) => hashCons(opts);
    Object.assign(hashC, info);
    return Object.freeze(hashC);
}
/**
 * Cryptographically secure PRNG backed by `crypto.getRandomValues`.
 * @param bytesLength - number of random bytes to generate
 * @returns Random bytes.
 * The platform `getRandomValues()` implementation still defines any
 * single-call length cap, and this helper rejects oversize requests
 * with a stable library `RangeError` instead of host-specific errors.
 * @throws On wrong argument types. {@link TypeError}
 * @throws On wrong argument ranges or values. {@link RangeError}
 * @throws If the current runtime does not provide `crypto.getRandomValues`. {@link Error}
 * @example
 * Generate a fresh random key or nonce.
 * ```ts
 * const key = randomBytes(16);
 * ```
 */
function randomBytes(bytesLength = 32) {
    // Match the repo's other length-taking helpers instead of relying on Uint8Array coercion.
    anumber(bytesLength, 'bytesLength');
    const cr = typeof globalThis === 'object' ? globalThis.crypto : null;
    if (typeof cr?.getRandomValues !== 'function')
        throw new Error('crypto.getRandomValues must be defined');
    // Web Cryptography API Level 2 §10.1.1:
    // if `byteLength > 65536`, throw `QuotaExceededError`.
    // Keep the guard explicit so callers can see the quota in code
    // instead of discovering it by reading the spec or host errors.
    // This wrapper surfaces the same quota as a stable library RangeError.
    if (bytesLength > 65536)
        throw new RangeError(`"bytesLength" expected <= 65536, got ${bytesLength}`);
    return cr.getRandomValues(new Uint8Array(bytesLength));
}
/**
 * Creates OID metadata for NIST hashes with prefix `06 09 60 86 48 01 65 03 04 02`.
 * @param suffix - final OID byte for the selected hash.
 *   The helper accepts any byte even though only the documented NIST hash
 *   suffixes are meaningful downstream.
 * @returns Object containing the DER-encoded OID.
 * @example
 * Build OID metadata for a NIST hash.
 * ```ts
 * oidNist(0x01);
 * ```
 */
const utils_oidNist = (suffix) => ({
    // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
    // Larger suffix values would need base-128 OID encoding and a different length byte.
    oid: Uint8Array.from([0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, suffix]),
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/_md.js
/**
 * Internal Merkle-Damgard hash utils.
 * @module
 */


/**
 * Shared 32-bit conditional boolean primitive reused by SHA-256, SHA-1, and MD5 `F`.
 * Returns bits from `b` when `a` is set, otherwise from `c`.
 * The XOR form is equivalent to MD5's `F(X,Y,Z) = XY v not(X)Z` because the masked terms never
 * set the same bit.
 * @param a - selector word
 * @param b - word chosen when selector bit is set
 * @param c - word chosen when selector bit is clear
 * @returns Mixed 32-bit word.
 * @example
 * Combine three words with the shared 32-bit choice primitive.
 * ```ts
 * Chi(0xffffffff, 0x12345678, 0x87654321);
 * ```
 */
function Chi(a, b, c) {
    return (a & b) ^ (~a & c);
}
/**
 * Shared 32-bit majority primitive reused by SHA-256 and SHA-1.
 * Returns bits shared by at least two inputs.
 * @param a - first input word
 * @param b - second input word
 * @param c - third input word
 * @returns Mixed 32-bit word.
 * @example
 * Combine three words with the shared 32-bit majority primitive.
 * ```ts
 * Maj(0xffffffff, 0x12345678, 0x87654321);
 * ```
 */
function Maj(a, b, c) {
    return (a & b) ^ (a & c) ^ (b & c);
}
/**
 * Merkle-Damgard hash construction base class.
 * Could be used to create MD5, RIPEMD, SHA1, SHA2.
 * Accepts only byte-aligned `Uint8Array` input, even when the underlying spec describes bit
 * strings with partial-byte tails.
 * @param blockLen - internal block size in bytes
 * @param outputLen - digest size in bytes
 * @param padOffset - trailing length field size in bytes
 * @param isLE - whether length and state words are encoded in little-endian
 * @example
 * Use a concrete subclass to get the shared Merkle-Damgard update/digest flow.
 * ```ts
 * import { _SHA1 } from '@noble/hashes/legacy.js';
 * const hash = new _SHA1();
 * hash.update(new Uint8Array([97, 98, 99]));
 * hash.digest();
 * ```
 */
class HashMD {
    blockLen;
    outputLen;
    canXOF = false;
    padOffset;
    isLE;
    // For partial updates less than block size
    buffer;
    view;
    finished = false;
    length = 0;
    pos = 0;
    destroyed = false;
    constructor(blockLen, outputLen, padOffset, isLE) {
        this.blockLen = blockLen;
        this.outputLen = outputLen;
        this.padOffset = padOffset;
        this.isLE = isLE;
        this.buffer = new Uint8Array(blockLen);
        this.view = createView(this.buffer);
    }
    update(data) {
        aexists(this);
        abytes(data);
        const { view, buffer, blockLen } = this;
        const len = data.length;
        let processed = false;
        for (let pos = 0; pos < len;) {
            const take = Math.min(blockLen - this.pos, len - pos);
            // Fast path only when there is no buffered partial block: `take === blockLen` implies
            // `this.pos === 0`, so we can process full blocks directly from the input view.
            if (take === blockLen) {
                const dataView = createView(data);
                for (; blockLen <= len - pos; pos += blockLen)
                    this.process(dataView, pos);
                processed = true;
                continue;
            }
            // When the whole input is buffered in one go (common for short messages), passing `data`
            // directly avoids allocating a subarray view.
            buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
            this.pos += take;
            pos += take;
            if (this.pos === blockLen) {
                this.process(view, 0);
                this.pos = 0;
                processed = true;
            }
        }
        this.length += data.length;
        // Shared schedule buffers only pick up input-derived words inside process(); if everything
        // was buffered without processing, there is nothing to zero.
        if (processed)
            this.roundClean();
        return this;
    }
    digestInto(out) {
        aexists(this);
        aoutput(out, this);
        this.finished = true;
        // Padding
        // We can avoid allocation of buffer for padding completely if it
        // was previously not allocated here. But it won't change performance.
        const { buffer, view, blockLen, isLE } = this;
        let { pos } = this;
        // append the bit '1' to the message, then zero-pad the rest of the block
        buffer[pos++] = 0b10000000;
        buffer.fill(0, pos);
        // we have less than padOffset left in buffer, so we cannot put length in
        // current block, need process it and pad again
        if (this.padOffset > blockLen - pos) {
            this.process(view, 0);
            buffer.fill(0);
        }
        // `padOffset` reserves the whole length field. For SHA-384/512 the high 64 bits stay zero from
        // the padding fill above, and JS will overflow before user input can make that half non-zero.
        // So we only need to write the low 64 bits here (`length * 8` only scales the exponent of an
        // integer below 2**53, so the split inside the helper stays exact).
        setU64FromNum(view, blockLen - 8, this.length * 8, isLE);
        this.process(view, 0);
        // The final block above is processed outside update(), so the shared message-schedule
        // buffers (e.g. SHA256_W) would otherwise retain input-derived words after digest().
        this.roundClean();
        // digest() passes our own `buffer` as `out`; reuse its cached view instead of allocating one.
        const oview = out === buffer ? view : createView(out);
        const len = this.outputLen;
        // NOTE: we do division by 4 later, which must be fused in single op with modulo by JIT
        const outLen = len / 4;
        const state = this.get();
        // Subclass-misconfiguration invariant: outputLen must be 32-bit aligned and fit the state.
        if (len % 4 || outLen > state.length)
            throw new Error('invalid outputLen');
        for (let i = 0; i < outLen; i++)
            oview.setUint32(4 * i, state[i], isLE);
    }
    digest() {
        const { buffer, outputLen } = this;
        this.digestInto(buffer);
        // Copy before destroy(): subclasses wipe `buffer` during cleanup, but `digest()` must return
        // fresh bytes to the caller.
        const res = buffer.slice(0, outputLen);
        this.destroy();
        return res;
    }
    _cloneIntoMeta(to) {
        const { buffer, length, finished, destroyed, pos } = this;
        to.destroyed = destroyed;
        to.finished = finished;
        to.length = length;
        to.pos = pos;
        // Only partial-block bytes need copying: when `length % blockLen === 0`, `pos === 0` and
        // later `update()` / `digestInto()` overwrite `to.buffer` from the start before reading it.
        if (pos)
            to.buffer.set(buffer); // Avoid a hot modulo guard.
        return to;
    }
    clone() {
        return this._cloneInto();
    }
}
/**
 * Initial SHA-2 state: fractional parts of square roots of first 16 primes 2..53.
 * Check out `test/misc/sha2-gen-iv.js` for recomputation guide.
 */
/** Initial SHA256 state from RFC 6234 §6.1: the first 32 bits of the fractional parts of the
 * square roots of the first eight prime numbers. Exported as a shared table; callers must treat
 * it as read-only because constructors copy words from it by index. */
const SHA256_IV = /* @__PURE__ */ Uint32Array.from([
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]);
/** Initial SHA224 state `H(0)` from RFC 6234 §6.1. Exported as a shared table; callers must
 * treat it as read-only because constructors copy words from it by index. */
const SHA224_IV = /* @__PURE__ */ Uint32Array.from([
    0xc1059ed8, 0x367cd507, 0x3070dd17, 0xf70e5939, 0xffc00b31, 0x68581511, 0x64f98fa7, 0xbefa4fa4,
]);
/** Initial SHA384 state from RFC 6234 §6.3: eight RFC 64-bit `H(0)` words stored as sixteen
 * big-endian 32-bit halves. Derived from the fractional parts of the square roots of the ninth
 * through sixteenth prime numbers. Exported as a shared table; callers must treat it as read-only
 * because constructors copy halves from it by index. */
const SHA384_IV = /* @__PURE__ */ Uint32Array.from([
    0xcbbb9d5d, 0xc1059ed8, 0x629a292a, 0x367cd507, 0x9159015a, 0x3070dd17, 0x152fecd8, 0xf70e5939,
    0x67332667, 0xffc00b31, 0x8eb44a87, 0x68581511, 0xdb0c2e0d, 0x64f98fa7, 0x47b5481d, 0xbefa4fa4,
]);
/** Initial SHA512 state from RFC 6234 §6.3: eight RFC 64-bit `H(0)` words stored as sixteen
 * big-endian 32-bit halves. Derived from the fractional parts of the square roots of the first
 * eight prime numbers. Exported as a shared table; callers must treat it as read-only because
 * constructors copy halves from it by index. */
const SHA512_IV = /* @__PURE__ */ Uint32Array.from([
    0x6a09e667, 0xf3bcc908, 0xbb67ae85, 0x84caa73b, 0x3c6ef372, 0xfe94f82b, 0xa54ff53a, 0x5f1d36f1,
    0x510e527f, 0xade682d1, 0x9b05688c, 0x2b3e6c1f, 0x1f83d9ab, 0xfb41bd6b, 0x5be0cd19, 0x137e2179,
]);

;// CONCATENATED MODULE: ./node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/sha2.js
/**
 * SHA2 hash function. A.k.a. sha256, sha384, sha512, sha512_224, sha512_256.
 * SHA256 is the fastest hash implementable in JS, even faster than Blake3.
 * Check out {@link https://www.rfc-editor.org/rfc/rfc4634 | RFC 4634} and
 * {@link https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf | FIPS 180-4}.
 * @module
 */



/**
 * SHA-224 / SHA-256 round constants from RFC 6234 §5.1: the first 32 bits
 * of the cube roots of the first 64 primes (2..311).
 */
// prettier-ignore
const SHA256_K = /* @__PURE__ */ Uint32Array.from([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]);
/** Reusable SHA-224 / SHA-256 message schedule buffer `W_t` from RFC 6234 §6.2 step 1. */
const SHA256_W = /* @__PURE__ */ new Uint32Array(64);
/** Internal SHA-224 / SHA-256 compression engine from RFC 6234 §6.2. */
class SHA2_32B extends HashMD {
    // We cannot use array here since array allows indexing by variable
    // which means optimizer/compiler cannot use registers.
    // Numeric initializers matter: starting the fields as `undefined` changes
    // V8's field representation and makes sha256 3x slower (measured).
    A = 0;
    B = 0;
    C = 0;
    D = 0;
    E = 0;
    F = 0;
    G = 0;
    H = 0;
    constructor(outputLen, IV) {
        super(64, outputLen, 8, false);
        this.A = IV[0] | 0;
        this.B = IV[1] | 0;
        this.C = IV[2] | 0;
        this.D = IV[3] | 0;
        this.E = IV[4] | 0;
        this.F = IV[5] | 0;
        this.G = IV[6] | 0;
        this.H = IV[7] | 0;
    }
    get() {
        const { A, B, C, D, E, F, G, H } = this;
        return [A, B, C, D, E, F, G, H];
    }
    // prettier-ignore
    set(A, B, C, D, E, F, G, H) {
        this.A = A | 0;
        this.B = B | 0;
        this.C = C | 0;
        this.D = D | 0;
        this.E = E | 0;
        this.F = F | 0;
        this.G = G | 0;
        this.H = H | 0;
    }
    _cloneInto(to) {
        (to ||= new this.constructor()).set(...this.get());
        return this._cloneIntoMeta(to);
    }
    process(view, offset) {
        // Extend the first 16 words into the remaining 48 words w[16..63] of the message schedule array
        for (let i = 0; i < 16; i++, offset += 4)
            SHA256_W[i] = view.getUint32(offset, false);
        for (let i = 16; i < 64; i++) {
            const W15 = SHA256_W[i - 15];
            const W2 = SHA256_W[i - 2];
            const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ (W15 >>> 3);
            const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ (W2 >>> 10);
            SHA256_W[i] = (s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16]) | 0;
        }
        // Compression function main loop, 64 rounds
        let { A, B, C, D, E, F, G, H } = this;
        for (let i = 0; i < 64; i++) {
            const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
            const T1 = (H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i]) | 0;
            const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
            const T2 = (sigma0 + Maj(A, B, C)) | 0;
            H = G;
            G = F;
            F = E;
            E = (D + T1) | 0;
            D = C;
            C = B;
            B = A;
            A = (T1 + T2) | 0;
        }
        // Add the compressed chunk to the current hash value
        A = (A + this.A) | 0;
        B = (B + this.B) | 0;
        C = (C + this.C) | 0;
        D = (D + this.D) | 0;
        E = (E + this.E) | 0;
        F = (F + this.F) | 0;
        G = (G + this.G) | 0;
        H = (H + this.H) | 0;
        this.set(A, B, C, D, E, F, G, H);
    }
    roundClean() {
        clean(SHA256_W);
    }
    destroy() {
        // HashMD callers route post-destroy usability through `destroyed`; zeroizing alone still leaves
        // update()/digest() callable on reused instances.
        this.destroyed = true;
        this.set(0, 0, 0, 0, 0, 0, 0, 0);
        clean(this.buffer);
    }
}
/** Internal SHA-256 hash class grounded in RFC 6234 §6.2. */
class _SHA256 extends SHA2_32B {
    constructor() {
        super(32, SHA256_IV);
    }
}
/** Internal SHA-224 hash class grounded in RFC 6234 §6.2 and §8.5. */
class _SHA224 extends SHA2_32B {
    constructor() {
        super(28, SHA224_IV);
    }
}
// SHA2-512 is slower than sha256 in js because u64 operations are slow.
// SHA-384 / SHA-512 round constants from RFC 6234 §5.2:
// 80 full 64-bit words split into high/low halves.
// prettier-ignore
const K512 = /* @__PURE__ */ (() => split([
    '0x428a2f98d728ae22', '0x7137449123ef65cd', '0xb5c0fbcfec4d3b2f', '0xe9b5dba58189dbbc',
    '0x3956c25bf348b538', '0x59f111f1b605d019', '0x923f82a4af194f9b', '0xab1c5ed5da6d8118',
    '0xd807aa98a3030242', '0x12835b0145706fbe', '0x243185be4ee4b28c', '0x550c7dc3d5ffb4e2',
    '0x72be5d74f27b896f', '0x80deb1fe3b1696b1', '0x9bdc06a725c71235', '0xc19bf174cf692694',
    '0xe49b69c19ef14ad2', '0xefbe4786384f25e3', '0x0fc19dc68b8cd5b5', '0x240ca1cc77ac9c65',
    '0x2de92c6f592b0275', '0x4a7484aa6ea6e483', '0x5cb0a9dcbd41fbd4', '0x76f988da831153b5',
    '0x983e5152ee66dfab', '0xa831c66d2db43210', '0xb00327c898fb213f', '0xbf597fc7beef0ee4',
    '0xc6e00bf33da88fc2', '0xd5a79147930aa725', '0x06ca6351e003826f', '0x142929670a0e6e70',
    '0x27b70a8546d22ffc', '0x2e1b21385c26c926', '0x4d2c6dfc5ac42aed', '0x53380d139d95b3df',
    '0x650a73548baf63de', '0x766a0abb3c77b2a8', '0x81c2c92e47edaee6', '0x92722c851482353b',
    '0xa2bfe8a14cf10364', '0xa81a664bbc423001', '0xc24b8b70d0f89791', '0xc76c51a30654be30',
    '0xd192e819d6ef5218', '0xd69906245565a910', '0xf40e35855771202a', '0x106aa07032bbd1b8',
    '0x19a4c116b8d2d0c8', '0x1e376c085141ab53', '0x2748774cdf8eeb99', '0x34b0bcb5e19b48a8',
    '0x391c0cb3c5c95a63', '0x4ed8aa4ae3418acb', '0x5b9cca4f7763e373', '0x682e6ff3d6b2b8a3',
    '0x748f82ee5defb2fc', '0x78a5636f43172f60', '0x84c87814a1f0ab72', '0x8cc702081a6439ec',
    '0x90befffa23631e28', '0xa4506cebde82bde9', '0xbef9a3f7b2c67915', '0xc67178f2e372532b',
    '0xca273eceea26619c', '0xd186b8c721c0c207', '0xeada7dd6cde0eb1e', '0xf57d4f7fee6ed178',
    '0x06f067aa72176fba', '0x0a637dc5a2c898a6', '0x113f9804bef90dae', '0x1b710b35131c471b',
    '0x28db77f523047d84', '0x32caab7b40c72493', '0x3c9ebe0a15c9bebc', '0x431d67c49c100d4c',
    '0x4cc5d4becb3e42b6', '0x597f299cfc657e2a', '0x5fcb6fab3ad6faec', '0x6c44198c4a475817'
].map(n => BigInt(n))))();
const SHA512_Kh = /* @__PURE__ */ (() => K512[0])();
const SHA512_Kl = /* @__PURE__ */ (() => K512[1])();
// Reusable high-half schedule buffer for the RFC 6234 §6.4 64-bit `W_t` words.
const SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
// Reusable low-half schedule buffer for the RFC 6234 §6.4 64-bit `W_t` words.
const SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
/** Internal SHA-384 / SHA-512 compression engine from RFC 6234 §6.4. */
class SHA2_64B extends HashMD {
    // We cannot use array here since array allows indexing by variable
    // which means optimizer/compiler cannot use registers.
    // h -- high 32 bits, l -- low 32 bits
    // Numeric initializers matter: starting the fields as `undefined` changes
    // V8's field representation and slows hashing down (measured on sha256).
    Ah = 0;
    Al = 0;
    Bh = 0;
    Bl = 0;
    Ch = 0;
    Cl = 0;
    Dh = 0;
    Dl = 0;
    Eh = 0;
    El = 0;
    Fh = 0;
    Fl = 0;
    Gh = 0;
    Gl = 0;
    Hh = 0;
    Hl = 0;
    constructor(outputLen, IV) {
        super(128, outputLen, 16, false);
        this.Ah = IV[0] | 0;
        this.Al = IV[1] | 0;
        this.Bh = IV[2] | 0;
        this.Bl = IV[3] | 0;
        this.Ch = IV[4] | 0;
        this.Cl = IV[5] | 0;
        this.Dh = IV[6] | 0;
        this.Dl = IV[7] | 0;
        this.Eh = IV[8] | 0;
        this.El = IV[9] | 0;
        this.Fh = IV[10] | 0;
        this.Fl = IV[11] | 0;
        this.Gh = IV[12] | 0;
        this.Gl = IV[13] | 0;
        this.Hh = IV[14] | 0;
        this.Hl = IV[15] | 0;
    }
    // prettier-ignore
    get() {
        const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
        return [Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl];
    }
    // prettier-ignore
    set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
        this.Ah = Ah | 0;
        this.Al = Al | 0;
        this.Bh = Bh | 0;
        this.Bl = Bl | 0;
        this.Ch = Ch | 0;
        this.Cl = Cl | 0;
        this.Dh = Dh | 0;
        this.Dl = Dl | 0;
        this.Eh = Eh | 0;
        this.El = El | 0;
        this.Fh = Fh | 0;
        this.Fl = Fl | 0;
        this.Gh = Gh | 0;
        this.Gl = Gl | 0;
        this.Hh = Hh | 0;
        this.Hl = Hl | 0;
    }
    _cloneInto(to) {
        (to ||= new this.constructor()).set(...this.get());
        return this._cloneIntoMeta(to);
    }
    process(view, offset) {
        // Extend the first 16 words into the remaining 64 words w[16..79] of the message schedule array
        for (let i = 0; i < 16; i++, offset += 4) {
            SHA512_W_H[i] = view.getUint32(offset);
            SHA512_W_L[i] = view.getUint32((offset += 4));
        }
        for (let i = 16; i < 80; i++) {
            // s0 := (w[i-15] rightrotate 1) xor (w[i-15] rightrotate 8) xor (w[i-15] rightshift 7)
            const W15h = SHA512_W_H[i - 15] | 0;
            const W15l = SHA512_W_L[i - 15] | 0;
            const s0h = rotrSH(W15h, W15l, 1) ^ rotrSH(W15h, W15l, 8) ^ shrSH(W15h, W15l, 7);
            const s0l = rotrSL(W15h, W15l, 1) ^ rotrSL(W15h, W15l, 8) ^ shrSL(W15h, W15l, 7);
            // s1 := (w[i-2] rightrotate 19) xor (w[i-2] rightrotate 61) xor (w[i-2] rightshift 6)
            const W2h = SHA512_W_H[i - 2] | 0;
            const W2l = SHA512_W_L[i - 2] | 0;
            const s1h = rotrSH(W2h, W2l, 19) ^ rotrBH(W2h, W2l, 61) ^ shrSH(W2h, W2l, 6);
            const s1l = rotrSL(W2h, W2l, 19) ^ rotrBL(W2h, W2l, 61) ^ shrSL(W2h, W2l, 6);
            // SHA512_W[i] = s0 + s1 + SHA512_W[i - 7] + SHA512_W[i - 16];
            const SUMl = add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
            const SUMh = add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
            SHA512_W_H[i] = SUMh | 0;
            SHA512_W_L[i] = SUMl | 0;
        }
        let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
        // Compression function main loop, 80 rounds
        for (let i = 0; i < 80; i++) {
            // S1 := (e rightrotate 14) xor (e rightrotate 18) xor (e rightrotate 41)
            const sigma1h = rotrSH(Eh, El, 14) ^ rotrSH(Eh, El, 18) ^ rotrBH(Eh, El, 41);
            const sigma1l = rotrSL(Eh, El, 14) ^ rotrSL(Eh, El, 18) ^ rotrBL(Eh, El, 41);
            //const T1 = (H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i]) | 0;
            const CHIh = (Eh & Fh) ^ (~Eh & Gh);
            const CHIl = (El & Fl) ^ (~El & Gl);
            // T1 = H + sigma1 + Chi(E, F, G) + SHA512_K[i] + SHA512_W[i]
            // prettier-ignore
            const T1ll = add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
            const T1h = add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
            const T1l = T1ll | 0;
            // S0 := (a rightrotate 28) xor (a rightrotate 34) xor (a rightrotate 39)
            const sigma0h = rotrSH(Ah, Al, 28) ^ rotrBH(Ah, Al, 34) ^ rotrBH(Ah, Al, 39);
            const sigma0l = rotrSL(Ah, Al, 28) ^ rotrBL(Ah, Al, 34) ^ rotrBL(Ah, Al, 39);
            const MAJh = (Ah & Bh) ^ (Ah & Ch) ^ (Bh & Ch);
            const MAJl = (Al & Bl) ^ (Al & Cl) ^ (Bl & Cl);
            Hh = Gh | 0;
            Hl = Gl | 0;
            Gh = Fh | 0;
            Gl = Fl | 0;
            Fh = Eh | 0;
            Fl = El | 0;
            ({ h: Eh, l: El } = add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
            Dh = Ch | 0;
            Dl = Cl | 0;
            Ch = Bh | 0;
            Cl = Bl | 0;
            Bh = Ah | 0;
            Bl = Al | 0;
            const All = add3L(T1l, sigma0l, MAJl);
            Ah = add3H(All, T1h, sigma0h, MAJh);
            Al = All | 0;
        }
        // Add the compressed chunk to the current hash value
        ({ h: Ah, l: Al } = add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
        ({ h: Bh, l: Bl } = add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
        ({ h: Ch, l: Cl } = add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
        ({ h: Dh, l: Dl } = add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
        ({ h: Eh, l: El } = add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
        ({ h: Fh, l: Fl } = add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
        ({ h: Gh, l: Gl } = add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
        ({ h: Hh, l: Hl } = add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
        this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
    }
    roundClean() {
        clean(SHA512_W_H, SHA512_W_L);
    }
    destroy() {
        // HashMD callers route post-destroy usability through `destroyed`; zeroizing alone still leaves
        // update()/digest() callable on reused instances.
        this.destroyed = true;
        clean(this.buffer);
        this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
}
/** Internal SHA-512 hash class grounded in RFC 6234 §6.3 and §6.4. */
class _SHA512 extends SHA2_64B {
    constructor() {
        super(64, SHA512_IV);
    }
}
/** Internal SHA-384 hash class grounded in RFC 6234 §6.3 and §6.4. */
class _SHA384 extends SHA2_64B {
    constructor() {
        super(48, SHA384_IV);
    }
}
/**
 * Truncated SHA512/256 and SHA512/224.
 * SHA512_IV is XORed with 0xa5a5a5a5a5a5a5a5, then used as "intermediary" IV of SHA512/t.
 * Then t hashes string to produce result IV.
 * See the repo-side derivation recipe in `test/misc/sha2-gen-iv.js`.
 * These IV literals are checked against that script rather than a dedicated
 * local RFC section.
 */
/** SHA-512/224 IV derived by the SHA-512/t recipe in `test/misc/sha2-gen-iv.js` and
 * stored as sixteen big-endian 32-bit halves. */
const T224_IV = /* @__PURE__ */ Uint32Array.from([
    0x8c3d37c8, 0x19544da2, 0x73e19966, 0x89dcd4d6, 0x1dfab7ae, 0x32ff9c82, 0x679dd514, 0x582f9fcf,
    0x0f6d2b69, 0x7bd44da8, 0x77e36f73, 0x04c48942, 0x3f9d85a8, 0x6a1d36c8, 0x1112e6ad, 0x91d692a1,
]);
/** SHA-512/256 IV derived by the SHA-512/t recipe in `test/misc/sha2-gen-iv.js` and
 * stored as sixteen big-endian 32-bit halves. */
const T256_IV = /* @__PURE__ */ Uint32Array.from([
    0x22312194, 0xfc2bf72c, 0x9f555fa3, 0xc84c64c2, 0x2393b86b, 0x6f53b151, 0x96387719, 0x5940eabd,
    0x96283ee2, 0xa88effe3, 0xbe5e1e25, 0x53863992, 0x2b0199fc, 0x2c85b8aa, 0x0eb72ddc, 0x81c52ca2,
]);
/** Internal SHA-512/224 hash class using the derived `T224_IV` and the shared
 * RFC 6234 §6.4 compression engine. */
class _SHA512_224 extends SHA2_64B {
    constructor() {
        super(28, T224_IV);
    }
}
/** Internal SHA-512/256 hash class using the derived `T256_IV` and the shared
 * RFC 6234 §6.4 compression engine. */
class _SHA512_256 extends SHA2_64B {
    constructor() {
        super(32, T256_IV);
    }
}
/**
 * SHA2-256 hash function from RFC 4634. In JS it's the fastest: even faster than Blake3. Some info:
 *
 * - Trying 2^128 hashes would get 50% chance of collision, using birthday attack.
 * - BTC network is doing 2^70 hashes/sec (2^95 hashes/year) as per 2025.
 * - Each sha256 hash is executing 2^18 bit operations.
 * - Good 2024 ASICs can do 200Th/sec with 3500 watts of power, corresponding to 2^36 hashes/joule.
 * @param msg - message bytes to hash
 * @param opts - Reserved hash options.
 * @returns Digest bytes.
 * @example
 * Hash a message with SHA2-256.
 * ```ts
 * sha256(new Uint8Array([97, 98, 99]));
 * ```
 */
const sha256 = /* @__PURE__ */ utils_createHasher(() => new _SHA256(), 
/* @__PURE__ */ utils_oidNist(0x01));
/**
 * SHA2-224 hash function from RFC 4634.
 * @param msg - message bytes to hash
 * @param opts - Reserved hash options.
 * @returns Digest bytes.
 * @example
 * Hash a message with SHA2-224.
 * ```ts
 * sha224(new Uint8Array([97, 98, 99]));
 * ```
 */
const sha224 = /* @__PURE__ */ (/* unused pure expression or super */ null && (createHasher(() => new _SHA224(), 
/* @__PURE__ */ oidNist(0x04))));
/**
 * SHA2-512 hash function from RFC 4634.
 * @param msg - message bytes to hash
 * @param opts - Reserved hash options.
 * @returns Digest bytes.
 * @example
 * Hash a message with SHA2-512.
 * ```ts
 * sha512(new Uint8Array([97, 98, 99]));
 * ```
 */
const sha512 = /* @__PURE__ */ (/* unused pure expression or super */ null && (createHasher(() => new _SHA512(), 
/* @__PURE__ */ oidNist(0x03))));
/**
 * SHA2-384 hash function from RFC 4634.
 * @param msg - message bytes to hash
 * @param opts - Reserved hash options.
 * @returns Digest bytes.
 * @example
 * Hash a message with SHA2-384.
 * ```ts
 * sha384(new Uint8Array([97, 98, 99]));
 * ```
 */
const sha384 = /* @__PURE__ */ (/* unused pure expression or super */ null && (createHasher(() => new _SHA384(), 
/* @__PURE__ */ oidNist(0x02))));
/**
 * SHA2-512/256 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on {@link https://eprint.iacr.org/2010/548.pdf | truncated SHA512}.
 * @param msg - message bytes to hash
 * @param opts - Reserved hash options.
 * @returns Digest bytes.
 * @example
 * Hash a message with SHA2-512/256.
 * ```ts
 * sha512_256(new Uint8Array([97, 98, 99]));
 * ```
 */
const sha512_256 = /* @__PURE__ */ (/* unused pure expression or super */ null && (createHasher(() => new _SHA512_256(), 
/* @__PURE__ */ oidNist(0x06))));
/**
 * SHA2-512/224 "truncated" hash function, with improved resistance to length extension attacks.
 * See the paper on {@link https://eprint.iacr.org/2010/548.pdf | truncated SHA512}.
 * @param msg - message bytes to hash
 * @param opts - Reserved hash options.
 * @returns Digest bytes.
 * @example
 * Hash a message with SHA2-512/224.
 * ```ts
 * sha512_224(new Uint8Array([97, 98, 99]));
 * ```
 */
const sha512_224 = /* @__PURE__ */ (/* unused pure expression or super */ null && (createHasher(() => new _SHA512_224(), 
/* @__PURE__ */ oidNist(0x05))));

;// CONCATENATED MODULE: ./node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/hmac.js
/**
 * HMAC: RFC2104 message authentication code.
 * @module
 */

/**
 * Internal class for HMAC.
 * Accepts any byte key, although RFC 2104 §3 recommends keys at least
 * `HashLen` bytes long.
 */
class _HMAC {
    oHash;
    iHash;
    blockLen;
    outputLen;
    canXOF = false;
    finished = false;
    destroyed = false;
    constructor(hash, key) {
        ahash(hash);
        abytes(key, undefined, 'key');
        this.iHash = hash.create();
        if (typeof this.iHash.update !== 'function')
            throw new Error('expected Hash instance');
        this.blockLen = this.iHash.blockLen;
        this.outputLen = this.iHash.outputLen;
        const blockLen = this.blockLen;
        const pad = new Uint8Array(blockLen);
        // blockLen can be bigger than outputLen
        pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
        for (let i = 0; i < pad.length; i++)
            pad[i] ^= 0x36;
        this.iHash.update(pad);
        // By doing update (processing of the first block) of the outer hash here,
        // we can re-use it between multiple calls via clone.
        this.oHash = hash.create();
        // Undo internal XOR && apply outer XOR
        for (let i = 0; i < pad.length; i++)
            pad[i] ^= 0x36 ^ 0x5c;
        this.oHash.update(pad);
        clean(pad);
    }
    update(buf) {
        aexists(this);
        this.iHash.update(buf);
        return this;
    }
    digestInto(out) {
        aexists(this);
        aoutput(out, this);
        this.finished = true;
        const buf = out.subarray(0, this.outputLen);
        // Reuse the first outputLen bytes for the inner digest; the outer hash consumes them before
        // overwriting that same prefix with the final tag, leaving any oversized tail untouched.
        this.iHash.digestInto(buf);
        this.oHash.update(buf);
        this.oHash.digestInto(buf);
        this.destroy();
    }
    digest() {
        const out = new Uint8Array(this.oHash.outputLen);
        this.digestInto(out);
        return out;
    }
    _cloneInto(to) {
        // Create new instance without calling constructor since the key
        // is already in state and we don't know it.
        to ||= Object.create(Object.getPrototypeOf(this), {});
        const { oHash, iHash, finished, destroyed, blockLen, outputLen, canXOF } = this;
        to = to;
        to.finished = finished;
        to.destroyed = destroyed;
        to.blockLen = blockLen;
        to.outputLen = outputLen;
        to.canXOF = canXOF;
        to.oHash = oHash._cloneInto(to.oHash);
        to.iHash = iHash._cloneInto(to.iHash);
        return to;
    }
    clone() {
        return this._cloneInto();
    }
    destroy() {
        this.destroyed = true;
        this.oHash.destroy();
        this.iHash.destroy();
    }
}
const hmac = /* @__PURE__ */ (() => {
    const hmac_ = ((hash, key, message) => new _HMAC(hash, key).update(message).digest());
    hmac_.create = (hash, key) => new _HMAC(hash, key);
    return hmac_;
})();

;// CONCATENATED MODULE: ./src/sigv4.ts
// AWS Signature Version 4 — pure module (no tur imports) so the Node selftest
// can verify it against known vectors and an independent node:crypto
// reference signer. Uses `@noble/hashes` (pure-JS SHA-256 / HMAC — the plugin
// runtime's `crypto` global only exposes getRandomValues/randomUUID, no
// WebCrypto subtle) and the global `TextEncoder` (native in Node, provided by
// `infra/text-polyfill` in the plugin runtime — imported first by backend.ts).
//
// Only what S3 needs: bodyless GETs (list + ranged object download), static
// credentials, path-style addressing. The canonical URI/query strings passed
// in must already be SigV4-encoded (see `s3path.ts`) — the same strings go
// into the request URL and the canonical request, byte for byte.



/** SHA-256 of the empty payload — every request this plugin signs is a
 *  bodyless GET. (Hardcoded so the constant is testable against itself.) */ const EMPTY_PAYLOAD_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
const S3_SERVICE = "s3";
const ALGORITHM = "AWS4-HMAC-SHA256";
const AMZ_TERMINATOR = "aws4_request";
const encoder = ()=>new TextEncoder();
/** `{ amzDate: "20150830T123600Z", dateStamp: "20150830" }` for `now`
 *  (UTC — SigV4 has no notion of local time). */ function amzTimestamps(now) {
    const p = (n, w)=>String(n).padStart(w, "0");
    const dateStamp = String(now.getUTCFullYear()).padStart(4, "0") + p(now.getUTCMonth() + 1, 2) + p(now.getUTCDate(), 2);
    const amzDate = dateStamp + "T" + p(now.getUTCHours(), 2) + p(now.getUTCMinutes(), 2) + p(now.getUTCSeconds(), 2) + "Z";
    return {
        amzDate,
        dateStamp
    };
}
/**
 * Canonical query string: params sorted by key (then value), strictly
 * RFC 3986-encoded, joined `k=v` with `&`. The SAME string doubles as the
 * request URL's query — servers do not care about order, the signature does.
 * `params` may be given in any order; keys must not be pre-encoded.
 */ function canonicalQueryString(params) {
    const enc = (s)=>s3UriEncode(s);
    return params.slice().sort((a, b)=>a[0] === b[0] ? a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0 : a[0] < b[0] ? -1 : 1).map(([k, v])=>`${enc(k)}=${enc(v)}`).join("&");
}
// Local import-free copy of the strict encoder (s3path.ts keeps its own so
// the two pure modules stay independently testable — `s3Encode(s, false)`).
function s3UriEncode(s) {
    const unreserved = /[A-Za-z0-9\-._~]/;
    const bytes = new TextEncoder().encode(s);
    let out = "";
    for (const b of bytes){
        const ch = String.fromCharCode(b);
        out += unreserved.test(ch) ? ch : "%" + b.toString(16).toUpperCase().padStart(2, "0");
    }
    return out;
}
/** SigV4 signing key: HMAC chain over date / region / service / terminator. */ function deriveSigningKey(secretKey, dateStamp, region, service) {
    const enc = encoder();
    let key = hmac(sha256, enc.encode("AWS4" + secretKey), enc.encode(dateStamp));
    key = hmac(sha256, key, enc.encode(region));
    key = hmac(sha256, key, enc.encode(service));
    return hmac(sha256, key, enc.encode(AMZ_TERMINATOR));
}
/** Canonical request string (the SigV4 spec's step 1) — exported for tests.
 *  Header lines are rendered in sorted (lowercase) name order, as the spec
 *  requires — insertion order is only accidentally sorted for list ops. */ function canonicalRequest(p) {
    const headerLines = Object.keys(p.headers).sort().map((name)=>`${name}:${trimAll(p.headers[name])}\n`).join("");
    const signedHeaders = Object.keys(p.headers).sort().join(";");
    return p.method + "\n" + p.canonicalUri + "\n" + p.canonicalQuery + "\n" + headerLines + "\n" + signedHeaders + "\n" + (p.payloadSha256 ?? EMPTY_PAYLOAD_SHA256);
}
/** String to sign (step 2) — exported for tests. */ function stringToSign(p) {
    const hashedCanonical = bytesToHex(sha256(encoder().encode(canonicalRequest(p))));
    return ALGORITHM + "\n" + p.amzDate + "\n" + `${p.dateStamp}/${p.region}/${p.service}/${AMZ_TERMINATOR}` + "\n" + hashedCanonical;
}
/** `trimAll`: sequential spaces collapse to one, then trim — the spec's
 *  header-value canonicalization. */ function trimAll(v) {
    return v.replace(/\s+/g, " ").trim();
}
/** Steps 3–5: derive the signing key, sign the string-to-sign, assemble the
 *  `Authorization` header. */ function signRequest(p, credentials) {
    const signedHeaders = Object.keys(p.headers).sort().join(";");
    const key = deriveSigningKey(credentials.secretKey, p.dateStamp, p.region, p.service);
    const signature = bytesToHex(hmac(sha256, key, encoder().encode(stringToSign(p))));
    const authorization = `${ALGORITHM} Credential=${credentials.accessKey}` + `/${p.dateStamp}/${p.region}/${p.service}/${AMZ_TERMINATOR}` + `, SignedHeaders=${signedHeaders}, Signature=${signature}`;
    return {
        authorization,
        signedHeaders
    };
}

;// CONCATENATED MODULE: ./src/s3path.ts
// S3 path & endpoint helpers — pure (no tur imports) so the Node selftest can
// exercise them directly (`node scripts/selftest.ts`).
//
// Path model mirroring the WebDAV plugin's conventions, mapped onto S3's flat
// key space:
//   - plugin paths are `/`-rooted: "/music/album/track.mp3"
//   - a `dir` from the host is "" or "/" for the root, else "/music/album"
//   - an S3 prefix always ends with "/" ("" for the root)
//   - keys are stored WITHOUT the leading slash: "music/album/track.mp3"
//
// URI encoding follows the SigV4 rules (everything but `A-Za-z0-9-._~`
// percent-encoded, hex uppercase; `/` preserved in paths). The SAME encoded
// string is used for both the request URL and the canonical request — they
// must match byte-for-byte or the signature fails. reqwest's `Url` passes
// already-encoded paths through unchanged (the WebDAV plugin relies on the
// same property).
/** Endpoint as the user entered it, normalized for requests + signing. */ /**
 * Normalize an endpoint string. Accepts `host`, `host:port`, `http(s)://…`,
 * optional base path, trailing slashes. Throws on anything without a parseable
 * host (no `URL` in the boa engine — pure string handling, like the WebDAV
 * plugin's `splitAddr`).
 */ function normalizeEndpoint(input) {
    let s = input.trim();
    if (s === "") throw new Error("s3: endpoint cannot be empty");
    const hasScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(s);
    if (!hasScheme) s = "https://" + s;
    const schemeDelim = s.indexOf("://");
    const scheme = s.slice(0, schemeDelim).toLowerCase();
    if (scheme !== "http" && scheme !== "https") {
        throw new Error(`s3: endpoint scheme must be http or https: ${input}`);
    }
    const rest = s.slice(schemeDelim + 3);
    const slash = rest.indexOf("/");
    const authority = slash === -1 ? rest : rest.slice(0, slash);
    let basePath = slash === -1 ? "" : rest.slice(slash).replace(/\/+$/, "");
    if (authority === "" || /\s/.test(authority) || authority.startsWith(":")) {
        throw new Error(`s3: endpoint has no host: ${input}`);
    }
    // Authority must be `host` or `host:port` (IPv6 brackets tolerated).
    const colon = authority.lastIndexOf(":");
    let host = authority;
    if (colon !== -1) {
        const port = authority.slice(colon + 1);
        if (!/^\d+$/.test(port)) {
            throw new Error(`s3: endpoint has an invalid port: ${input}`);
        }
        if (authority.slice(0, colon) === "") {
            throw new Error(`s3: endpoint has no host: ${input}`);
        }
        // Strip explicit default ports — the `Url` crate drops them when
        // parsing, so the Host header (and the signed `host` value) must match.
        if (scheme === "http" && port === "80" || scheme === "https" && port === "443") {
            host = authority.slice(0, colon);
        }
    }
    return {
        origin: `${scheme}://${host}${basePath}`,
        host,
        basePath: basePath === "" ? "" : basePath
    };
}
/** Strict RFC 3986 percent-encoding (SigV4 rules): everything but
 *  `A-Za-z0-9-._~`; slashes preserved unless `keepSlash` is false. Hex is
 *  uppercase per the spec. */ function s3Encode(s, keepSlash) {
    const unreserved = /[A-Za-z0-9\-._~]/;
    const bytes = new TextEncoder().encode(s);
    let out = "";
    for (const b of bytes){
        const ch = String.fromCharCode(b);
        if (unreserved.test(ch) || keepSlash && ch === "/") {
            out += ch;
        } else {
            out += "%" + b.toString(16).toUpperCase().padStart(2, "0");
        }
    }
    return out;
}
/** Tolerant percent-decoding (S3 list responses return keys URL-encoded;
 *  MinIO returns them raw — decode failures keep the input verbatim). */ function s3Decode(s) {
    if (!s.includes("%")) return s;
    try {
        return decodeURIComponent(s);
    } catch  {
        return s;
    }
}
/** Host `dir` ("", "/", "/music/album") → S3 list prefix ("", "music/album/"). */ function dirToPrefix(dir) {
    let d = dir.replace(/^\/+/, "").replace(/\/+$/, "");
    if (d === "") return "";
    return d + "/";
}
/** Plugin path ("/music/a.mp3") → object key ("music/a.mp3"). */ function pathToKey(path) {
    return path.replace(/^\/+/, "");
}
/** Object key ("music/a.mp3") → plugin path ("/music/a.mp3"). */ function keyToPath(key) {
    return "/" + key.replace(/^\/+/, "");
}
/**
 * Canonical URI for a request (also used verbatim as the URL's path):
 * `/[basePath/]bucket[/key]`, strictly encoded with slashes preserved.
 * The bucket charset is validated by the connect flow, but encode anyway so
 * nothing surprising ever reaches the wire unescaped.
 */ function canonicalUri(endpoint, bucket, key) {
    const base = endpoint.basePath === "" ? "" : s3Encode(endpoint.basePath, true);
    let uri = `${base}/${s3Encode(bucket, false)}`;
    if (key != null && key !== "") uri += "/" + s3Encode(key, true);
    return uri;
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/util.js


const nameStartChar = ':A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD';
const nameChar = nameStartChar + '\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040';
const nameRegexp = '[' + nameStartChar + '][' + nameChar + ']*';
const regexName = new RegExp('^' + nameRegexp + '$');

function getAllMatches(string, regex) {
  const matches = [];
  let match = regex.exec(string);
  while (match) {
    const allmatches = [];
    allmatches.startIndex = regex.lastIndex - match[0].length;
    const len = match.length;
    for (let index = 0; index < len; index++) {
      allmatches.push(match[index]);
    }
    matches.push(allmatches);
    match = regex.exec(string);
  }
  return matches;
}

const isName = function (string) {
  const match = regexName.exec(string);
  return !(match === null || typeof match === 'undefined');
}

function isExist(v) {
  return typeof v !== 'undefined';
}

function isEmptyObject(obj) {
  return Object.keys(obj).length === 0;
}

function getValue(v) {
  if (exports.isExist(v)) {
    return v;
  } else {
    return '';
  }
}

/**
 * Dangerous property names that could lead to prototype pollution or security issues
 */
const DANGEROUS_PROPERTY_NAMES = [
  // '__proto__',
  // 'constructor',
  // 'prototype',
  'hasOwnProperty',
  'toString',
  'valueOf',
  '__defineGetter__',
  '__defineSetter__',
  '__lookupGetter__',
  '__lookupSetter__'
];

const criticalProperties = ["__proto__", "constructor", "prototype"];
;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js



const defaultOnDangerousProperty = (name) => {
  if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
    return "__" + name;
  }
  return name;
};


const defaultOptions = {
  preserveOrder: false,
  attributeNamePrefix: '@_',
  attributesGroupName: false,
  textNodeName: '#text',
  ignoreAttributes: true,
  removeNSPrefix: false, // remove NS from tag name or attribute name if true
  allowBooleanAttributes: false, //a tag can have attributes without any value
  //ignoreRootElement : false,
  parseTagValue: true,
  parseAttributeValue: false,
  trimValues: true, //Trim string values of tag and attributes
  cdataPropName: false,
  numberParseOptions: {
    hex: true,
    leadingZeros: true,
    eNotation: true,
    unicode: false
  },
  tagValueProcessor: function (tagName, val) {
    return val;
  },
  attributeValueProcessor: function (attrName, val) {
    return val;
  },
  stopNodes: [], //nested tags will not be parsed even for errors
  alwaysCreateTextNode: false,
  isArray: () => false,
  commentPropName: false,
  unpairedTags: [],
  processEntities: true,
  htmlEntities: false,
  entityDecoder: null,
  ignoreDeclaration: false,
  ignorePiTags: false,
  transformTagName: false,
  transformAttributeName: false,
  updateTag: function (tagName, jPath, attrs) {
    return tagName
  },
  // skipEmptyListItem: false
  captureMetaData: false,
  maxNestedTags: 100,
  strictReservedNames: true,
  jPath: true, // if true, pass jPath string to callbacks; if false, pass matcher instance
  onDangerousProperty: defaultOnDangerousProperty
};


/**
 * Validates that a property name is safe to use
 * @param {string} propertyName - The property name to validate
 * @param {string} optionName - The option field name (for error message)
 * @throws {Error} If property name is dangerous
 */
function validatePropertyName(propertyName, optionName) {
  if (typeof propertyName !== 'string') {
    return; // Only validate string property names
  }

  const normalized = propertyName.toLowerCase();
  if (DANGEROUS_PROPERTY_NAMES.some(dangerous => normalized === dangerous.toLowerCase())) {
    throw new Error(
      `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
    );
  }

  if (criticalProperties.some(dangerous => normalized === dangerous.toLowerCase())) {
    throw new Error(
      `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
    );
  }
}

/**
 * Normalizes processEntities option for backward compatibility
 * @param {boolean|object} value 
 * @returns {object} Always returns normalized object
 */
function normalizeProcessEntities(value, htmlEntities) {
  // Boolean backward compatibility
  if (typeof value === 'boolean') {
    return {
      enabled: value, // true or false
      maxEntitySize: 10000,
      maxExpansionDepth: 10000,
      maxTotalExpansions: Infinity,
      maxExpandedLength: 100000,
      maxEntityCount: 1000,
      allowedTags: null,
      tagFilter: null,
      appliesTo: "all",
    };
  }

  // Object config - merge with defaults
  if (typeof value === 'object' && value !== null) {
    return {
      enabled: value.enabled !== false,
      maxEntitySize: Math.max(1, value.maxEntitySize ?? 10000),
      maxExpansionDepth: Math.max(1, value.maxExpansionDepth ?? 10000),
      maxTotalExpansions: Math.max(1, value.maxTotalExpansions ?? Infinity),
      maxExpandedLength: Math.max(1, value.maxExpandedLength ?? 100000),
      maxEntityCount: Math.max(1, value.maxEntityCount ?? 1000),
      allowedTags: value.allowedTags ?? null,
      tagFilter: value.tagFilter ?? null,
      appliesTo: value.appliesTo ?? "all",
    };
  }

  // Default to enabled with limits
  return normalizeProcessEntities(true);
}

const buildOptions = function (options) {
  const built = Object.assign({}, defaultOptions, options);

  // Validate property names to prevent prototype pollution
  const propertyNameOptions = [
    { value: built.attributeNamePrefix, name: 'attributeNamePrefix' },
    { value: built.attributesGroupName, name: 'attributesGroupName' },
    { value: built.textNodeName, name: 'textNodeName' },
    { value: built.cdataPropName, name: 'cdataPropName' },
    { value: built.commentPropName, name: 'commentPropName' }
  ];

  for (const { value, name } of propertyNameOptions) {
    if (value) {
      validatePropertyName(value, name);
    }
  }

  if (built.onDangerousProperty === null) {
    built.onDangerousProperty = defaultOnDangerousProperty;
  }

  // Always normalize processEntities for backward compatibility and validation
  built.processEntities = normalizeProcessEntities(built.processEntities, built.htmlEntities);
  built.unpairedTagsSet = new Set(built.unpairedTags);
  // Convert old-style stopNodes for backward compatibility
  if (built.stopNodes && Array.isArray(built.stopNodes)) {
    built.stopNodes = built.stopNodes.map(node => {
      if (typeof node === 'string' && node.startsWith('*.')) {
        // Old syntax: *.tagname meant "tagname anywhere"
        // Convert to new syntax: ..tagname
        return '..' + node.substring(2);
      }
      return node;
    });
  }
  //console.debug(built.processEntities)
  return built;
};
;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/xmlparser/xmlNode.js


let METADATA_SYMBOL;

if (typeof Symbol !== "function") {
  METADATA_SYMBOL = "@@xmlMetadata";
} else {
  METADATA_SYMBOL = Symbol("XML Node Metadata");
}

class XmlNode {
  constructor(tagname) {
    this.tagname = tagname;
    this.child = []; //nested tags, text, cdata, comments in order
    this[":@"] = Object.create(null); //attributes map
  }
  add(key, val) {
    // this.child.push( {name : key, val: val, isCdata: isCdata });
    if (key === "__proto__") key = "#__proto__";
    this.child.push({ [key]: val });
  }
  addChild(node, startIndex) {
    if (node.tagname === "__proto__") node.tagname = "#__proto__";
    if (node[":@"] && Object.keys(node[":@"]).length > 0) {
      this.child.push({ [node.tagname]: node.child, [":@"]: node[":@"] });
    } else {
      this.child.push({ [node.tagname]: node.child });
    }
    // if requested, add the startIndex
    this.addStartIndex(startIndex);
  }

  addStartIndex(startIndex) {
    if (startIndex !== undefined) {
      // Note: for now we just overwrite the metadata. If we had more complex metadata,
      // we might need to do an object append here:  metadata = { ...metadata, startIndex }
      this.child[this.child.length - 1][METADATA_SYMBOL] = { startIndex };
    }
  }

  addEndIndex(endIndex) {
    const lastChild = this.child[this.child.length - 1];
    // endIndex is write-once: when updateTag drops a node, the last child is a
    // previously completed sibling whose endIndex must not be overwritten
    if (lastChild !== undefined && lastChild[METADATA_SYMBOL] !== undefined
      && lastChild[METADATA_SYMBOL].endIndex === undefined) {
      lastChild[METADATA_SYMBOL].endIndex = endIndex;
    }
  }
  /** symbol used for metadata */
  static getMetaDataSymbol() {
    return METADATA_SYMBOL;
  }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/xml-naming@0.3.0/node_modules/xml-naming/src/index.js
/**
 * xml-naming
 * Validates XML Name productions as defined in the XML 1.0 and 1.1 specifications.
 * Covers: Name, NCName, QName, NMToken, NMTokens
 *
 * XML 1.0 spec: https://www.w3.org/TR/xml/#NT-Name
 * XML 1.1 spec: https://www.w3.org/TR/xml11/#NT-NameStartChar
 * XML NS spec:  https://www.w3.org/TR/xml-names/#NT-NCName
 */

// ---------------------------------------------------------------------------
// Character class strings — XML 1.0
//
// NameStartChar ::= ":" | [A-Z] | "_" | [a-z]
//   | [#xC0-#xD6]   | [#xD8-#xF6]   | [#xF8-#x2FF]
//   | [#x370-#x37D] | [#x37F-#x1FFF]    <- split to exclude #x0487
//   | [#x200C-#x200D]
//   | [#x2070-#x218F] | [#x2C00-#x2FEF]
//   | [#x3001-#xD7FF] | [#xF900-#xFDCF] | [#xFDF0-#xFFFD]
//
// NameChar ::= NameStartChar | "-" | "." | [0-9]
//   | #xB7 | [#x0300-#x036F] | [#x203F-#x2040]
//
// Note: \u0487 (Combining Cyrillic Millions Sign) was added in Unicode 4.0,
// after XML 1.0 was defined against Unicode 2.0. It falls inside the range
// \u037F-\u1FFF but must be excluded. We split that range into
// \u037F-\u0486 and \u0488-\u1FFF to exclude it explicitly.
// ---------------------------------------------------------------------------

const nameStartChar10 =
  ':A-Za-z_' +
  '\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF' +
  '\u0370-\u037D' +
  '\u037F-\u0486\u0488-\u1FFF' +  // split to exclude \u0487
  '\u200C-\u200D' +
  '\u2070-\u218F' +
  '\u2C00-\u2FEF' +
  '\u3001-\uD7FF' +
  '\uF900-\uFDCF' +
  '\uFDF0-\uFFFD';

const nameChar10 =
  nameStartChar10 +
  '\\-\\.\\d' +
  '\u00B7' +
  '\u0300-\u036F' +
  '\u203F-\u2040';

// ---------------------------------------------------------------------------
// Character class strings — XML 1.1
//
// Differences from XML 1.0:
//
// NameStartChar:
//   1.0 has split ranges: \u00C0-\u00D6, \u00D8-\u00F6, \u00F8-\u02FF
//   1.1 merges them into: \u00C0-\u02FF
//   (\u00D7 x and \u00F7 / are division symbols, excluded in both versions)
//
//   1.0 tops out at \uFFFD (BMP only)
//   1.1 adds \u{10000}-\u{EFFFF} (supplementary planes)
//   These require the /u flag on the RegExp — see buildRegexes below.
//
// NameChar:
//   1.1 adds \u0487 (Combining Cyrillic Millions Sign, added in Unicode 4.0)
// ---------------------------------------------------------------------------

const nameStartChar11 =
  ':A-Za-z_' +
  '\u00C0-\u02FF' +                    // merged — 1.0 had three split ranges here
  '\u0370-\u037D' +
  '\u037F-\u0486\u0488-\u1FFF' +       // split to exclude \u0487 (combining mark, never a NameStartChar)
  '\u200C-\u200D' +
  '\u2070-\u218F' +
  '\u2C00-\u2FEF' +
  '\u3001-\uD7FF' +
  '\uF900-\uFDCF' +
  '\uFDF0-\uFFFD' +
  '\u{10000}-\u{EFFFF}';     // supplementary planes — REQUIRES /u flag on RegExp

const nameChar11 =
  nameStartChar11 +
  '\\-\\.\\d' +
  '\u00B7' +
  '\u0300-\u036F' +
  '\u0487' +                 // Combining Cyrillic Millions Sign — valid in 1.1, not 1.0
  '\u203F-\u2040';

// ---------------------------------------------------------------------------
// Regex builders
//
// XML 1.0 regexes: no flags — BMP only, standard JS regex behaviour.
// XML 1.1 regexes: /u flag — required for \u{10000}-\u{EFFFF} to match actual
//   supplementary code points rather than lone surrogates (which are illegal XML).
// ---------------------------------------------------------------------------

const buildRegexes = (startChar, char, flags = '') => {
  const ncStart = startChar.replace(':', '');
  const ncChar = char.replace(':', '');
  const ncNamePat = `[${ncStart}][${ncChar}]*`;

  return {
    name: new RegExp(`^[${startChar}][${char}]*$`, flags),
    ncName: new RegExp(`^${ncNamePat}$`, flags),
    qName: new RegExp(`^${ncNamePat}(?::${ncNamePat})?$`, flags),
    nmToken: new RegExp(`^[${char}]+$`, flags),
    nmTokens: new RegExp(`^[${char}]+(?:\\s+[${char}]+)*$`, flags),
  };
};

const regexes10 = buildRegexes(nameStartChar10, nameChar10);       // no /u — BMP only
const regexes11 = buildRegexes(nameStartChar11, nameChar11, 'u');  // /u — enables \u{10000}-\u{EFFFF}

// ---------------------------------------------------------------------------
// ASCII-only fast path (opt-in, off by default)
//
// The XML 1.0 vs 1.1 NameStartChar/NameChar productions differ *only* in
// their non-ASCII ranges (merged vs split Latin-1 ranges, \u0487, and
// supplementary planes). Restricted to ASCII, both versions collapse to the
// same character classes, so a single regex pair covers both xmlVersion
// values — no /u flag needed.
//
// Rationale: unicode-aware regexes (the /u flag, required for XML 1.1's
// supplementary-plane range) are measurably slower in V8 than plain
// non-unicode regexes on the same input, even when the input is pure ASCII.
// For the common case — HTML/SVG ids, XML tags — names are ASCII, so callers
// who know this can opt in to skip the unicode-aware matching path entirely.
// This is a real but *conditional* win: mainly for XML 1.1 input (avoids /u),
// or at scale where the larger unicode character classes add engine
// overhead. It also changes behaviour (rejects legitimate non-ASCII XML
// 1.0/1.1 names), so it must never be silently enabled — hence off by
// default.
// ---------------------------------------------------------------------------

const nameStartCharAscii = ':A-Za-z_';
const nameCharAscii = nameStartCharAscii + '\\-\\.\\d';

const regexesAscii = buildRegexes(nameStartCharAscii, nameCharAscii); // no /u — ASCII only

const getRegexes = (xmlVersion = '1.0', asciiOnly = false) => {
  if (asciiOnly) return regexesAscii;
  return xmlVersion === '1.1' ? regexes11 : regexes10;
};

// ---------------------------------------------------------------------------
// Boolean validators
// ---------------------------------------------------------------------------

/**
 * Returns true if the string is a valid XML Name.
 * Colons are allowed anywhere (Name production).
 * Used for: DOCTYPE entity names, notation names, DTD element declarations.
 *
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean }} [opts]
 *   asciiOnly: skip unicode-aware matching, ASCII names only (default false).
 */
const src_name = (str, { xmlVersion = '1.0', asciiOnly = false } = {}) =>
  getRegexes(xmlVersion, asciiOnly).name.test(str);

/**
 * Returns true if the string is a valid NCName (Non-Colonized Name).
 * Colons are not permitted.
 * Used for: namespace prefixes, local names, SVG id attributes.
 *
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean }} [opts]
 *   asciiOnly: skip unicode-aware matching, ASCII names only (default false).
 */
const ncName = (str, { xmlVersion = '1.0', asciiOnly = false } = {}) =>
  getRegexes(xmlVersion, asciiOnly).ncName.test(str);

/**
 * Returns true if the string is a valid QName (Qualified Name).
 * Allows exactly one colon as a prefix separator: prefix:localName.
 * Used for: element and attribute names in namespace-aware XML/SVG.
 *
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean }} [opts]
 *   asciiOnly: skip unicode-aware matching, ASCII names only (default false).
 */
const qName = (str, { xmlVersion = '1.0', asciiOnly = false } = {}) =>
  getRegexes(xmlVersion, asciiOnly).qName.test(str);

/**
 * Returns true if the string is a valid NMToken.
 * Like Name but no restriction on the first character.
 * Used for: DTD NMTOKEN attribute values.
 *
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean }} [opts]
 *   asciiOnly: skip unicode-aware matching, ASCII names only (default false).
 */
const nmToken = (str, { xmlVersion = '1.0', asciiOnly = false } = {}) =>
  getRegexes(xmlVersion, asciiOnly).nmToken.test(str);

/**
 * Returns true if the string is a valid NMTokens value.
 * A whitespace-separated list of NMToken values.
 * Used for: DTD NMTOKENS attribute values.
 *
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean }} [opts]
 *   asciiOnly: skip unicode-aware matching, ASCII names only (default false).
 */
const nmTokens = (str, { xmlVersion = '1.0', asciiOnly = false } = {}) =>
  getRegexes(xmlVersion, asciiOnly).nmTokens.test(str);

// ---------------------------------------------------------------------------
// Memoized validator factory
//
// Real documents reuse a small vocabulary of tag/attribute names across many
// siblings (e.g. `id`, `class`, `href` repeated across hundreds of elements).
// The plain boolean validators above re-run the regex on every call
// regardless of repeats. `createValidator` returns a closure with a private
// string -> boolean cache, so repeated names after the first become O(1)
// lookups instead of regex tests.
//
// - opts (xmlVersion, asciiOnly) are fixed at creation time, so the regex is
//   resolved once, not on every call.
// - The cache is private to the returned closure — no shared/global state,
//   no cross-caller pollution.
// - `maxCacheSize` bounds memory: once the cache reaches this many entries,
//   it stops accepting new ones (existing entries keep serving hits; new
//   misses just fall through to the regex, uncached). This avoids unbounded
//   growth against adversarial/high-cardinality input (e.g. validating
//   attacker-supplied names with no repeats) without the cost/complexity of
//   a full LRU, and without the perf cliff of reset-and-refill thrashing.
// - Call `.reset()` on the returned function to clear the cache manually
//   (e.g. between unrelated parse calls).
// ---------------------------------------------------------------------------

const PRODUCTIONS = (/* unused pure expression or super */ null && (['name', 'ncName', 'qName', 'nmToken', 'nmTokens']));

/**
 * Returns a memoized boolean validator function for a single production,
 * with opts fixed at creation time.
 *
 * @param {'name'|'ncName'|'qName'|'nmToken'|'nmTokens'} production
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean, maxCacheSize?: number }} [opts]
 *   maxCacheSize: max number of distinct strings to cache (default 2048).
 *   Once reached, new strings are validated but not cached; existing cached
 *   entries keep being served.
 * @returns {((str: string) => boolean) & { reset: () => void }}
 */
const createValidator = (production, { xmlVersion = '1.0', asciiOnly = false, maxCacheSize = 2048 } = {}) => {
  if (!PRODUCTIONS.includes(production)) {
    throw new TypeError(
      `Unknown production "${production}". Must be one of: ${PRODUCTIONS.join(', ')}`
    );
  }

  const regex = getRegexes(xmlVersion, asciiOnly)[production];
  let cache = new Map();

  const validator = (str) => {
    const cached = cache.get(str);
    if (cached !== undefined) return cached;

    const result = regex.test(str);
    if (cache.size < maxCacheSize) cache.set(str, result);
    return result;
  };

  validator.reset = () => { cache = new Map(); };

  return validator;
};

// ---------------------------------------------------------------------------
// Diagnostic validator
// ---------------------------------------------------------------------------

/**
 * Validates a string against a named production and returns a detailed result.
 *
 * @param {string} str
 * @param {'name'|'ncName'|'qName'|'nmToken'|'nmTokens'} production
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean }} [opts]
 * @returns {{ valid: boolean, production: string, input: string, reason?: string, position?: number }}
 */
const src_validate = (str, production, { xmlVersion = '1.0', asciiOnly = false } = {}) => {
  if (!PRODUCTIONS.includes(production)) {
    throw new TypeError(
      `Unknown production "${production}". Must be one of: ${PRODUCTIONS.join(', ')}`
    );
  }

  const validators = { name: src_name, ncName, qName, nmToken, nmTokens };
  const isValid = validators[production](str, { xmlVersion, asciiOnly });

  if (isValid) return { valid: true, production, input: str };

  let reason = 'Does not match the production rules';
  let position;

  // Diagnostic fallback char checks must mirror the same character set the
  // boolean validator above used, or the reported reason/position could
  // contradict the `valid: false` result (e.g. flagging a char as illegal
  // that the unicode-aware check would have accepted).
  const startCharPattern = asciiOnly ? /^[:A-Za-z_]/ : /^[:A-Za-z_\u00C0-\uFFFD]/;
  const namePattern = asciiOnly ? /[\w\-\\.:]/ : /[\w\-\\.:\u00B7\u00C0-\uFFFD]/;

  if (str.length === 0) {
    reason = 'Input is empty';
  } else if (production === 'ncName' && str.includes(':')) {
    position = str.indexOf(':');
    reason = 'Colon is not allowed in NCName';
  } else if (production === 'qName' && str.startsWith(':')) {
    reason = 'QName cannot start with a colon';
    position = 0;
  } else if (production === 'qName' && str.endsWith(':')) {
    reason = 'QName cannot end with a colon';
    position = str.length - 1;
  } else if (production === 'qName' && (str.match(/:/g) || []).length > 1) {
    reason = 'QName can have at most one colon';
    position = str.lastIndexOf(':');
  } else if (
    ['name', 'ncName', 'qName'].includes(production) &&
    !startCharPattern.test(str[0])
  ) {
    reason = `First character "${str[0]}" is not a valid NameStartChar`;
    position = 0;
  } else {
    for (let i = 0; i < str.length; i++) {
      if (!namePattern.test(str[i])) {
        reason = `Character "${str[i]}" at position ${i} is not a valid NameChar`;
        position = i;
        break;
      }
    }
  }

  return { valid: false, production, input: str, reason, position };
};

// ---------------------------------------------------------------------------
// Batch validator
// ---------------------------------------------------------------------------

/**
 * Validates an array of strings against a named production.
 *
 * @param {string[]} strings
 * @param {'name'|'ncName'|'qName'|'nmToken'|'nmTokens'} production
 * @param {{ xmlVersion?: '1.0'|'1.1', asciiOnly?: boolean }} [opts]
 * @returns {Array<{ valid: boolean, production: string, input: string, reason?: string, position?: number }>}
 */
const validateAll = (strings, production, opts = {}) =>
  strings.map(str => src_validate(str, production, opts));

// ---------------------------------------------------------------------------
// Sanitizer
// ---------------------------------------------------------------------------

/**
 * Transforms an invalid string into the nearest valid XML name for the given production.
 *
 * @param {string} str
 * @param {'name'|'ncName'|'qName'|'nmToken'|'nmTokens'} production
 * @param {{ replacement?: string, asciiOnly?: boolean }} [opts]
 *   asciiOnly: also replace any non-ASCII character, not just XML-illegal
 *   ones (default false).
 * @returns {string}
 */
const sanitize = (str, production = 'name', { replacement = '_', asciiOnly = false } = {}) => {
  if (!str) return replacement;

  let result = str;

  // Strip colons for NCName
  if (production === 'ncName') {
    result = result.replace(/:/g, '');
  }

  // Replace illegal characters
  const allowedCharPattern = asciiOnly ? /[^\w\-\.:]/g : /[^\w\-\.:\u00B7\u00C0-\uFFFD]/g;
  result = result.replace(allowedCharPattern, replacement);

  // Fix invalid start character for Name / NCName / QName
  if (production !== 'nmToken' && production !== 'nmTokens') {
    if (/^[\-\.\d]/.test(result)) {
      result = replacement + result;
    }
  }

  return result || replacement;
};
;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js


class DocTypeReader {
    constructor(options, xmlVersion) {
        this.suppressValidationErr = !options;
        this.options = options;
        this.xmlVersion = xmlVersion || 1.0;
    }

    setXmlVersion(xmlVersion = 1.0) {
        this.xmlVersion = xmlVersion;
    }
    readDocType(xmlData, i) {
        const entities = Object.create(null);
        let entityCount = 0;

        if (xmlData[i + 3] === 'O' &&
            xmlData[i + 4] === 'C' &&
            xmlData[i + 5] === 'T' &&
            xmlData[i + 6] === 'Y' &&
            xmlData[i + 7] === 'P' &&
            xmlData[i + 8] === 'E') {
            i = i + 9;
            let angleBracketsCount = 1;
            let hasBody = false, comment = false;
            let quoteChar = null; // tracks an open SYSTEM/PUBLIC literal before the '[' body
            let exp = "";
            for (; i < xmlData.length; i++) {
                // Inside a quoted external-identifier literal — XML allows '<'
                // and '>' as plain data here, so they must not be interpreted
                // as DOCTYPE structure until the matching quote closes.
                if (quoteChar !== null) {
                    if (xmlData[i] === quoteChar) quoteChar = null;
                    exp += xmlData[i];
                    continue;
                }
                if (!hasBody && !comment && (xmlData[i] === '"' || xmlData[i] === "'")) {
                    quoteChar = xmlData[i];
                    exp += xmlData[i];
                    continue;
                }

                if (xmlData[i] === '<' && !comment) { //Determine the tag type
                    if (hasBody && hasSeq(xmlData, "!ENTITY", i)) {
                        i += 7;
                        let entityName, val;
                        [entityName, val, i] = this.readEntityExp(xmlData, i + 1, this.suppressValidationErr);
                        if (val.indexOf("&") === -1) { //Parameter entities are not supported
                            if (this.options.enabled !== false &&
                                this.options.maxEntityCount != null &&
                                entityCount >= this.options.maxEntityCount) {
                                throw new Error(
                                    `Entity count (${entityCount + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`
                                );
                            }
                            //const escaped = entityName.replace(/[.\-+*:]/g, '\\.');
                            //const escaped = entityName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                            entities[entityName] = val;
                            entityCount++;
                        }
                    }
                    else if (hasBody && hasSeq(xmlData, "!ELEMENT", i)) {
                        i += 8;//Not supported
                        const { index } = this.readElementExp(xmlData, i + 1);
                        i = index;
                    } else if (hasBody && hasSeq(xmlData, "!ATTLIST", i)) {
                        i += 8;//Not supported
                        // const {index} = this.readAttlistExp(xmlData,i+1);
                        // i = index;
                    } else if (hasBody && hasSeq(xmlData, "!NOTATION", i)) {
                        i += 9;//Not supported
                        const { index } = this.readNotationExp(xmlData, i + 1, this.suppressValidationErr);
                        i = index;
                    } else if (hasSeq(xmlData, "!--", i)) comment = true;
                    else throw new Error(`Invalid DOCTYPE`);

                    angleBracketsCount++;
                    exp = "";
                } else if (xmlData[i] === '>') { //Read tag content
                    if (comment) {
                        if (xmlData[i - 1] === "-" && xmlData[i - 2] === "-") {
                            comment = false;
                            angleBracketsCount--;
                        }
                    } else {
                        angleBracketsCount--;
                    }
                    if (angleBracketsCount === 0) {
                        break;
                    }
                } else if (xmlData[i] === '[') {
                    hasBody = true;
                } else {
                    exp += xmlData[i];
                }
            }
            if (quoteChar !== null || angleBracketsCount !== 0) {
                throw new Error(`Unclosed DOCTYPE`);
            }
        } else {
            throw new Error(`Invalid Tag instead of DOCTYPE`);
        }
        return { entities, i };
    }
    readEntityExp(xmlData, i) {
        //External entities are not supported
        //    <!ENTITY ext SYSTEM "http://normal-website.com" >

        //Parameter entities are not supported
        //    <!ENTITY entityname "&anotherElement;">

        //Internal entities are supported
        //    <!ENTITY entityname "replacement text">

        // Skip leading whitespace after <!ENTITY
        i = skipWhitespace(xmlData, i);

        // Read entity name
        const startIndex = i;
        while (i < xmlData.length && !/\s/.test(xmlData[i]) && xmlData[i] !== '"' && xmlData[i] !== "'") {
            i++;
        }
        let entityName = xmlData.substring(startIndex, i);

        validateEntityName(entityName, { xmlVersion: this.xmlVersion });

        // Skip whitespace after entity name
        i = skipWhitespace(xmlData, i);

        // Check for unsupported constructs (external entities or parameter entities)
        if (!this.suppressValidationErr) {
            if (xmlData.substring(i, i + 6).toUpperCase() === "SYSTEM") {
                throw new Error("External entities are not supported");
            } else if (xmlData[i] === "%") {
                throw new Error("Parameter entities are not supported");
            }
        }

        // Read entity value (internal entity)
        let entityValue = "";
        [i, entityValue] = this.readIdentifierVal(xmlData, i, "entity");

        // Validate entity size
        if (this.options.enabled !== false &&
            this.options.maxEntitySize != null &&
            entityValue.length > this.options.maxEntitySize) {
            throw new Error(
                `Entity "${entityName}" size (${entityValue.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`
            );
        }

        i--;
        return [entityName, entityValue, i];
    }

    readNotationExp(xmlData, i) {
        // Skip leading whitespace after <!NOTATION
        i = skipWhitespace(xmlData, i);

        // Read notation name

        const startIndex = i;
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
            i++;
        }
        let notationName = xmlData.substring(startIndex, i);

        !this.suppressValidationErr && validateEntityName(notationName, { xmlVersion: this.xmlVersion });

        // Skip whitespace after notation name
        i = skipWhitespace(xmlData, i);

        // Check identifier type (SYSTEM or PUBLIC)
        const identifierType = xmlData.substring(i, i + 6).toUpperCase();
        if (!this.suppressValidationErr && identifierType !== "SYSTEM" && identifierType !== "PUBLIC") {
            throw new Error(`Expected SYSTEM or PUBLIC, found "${identifierType}"`);
        }
        i += identifierType.length;

        // Skip whitespace after identifier type
        i = skipWhitespace(xmlData, i);

        // Read public identifier (if PUBLIC)
        let publicIdentifier = null;
        let systemIdentifier = null;

        if (identifierType === "PUBLIC") {
            [i, publicIdentifier] = this.readIdentifierVal(xmlData, i, "publicIdentifier");

            // Skip whitespace after public identifier
            i = skipWhitespace(xmlData, i);

            // Optionally read system identifier
            if (xmlData[i] === '"' || xmlData[i] === "'") {
                [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
            }
        } else if (identifierType === "SYSTEM") {
            // Read system identifier (mandatory for SYSTEM)
            [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");

            if (!this.suppressValidationErr && !systemIdentifier) {
                throw new Error("Missing mandatory system identifier for SYSTEM notation");
            }
        }

        return { notationName, publicIdentifier, systemIdentifier, index: --i };
    }

    readIdentifierVal(xmlData, i, type) {
        let identifierVal = "";
        const startChar = xmlData[i];
        if (startChar !== '"' && startChar !== "'") {
            throw new Error(`Expected quoted string, found "${startChar}"`);
        }
        i++;

        const startIndex = i;
        while (i < xmlData.length && xmlData[i] !== startChar) {
            i++;
        }
        identifierVal = xmlData.substring(startIndex, i);

        if (xmlData[i] !== startChar) {
            throw new Error(`Unterminated ${type} value`);
        }
        i++;
        return [i, identifierVal];
    }

    readElementExp(xmlData, i) {
        // <!ELEMENT br EMPTY>
        // <!ELEMENT div ANY>
        // <!ELEMENT title (#PCDATA)>
        // <!ELEMENT book (title, author+)>
        // <!ELEMENT name (content-model)>

        // Skip leading whitespace after <!ELEMENT
        i = skipWhitespace(xmlData, i);

        // Read element name
        const startIndex = i;
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
            i++;
        }
        let elementName = xmlData.substring(startIndex, i);

        // Validate element name
        if (!this.suppressValidationErr && !qName(elementName, { xmlVersion: this.xmlVersion })) {
            throw new Error(`Invalid element name: "${elementName}"`);
        }

        // Skip whitespace after element name
        i = skipWhitespace(xmlData, i);
        let contentModel = "";
        // Expect '(' to start content model
        if (xmlData[i] === "E" && hasSeq(xmlData, "MPTY", i)) i += 4;
        else if (xmlData[i] === "A" && hasSeq(xmlData, "NY", i)) i += 2;
        else if (xmlData[i] === "(") {
            i++; // Move past '('

            // Read content model
            const startIndex = i;
            while (i < xmlData.length && xmlData[i] !== ")") {
                i++;
            }
            contentModel = xmlData.substring(startIndex, i);

            if (xmlData[i] !== ")") {
                throw new Error("Unterminated content model");
            }

        } else if (!this.suppressValidationErr) {
            throw new Error(`Invalid Element Expression, found "${xmlData[i]}"`);
        }

        return {
            elementName,
            contentModel: contentModel.trim(),
            index: i
        };
    }

    readAttlistExp(xmlData, i) {
        // Skip leading whitespace after <!ATTLIST
        i = skipWhitespace(xmlData, i);

        // Read element name
        let startIndex = i;
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
            i++;
        }
        let elementName = xmlData.substring(startIndex, i);

        // Validate element name
        validateEntityName(elementName, { xmlVersion: this.xmlVersion })

        // Skip whitespace after element name
        i = skipWhitespace(xmlData, i);

        // Read attribute name
        startIndex = i;
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
            i++;
        }
        let attributeName = xmlData.substring(startIndex, i);

        // Validate attribute name
        if (!validateEntityName(attributeName, { xmlVersion: this.xmlVersion })) {
            throw new Error(`Invalid attribute name: "${attributeName}"`);
        }

        // Skip whitespace after attribute name
        i = skipWhitespace(xmlData, i);

        // Read attribute type
        let attributeType = "";
        if (xmlData.substring(i, i + 8).toUpperCase() === "NOTATION") {
            attributeType = "NOTATION";
            i += 8; // Move past "NOTATION"

            // Skip whitespace after "NOTATION"
            i = skipWhitespace(xmlData, i);

            // Expect '(' to start the list of notations
            if (xmlData[i] !== "(") {
                throw new Error(`Expected '(', found "${xmlData[i]}"`);
            }
            i++; // Move past '('

            // Read the list of allowed notations
            let allowedNotations = [];
            while (i < xmlData.length && xmlData[i] !== ")") {


                const startIndex = i;
                while (i < xmlData.length && xmlData[i] !== "|" && xmlData[i] !== ")") {
                    i++;
                }
                let notation = xmlData.substring(startIndex, i);

                // Validate notation name
                notation = notation.trim();
                if (!validateEntityName(notation, { xmlVersion: this.xmlVersion })) {
                    throw new Error(`Invalid notation name: "${notation}"`);
                }

                allowedNotations.push(notation);

                // Skip '|' separator or exit loop
                if (xmlData[i] === "|") {
                    i++; // Move past '|'
                    i = skipWhitespace(xmlData, i); // Skip optional whitespace after '|'
                }
            }

            if (xmlData[i] !== ")") {
                throw new Error("Unterminated list of notations");
            }
            i++; // Move past ')'

            // Store the allowed notations as part of the attribute type
            attributeType += " (" + allowedNotations.join("|") + ")";
        } else {
            // Handle simple types (e.g., CDATA, ID, IDREF, etc.)
            const startIndex = i;
            while (i < xmlData.length && !/\s/.test(xmlData[i])) {
                i++;
            }
            attributeType += xmlData.substring(startIndex, i);

            // Validate simple attribute type
            const validTypes = ["CDATA", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NMTOKEN", "NMTOKENS"];
            if (!this.suppressValidationErr && !validTypes.includes(attributeType.toUpperCase())) {
                throw new Error(`Invalid attribute type: "${attributeType}"`);
            }
        }

        // Skip whitespace after attribute type
        i = skipWhitespace(xmlData, i);

        // Read default value
        let defaultValue = "";
        if (xmlData.substring(i, i + 8).toUpperCase() === "#REQUIRED") {
            defaultValue = "#REQUIRED";
            i += 8;
        } else if (xmlData.substring(i, i + 7).toUpperCase() === "#IMPLIED") {
            defaultValue = "#IMPLIED";
            i += 7;
        } else {
            [i, defaultValue] = this.readIdentifierVal(xmlData, i, "ATTLIST");
        }

        return {
            elementName,
            attributeName,
            attributeType,
            defaultValue,
            index: i
        }
    }
}



const skipWhitespace = (data, index) => {
    while (index < data.length && /\s/.test(data[index])) {
        index++;
    }
    return index;
};



function hasSeq(data, seq, i) {
    for (let j = 0; j < seq.length; j++) {
        if (seq[j] !== data[i + j + 1]) return false;
    }
    return true;
}

function validateEntityName(name, xmlVersion) {
    if (qName(name, { xmlVersion: xmlVersion }))
        return name;
    else
        throw new Error(`Invalid entity name ${name}`);
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/anynum@1.0.1/node_modules/anynum/digitTable.js
/**
 * Flat lookup table: maps Unicode code point → ASCII digit (0-9).
 * Only decimal digit characters (Unicode category Nd) are included.
 *
 * Strategy: Int32Array of size (maxCodePoint - minCodePoint + 1).
 * Value 0xFF means "not a digit". Value 0-9 is the ASCII digit value.
 * This gives O(1) lookup with no branching, no bisect, no loop.
 *
 * Memory: range is 0x0660 to 0x1FBF0 → ~129,936 entries × 1 byte = ~127 KB.
 * Acceptable for a one-time init; lookup is a single array index.
 */

// All known Unicode Nd (decimal digit) script zero code points.
// Each script has exactly 10 consecutive digits: zero+0 .. zero+9.
const SCRIPT_ZEROS = [
  // Basic Latin (ASCII) — included for completeness / pass-through
  0x0030, // 0-9

  // Arabic scripts
  0x0660, // Arabic-Indic ٠١٢٣٤٥٦٧٨٩
  0x06F0, // Extended Arabic-Indic (Urdu/Persian/Sindhi) ۰۱۲۳

  // Indic scripts
  0x0966, // Devanagari ०१२३४५६७८९
  0x09E6, // Bengali ০১২৩৪৫৬৭৮৯
  0x0A66, // Gurmukhi ੦੧੨੩੪੫੬੭੮੯
  0x0AE6, // Gujarati ૦૧૨૩૪૫૬૭૮૯
  0x0B66, // Odia ୦୧୨୩୪୫୬୭୮୯
  0x0BE6, // Tamil ௦௧௨௩௪௫௬௭௮௯
  0x0C66, // Telugu ౦౧౨౩౪౫౬౭౮౯
  0x0CE6, // Kannada ೦೧೨೩೪೫೬೭೮೯
  0x0D66, // Malayalam ൦൧൨൩൪൫൬൭൮൯
  0x0DE6, // Sinhala Archaic ෦෧෨෩෪෫෬෭෮෯

  // Southeast Asian scripts
  0x0E50, // Thai ๐๑๒๓๔๕๖๗๘๙
  0x0ED0, // Lao ໐໑໒໓໔໕໖໗໘໙
  0x0F20, // Tibetan ༠༡༢༣༤༥༦༧༨༩
  0x1040, // Myanmar ၀၁၂၃၄၅၆၇၈၉
  0x1090, // Myanmar Shan ႐႑႒႓႔႕႖႗႘႙
  0x17E0, // Khmer ០១២៣៤៥៦៧៨៩
  0x1810, // Mongolian ᠐᠑᠒᠓᠔᠕᠖᠗᠘᠙
  0x1946, // Limbu ᥆᥇᥈᥉᥊᥋᥌᥍᥎᥏
  0x19D0, // New Tai Lue ᧐᧑᧒᧓᧔᧕᧖᧗᧘᧙
  0x1A80, // Tai Tham Hora ᪀᪁᪂᪃᪄᪅᪆᪇᪈᪉
  0x1A90, // Tai Tham Tham ᪐᪑᪒᪓᪔᪕᪖᪗᪘᪙
  0x1B50, // Balinese ᭐᭑᭒᭓᭔᭕᭖᭗᭘᭙
  0x1BB0, // Sundanese ᮰᮱᮲᮳᮴᮵᮶᮷᮸᮹
  0x1C40, // Lepcha ᱀᱁᱂᱃᱄᱅᱆᱇᱈᱉
  0x1C50, // Ol Chiki ᱐᱑᱒᱓᱔᱕᱖᱗᱘᱙

  // Fullwidth (CJK context)
  0xFF10, // Fullwidth ０１２３４５６７８９

  // Mathematical digit variants (Unicode math block)
  0x1D7CE, // Mathematical Bold
  0x1D7D8, // Mathematical Double-Struck
  0x1D7E2, // Mathematical Sans-Serif
  0x1D7EC, // Mathematical Sans-Serif Bold
  0x1D7F6, // Mathematical Monospace

  // Other scripts
  0x104A0, // Osmanya 𐒠𐒡𐒢𐒣𐒤𐒥𐒦𐒧𐒨𐒩
  0x10D30, // Hanifi Rohingya 𐴰𐴱𐴲𐴳𐴴𐴵𐴶𐴷𐴸𐴹
  0x11066, // Brahmi 𑁦𑁧𑁨𑁩𑁪𑁫𑁬𑁭𑁮𑁯
  0x110F0, // Sora Sompeng 𑃰𑃱𑃲𑃳𑃴𑃵𑃶𑃷𑃸𑃹
  0x11136, // Chakma 𑄶𑄷𑄸𑄹𑄺𑄻𑄼𑄽𑄾𑄿
  0x111D0, // Sharada 𑇐𑇑𑇒𑇓𑇔𑇕𑇖𑇗𑇘𑇙
  0x112F0, // Khudawadi 𑋰𑋱𑋲𑋳𑋴𑋵𑋶𑋷𑋸𑋹
  0x11450, // Newa 𑑐𑑑𑑒𑑓𑑔𑑕𑑖𑑗𑑘𑑙
  0x114D0, // Tirhuta 𑓐𑓑𑓒𑓓𑓔𑓕𑓖𑓗𑓘𑓙
  0x11650, // Modi 𑙐𑙑𑙒𑙓𑙔𑙕𑙖𑙗𑙘𑙙
  0x116C0, // Takri 𑛀𑛁𑛂𑛃𑛄𑛅𑛆𑛇𑛈𑛉
  0x11730, // Ahom 𑜰𑜱𑜲𑜳𑜴𑜵𑜶𑜷𑜸𑜹
  0x118E0, // Warang Citi 𑣠𑣡𑣢𑣣𑣤𑣥𑣦𑣧𑣨𑣩
  0x11950, // Dives Akuru 𑥐𑥑𑥒𑥓𑥔𑥕𑥖𑥗𑥘𑥙
  0x11BF0, // Khitan Small Script 𑯰𑯱𑯲𑯳𑯴𑯵𑯶𑯷𑯸𑯹
  0x11C50, // Bhaiksuki 𑱐𑱑𑱒𑱓𑱔𑱕𑱖𑱗𑱘𑱙
  0x11D50, // Masaram Gondi 𑵐𑵑𑵒𑵓𑵔𑵕𑵖𑵗𑵘𑵙
  0x11DA0, // Gunjala Gondi 𑶠𑶡𑶢𑶣𑶤𑶥𑶦𑶧𑶨𑶩
  0x11F50, // Kawi 𑽐𑽑𑽒𑽓𑽔𑽕𑽖𑽗𑽘𑽙
  0x16A60, // Mro 𖩠𖩡𖩢𖩣𖩤𖩥𖩦𖩧𖩨𖩩
  0x16AC0, // Tangsa 𖫀𖫁𖫂𖫃𖫄𖫅𖫆𖫇𖫈𖫉
  0x16B50, // Pahawh Hmong 𖭐𖭑𖭒𖭓𖭔𖭕𖭖𖭗𖭘𖭙
  0x1E140, // Nyiakeng Puachue Hmong 𞅀𞅁𞅂𞅃𞅄𞅅𞅆𞅇𞅈𞅉
  0x1E2F0, // Wancho 𞋰𞋱𞋲𞋳𞋴𞋵𞋶𞋷𞋸𞋹
  0x1E4F0, // Nag Mundari 𞓰𞓱𞓲𞓳𞓴𞓵𞓶𞓷𞓸𞓹
  0x1E950, // Adlam 𞥐𞥑𞥒𞥓𞥔𞥕𞥖𞥗𞥘𞥙
  0x1FBF0, // Segmented digit symbols 🯰🯱🯲🯳🯴🯵🯶🯷🯸🯹
];

// Build a sparse Map for scripts above 0xFFFF (surrogate-pair range).
// These can't go into a flat Uint8Array indexed by code point efficiently.
const NOT_DIGIT = 0xFF;
const HIGH_MAP = new Map(); // codePoint → digit value (0-9)

const LOW_MAX = 0xFFFF;
const LOW_MIN = 0x0660; // first non-ASCII digit script

// Flat Uint8Array covering 0x0660 .. 0xFFFF
const TABLE_OFFSET = LOW_MIN;
const TABLE_SIZE = LOW_MAX - LOW_MIN + 1;
const TABLE = new Uint8Array(TABLE_SIZE).fill(NOT_DIGIT);

for (const zero of SCRIPT_ZEROS) {
  for (let d = 0; d < 10; d++) {
    const cp = zero + d;
    if (cp <= LOW_MAX) {
      TABLE[cp - TABLE_OFFSET] = d;
    } else {
      HIGH_MAP.set(cp, d);
    }
  }
}



;// CONCATENATED MODULE: ./node_modules/.pnpm/anynum@1.0.1/node_modules/anynum/anynum.js




const CHAR_0 = 48; // '0'.charCodeAt(0)
const CHAR_9 = 57; // '9'.charCodeAt(0)
const CHAR_MINUS = 45; // '-'.charCodeAt(0)

// Unicode minus/hyphen variants worth normalizing to ASCII '-' in numeric context:
//   U+2212  MINUS SIGN       − (mathematically correct minus)
//   U+FF0D  FULLWIDTH HYPHEN-MINUS  － (Japanese fullwidth context)
//   U+FE63  SMALL HYPHEN-MINUS     ﹣ (small form variant)
//
// NOT normalized (deliberate):
//   U+2013  EN DASH  –  (punctuation, not a numeric sign)
//   U+2014  EM DASH  —  (punctuation)
//   U+2010  HYPHEN   ‐  (typographic hyphen)
//
// Rationale: only characters a human or locale formatter would plausibly use
// as a numeric minus sign are normalized. Dashes used for punctuation are left
// alone to avoid mangling non-numeric strings.
const MINUS_SET = new Set([0x2212, 0xFF0D, 0xFE63]);

/**
 * Normalize all Unicode decimal digit characters in a string to ASCII (0-9),
 * and normalize Unicode minus variants to ASCII '-' (U+002D).
 *
 * Non-digit, non-minus characters are passed through unchanged.
 *
 * Performance design:
 * - Fast path: if the string has no convertible characters, return it unchanged
 *   (zero allocation).
 * - BMP digits (0x0660..0xFFFF excl. surrogates): flat Uint8Array lookup (O(1)).
 * - Supplementary plane digits (> 0xFFFF, encoded as surrogate pairs): Map lookup.
 * - Minus variants: checked inline with a small fixed Set.
 *
 * @param {string} str
 * @returns {string}
 */
function anynum(str) {
  if (typeof str !== 'string') return str;

  const len = str.length;
  if (len === 0) return str;

  // Scan for first character needing conversion.
  // If none found, return original string (zero allocation).
  let firstHit = -1;

  for (let i = 0; i < len; i++) {
    const cc = str.charCodeAt(i);

    // ASCII digit or ASCII minus — already normalized, skip fast
    if ((cc >= CHAR_0 && cc <= CHAR_9) || cc === CHAR_MINUS) continue;

    // Below first unicode digit script — check minus variants only
    if (cc < (/* inlined export .TABLE_OFFSET */1632)) {
      if (MINUS_SET.has(cc)) { firstHit = i; break; }
      continue;
    }

    // Surrogate pairs live in BMP range 0xD800-0xDFFF — check before TABLE
    if (cc >= 0xD800 && cc <= 0xDBFF) {
      if (i + 1 < len) {
        const low = str.charCodeAt(i + 1);
        if (low >= 0xDC00 && low <= 0xDFFF) {
          const cp = 0x10000 + ((cc - 0xD800) << 10) + (low - 0xDC00);
          if (HIGH_MAP.has(cp)) { firstHit = i; break; }
        }
      }
      continue;
    }

    // BMP non-surrogate: flat table lookup; also check minus variants in this range
    if (TABLE[cc - (/* inlined export .TABLE_OFFSET */1632)] !== (/* inlined export .NOT_DIGIT */255) || MINUS_SET.has(cc)) {
      firstHit = i;
      break;
    }
  }

  // Nothing to replace — return original, zero allocation
  if (firstHit === -1) return str;

  // Build result: copy unchanged prefix, then convert from firstHit onward
  const chars = [];

  if (firstHit > 0) chars.push(str.slice(0, firstHit));

  for (let i = firstHit; i < len; i++) {
    const cc = str.charCodeAt(i);

    // ASCII digit or ASCII minus — pass through
    if ((cc >= CHAR_0 && cc <= CHAR_9) || cc === CHAR_MINUS) {
      chars.push(str[i]);
      continue;
    }

    // Below TABLE_OFFSET — check minus variants, else pass through
    if (cc < (/* inlined export .TABLE_OFFSET */1632)) {
      chars.push(MINUS_SET.has(cc) ? '-' : str[i]);
      continue;
    }

    // Surrogate pairs
    if (cc >= 0xD800 && cc <= 0xDBFF) {
      if (i + 1 < len) {
        const low = str.charCodeAt(i + 1);
        if (low >= 0xDC00 && low <= 0xDFFF) {
          const cp = 0x10000 + ((cc - 0xD800) << 10) + (low - 0xDC00);
          const d = HIGH_MAP.get(cp);
          if (d !== undefined) {
            chars.push(String.fromCharCode(d + 48));
            i++; // consume low surrogate
            continue;
          }
        }
      }
      chars.push(str[i]);
      continue;
    }

    // BMP non-surrogate: flat table lookup + minus variants
    if (MINUS_SET.has(cc)) {
      chars.push('-');
      continue;
    }
    const d = TABLE[cc - (/* inlined export .TABLE_OFFSET */1632)];
    chars.push(d !== (/* inlined export .NOT_DIGIT */255) ? String.fromCharCode(d + 48) : str[i]);
  }

  return chars.join('');
}


/* export default */ const anynum_anynum = (anynum);
;// CONCATENATED MODULE: ./node_modules/.pnpm/strnum@2.4.2/node_modules/strnum/strnum.js
const hexRegex = /^[-+]?0x[a-fA-F0-9]+$/;
const binRegex = /^0b[01]+$/;
const octRegex = /^0o[0-7]+$/;
const numRegex = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/;



const consider = {
    hex: true,
    binary: false,
    octal: false,
    leadingZeros: true,
    decimalPoint: "\.",
    eNotation: true,
    //skipLike: /regex/,
    infinity: "original", // "null", "infinity" (Infinity type), "string" ("Infinity" (the string literal))
    unicode: false,
};

function toNumber(str, options = {}) {
    options = Object.assign({}, consider, options);
    if (!str || typeof str !== "string") return str;

    let trimmedStr = str.trim();

    if (trimmedStr.length === 0) return str;
    else if (options.skipLike !== undefined && options.skipLike.test(trimmedStr)) return str;
    else if (trimmedStr === "0") return 0;

    if (options.unicode) {
        trimmedStr = anynum_anynum(trimmedStr);
        if (trimmedStr === "0") return 0; // re-check after normalization
    }
    if (options.hex && hexRegex.test(trimmedStr)) {
        return parse_int(trimmedStr, 16);
    } else if (options.binary && binRegex.test(trimmedStr)) {
        return parse_int(trimmedStr, 2);
    } else if (options.octal && octRegex.test(trimmedStr)) {
        return parse_int(trimmedStr, 8);
    } else if (!isFinite(trimmedStr)) { //Infinity
        return handleInfinity(str, Number(trimmedStr), options);
    } else if (trimmedStr.includes('e') || trimmedStr.includes('E')) { //eNotation
        return resolveEnotation(str, trimmedStr, options);
    } else {
        //separate negative sign, leading zeros, and rest number
        const match = numRegex.exec(trimmedStr);
        // +00.123 => [ , '+', '00', '.123', ..
        if (match) {
            const sign = match[1] || "";
            const leadingZeros = match[2];
            let numTrimmedByZeros = trimZeros(match[3]); //complete num without leading zeros
            const decimalAdjacentToLeadingZeros = sign ? // 0., -00., 000.
                str[leadingZeros.length + 1] === "."
                : str[leadingZeros.length] === ".";

            //trim ending zeros for floating number
            if (!options.leadingZeros //leading zeros are not allowed
                && (leadingZeros.length > 1
                    || (leadingZeros.length === 1 && !decimalAdjacentToLeadingZeros))) {
                // 00, 00.3, +03.24, 03, 03.24
                return str;
            }
            else {//no leading zeros or leading zeros are allowed
                const num = Number(trimmedStr);
                const parsedStr = String(num);

                if (num === 0) return num;
                if (parsedStr.search(/[eE]/) !== -1) { //given number is long and parsed to eNotation
                    if (options.eNotation) return num;
                    else return str;
                } else if (trimmedStr.indexOf(".") !== -1) { //floating number
                    if (parsedStr === "0") return num; //0.0
                    else if (parsedStr === numTrimmedByZeros) return num; //0.456. 0.79000
                    else if (parsedStr === `${sign}${numTrimmedByZeros}`) return num;
                    else return str;
                }

                let n = leadingZeros ? numTrimmedByZeros : trimmedStr;
                if (leadingZeros) {
                    // -009 => -9
                    return (n === parsedStr) || (sign + n === parsedStr) ? num : str
                } else {
                    // +9
                    return (n === parsedStr) || (n === sign + parsedStr) ? num : str
                }
            }
        } else { //non-numeric string
            return str;
        }
    }
}

const eNotationRegx = /^([-+])?(0*)(\d*(\.\d*)?[eE][-\+]?\d+)$/;
function resolveEnotation(str, trimmedStr, options) {
    if (!options.eNotation) return str;
    const notation = trimmedStr.match(eNotationRegx);
    if (notation) {
        let sign = notation[1] || "";
        const eChar = notation[3].indexOf("e") === -1 ? "E" : "e";
        const leadingZeros = notation[2];
        const eAdjacentToLeadingZeros = sign ? // 0E.
            str[leadingZeros.length + 1] === eChar
            : str[leadingZeros.length] === eChar;

        if (leadingZeros.length > 1 && eAdjacentToLeadingZeros) return str;
        else if (leadingZeros.length === 1
            && (notation[3].startsWith(`.${eChar}`) || notation[3][0] === eChar)) {
            return Number(trimmedStr);
        } else if (leadingZeros.length > 0) {
            // Has leading zeros — only accept if leadingZeros option allows it
            if (options.leadingZeros && !eAdjacentToLeadingZeros) {
                trimmedStr = (notation[1] || "") + notation[3];
                return Number(trimmedStr);
            } else return str;
        } else {
            // No leading zeros — always valid e-notation, parse it
            return Number(trimmedStr);
        }
    } else {
        return str;
    }
}

/**
 * 
 * @param {string} numStr without leading zeros
 * @returns 
 */
function trimZeros(numStr) {
    if (numStr && numStr.indexOf(".") !== -1) {//float
        //remove ending zeros without the O(n^2) backtracking that /0+$/ hits
        //when the string doesn't end in 0 but has a long internal zero-run
        let end = numStr.length;
        while (end > 0 && numStr.charCodeAt(end - 1) === 48 /* '0' */) end--;
        numStr = numStr.slice(0, end);
        if (numStr === ".") numStr = "0";
        else if (numStr[0] === ".") numStr = "0" + numStr;
        else if (numStr[numStr.length - 1] === ".") numStr = numStr.substring(0, numStr.length - 1);
        return numStr;
    }
    return numStr;
}

function parse_int(numStr, base) {
    const str = numStr.trim();
    if (base === 2 || base === 8) numStr = str.substring(2);

    if (parseInt) return parseInt(numStr, base);
    else if (Number.parseInt) return Number.parseInt(numStr, base);
    else if (window && window.parseInt) return window.parseInt(numStr, base);
    else throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
}

/**
 * Handle infinite values based on user option
 * @param {string} str - original input string
 * @param {number} num - parsed number (Infinity or -Infinity)
 * @param {object} options - user options
 * @returns {string|number|null} based on infinity option
 */
function handleInfinity(str, num, options) {
    const isPositive = num === Infinity;

    switch (options.infinity.toLowerCase()) {
        case "null":
            return null;
        case "infinity":
            return num; // Return Infinity or -Infinity
        case "string":
            return isPositive ? "Infinity" : "-Infinity";
        case "original":
        default:
            return str; // Return original string like "1e1000"
    }
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/ignoreAttributes.js
function getIgnoreAttributesFn(ignoreAttributes) {
    if (typeof ignoreAttributes === 'function') {
        return ignoreAttributes
    }
    if (Array.isArray(ignoreAttributes)) {
        return (attrName) => {
            for (const pattern of ignoreAttributes) {
                if (typeof pattern === 'string' && attrName === pattern) {
                    return true
                }
                if (pattern instanceof RegExp && pattern.test(attrName)) {
                    return true
                }
            }
        }
    }
    return () => false
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/path-expression-matcher@1.6.2/node_modules/path-expression-matcher/src/Matcher.js


/**
 * MatcherView - A lightweight read-only view over a Matcher's internal state.
 *
 * Created once by Matcher and reused across all callbacks. Holds a direct
 * reference to the parent Matcher so it always reflects current parser state
 * with zero copying or freezing overhead.
 *
 * Users receive this via {@link Matcher#readOnly} or directly from parser
 * callbacks. It exposes all query and matching methods but has no mutation
 * methods — misuse is caught at the TypeScript level rather than at runtime.
 *
 * @example
 * const matcher = new Matcher();
 * const view = matcher.readOnly();
 *
 * matcher.push("root", {});
 * view.getCurrentTag(); // "root"
 * view.getDepth();      // 1
 */
class MatcherView {
  /**
   * @param {Matcher} matcher - The parent Matcher instance to read from.
   */
  constructor(matcher) {
    this._matcher = matcher;
  }

  /**
   * Get the path separator used by the parent matcher.
   * @returns {string}
   */
  get separator() {
    return this._matcher.separator;
  }

  /**
   * Get current tag name.
   * @returns {string|undefined}
   */
  getCurrentTag() {
    const path = this._matcher.path;
    return path.length > 0 ? path[path.length - 1].tag : undefined;
  }

  /**
   * Get current namespace.
   * @returns {string|undefined}
   */
  getCurrentNamespace() {
    const path = this._matcher.path;
    return path.length > 0 ? path[path.length - 1].namespace : undefined;
  }

  /**
   * Get current node's attribute value.
   * @param {string} attrName
   * @returns {*}
   */
  getAttrValue(attrName) {
    const path = this._matcher.path;
    if (path.length === 0) return undefined;
    return path[path.length - 1].values?.[attrName];
  }

  /**
   * Check if current node has an attribute.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAttr(attrName) {
    const path = this._matcher.path;
    if (path.length === 0) return false;
    const current = path[path.length - 1];
    return current.values !== undefined && attrName in current.values;
  }

  /**
   * Get the value of a "kept" attribute from the nearest ancestor (or
   * current node) that declared it via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {*}
   */
  getAnyParentAttr(attrName) {
    return this._matcher.getAnyParentAttr(attrName);
  }

  /**
   * Check whether any ancestor (or the current node) kept the given
   * attribute via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAnyParentAttr(attrName) {
    return this._matcher.hasAnyParentAttr(attrName);
  }

  /**
   * Get current node's sibling position (child index in parent).
   * @returns {number}
   */
  getPosition() {
    const path = this._matcher.path;
    if (path.length === 0) return -1;
    return path[path.length - 1].position ?? 0;
  }

  /**
   * Get current node's repeat counter (occurrence count of this tag name).
   * @returns {number}
   */
  getCounter() {
    const path = this._matcher.path;
    if (path.length === 0) return -1;
    return path[path.length - 1].counter ?? 0;
  }

  /**
   * Get current node's sibling index (alias for getPosition).
   * @returns {number}
   * @deprecated Use getPosition() or getCounter() instead
   */
  getIndex() {
    return this.getPosition();
  }

  /**
   * Get current path depth.
   * @returns {number}
   */
  getDepth() {
    return this._matcher.path.length;
  }

  /**
   * Get path as string.
   * @param {string} [separator] - Optional separator (uses default if not provided)
   * @param {boolean} [includeNamespace=true]
   * @returns {string}
   */
  toString(separator, includeNamespace = true) {
    return this._matcher.toString(separator, includeNamespace);
  }

  /**
   * Get path as array of tag names.
   * @returns {string[]}
   */
  toArray() {
    return this._matcher.path.map(n => n.tag);
  }

  /**
   * Match current path against an Expression.
   * @param {Expression} expression
   * @returns {boolean}
   */
  matches(expression) {
    return this._matcher.matches(expression);
  }

  /**
   * Match any expression in the given set against the current path.
   * @param {ExpressionSet} exprSet
   * @returns {boolean}
   */
  matchesAny(exprSet) {
    return exprSet.matchesAny(this._matcher);
  }
}

/**
 * Matcher - Tracks current path in XML/JSON tree and matches against Expressions.
 *
 * The matcher maintains a stack of nodes representing the current path from root to
 * current tag. It only stores attribute values for the current (top) node to minimize
 * memory usage. Sibling tracking is used to auto-calculate position and counter.
 *
 * Use {@link Matcher#readOnly} to obtain a {@link MatcherView} safe to pass to
 * user callbacks — it always reflects current state with no Proxy overhead.
 *
 * @example
 * const matcher = new Matcher();
 * matcher.push("root", {});
 * matcher.push("users", {});
 * matcher.push("user", { id: "123", type: "admin" });
 *
 * const expr = new Expression("root.users.user");
 * matcher.matches(expr); // true
 */
class Matcher {
  /**
   * Create a new Matcher.
   * @param {Object} [options={}]
   * @param {string} [options.separator='.'] - Default path separator
   */
  constructor(options = {}) {
    this.separator = options.separator || '.';
    this.path = [];
    this.siblingStacks = [];
    // Each path node: { tag, values, position, counter, namespace? }
    // values only present for current (last) node
    // Each siblingStacks entry: Map<tagName, count> tracking occurrences at each level
    this._pathStringCache = null;
    this._view = new MatcherView(this);

    // Kept-attribute stack: only populated when push() is called with options.keep.
    this._keptAttrs = [];
  }

  /**
   * Push a new tag onto the path.
   * @param {string} tagName
   * @param {Object|null} [attrValues=null]
   * @param {string|null} [namespace=null]
   * @param {Object|null} [options=null]
   * @param {string[]} [options.keep] - Names of attributes (from attrValues)
   */
  push(tagName, attrValues = null, namespace = null, options = null) {
    this._pathStringCache = null;

    // Remove values from previous current node (now becoming ancestor)
    if (this.path.length > 0) {
      this.path[this.path.length - 1].values = undefined;
    }

    // Get or create sibling tracking for current level
    const currentLevel = this.path.length;
    let level = this.siblingStacks[currentLevel];
    if (!level) {
      // `counts` tells same-name siblings apart (the "counter" — nth <item>
      // among other <item>s). `total` is every child seen at this level so
      // far, kept as a running number instead of re-added from `counts` on
      // every push — a parent with many differently-named children would
      // otherwise cost more per child the more distinct names it has.
      level = { counts: new Map(), total: 0 };
      this.siblingStacks[currentLevel] = level;
    }

    // Create a unique key for sibling tracking that includes namespace
    const siblingKey = namespace ? `${namespace}:${tagName}` : tagName;

    // Calculate counter (how many times this tag appeared at this level)
    const counter = level.counts.get(siblingKey) || 0;

    // Position = total children at this level seen before this one.
    const position = level.total;

    // Update sibling count for this tag, and the level's running total.
    level.counts.set(siblingKey, counter + 1);
    level.total++;

    // Create new node
    const node = {
      tag: tagName,
      position: position,
      counter: counter
    };

    if (namespace !== null && namespace !== undefined) {
      node.namespace = namespace;
    }

    if (attrValues !== null && attrValues !== undefined) {
      node.values = attrValues;
    }

    this.path.push(node);

    // Depth of the node we just pushed (1-based, matches this.path.length)
    const depth = this.path.length;

    // Copy only the requested attributes into the kept-attrs stack. This is
    // the one part of push() whose cost scales with input (O(keep.length))
    // rather than being O(1) — by design, since the caller is explicitly
    // opting in for specific attribute names. No options/keep => zero added
    // cost beyond the two property reads below.
    const keep = options !== null ? options.keep : null;
    if (keep !== null && keep !== undefined && keep.length > 0 && attrValues) {
      for (let i = 0; i < keep.length; i++) {
        const name = keep[i];
        if (attrValues[name] !== undefined) {
          this._keptAttrs.push({ depth, name, value: attrValues[name] });
        }
      }
    }
  }

  /**
   * Pop the last tag from the path.
   * @returns {Object|undefined} The popped node
   */
  pop() {
    if (this.path.length === 0) return undefined;
    this._pathStringCache = null;

    const node = this.path.pop();

    if (this.siblingStacks.length > this.path.length + 1) {
      this.siblingStacks.length = this.path.length + 1;
    }

    // Drop any kept attributes that belonged to the popped node (or deeper).
    // _keptAttrs is depth-ordered (push only ever appends increasing depths),
    // so this is a backward scan that stops at the first surviving entry —
    // typically O(1) since kept attrs are rare by design.
    const poppedDepth = this.path.length + 1;
    while (
      this._keptAttrs.length > 0 &&
      this._keptAttrs[this._keptAttrs.length - 1].depth >= poppedDepth
    ) {
      this._keptAttrs.pop();
    }

    return node;
  }

  /**
   * Update current node's attribute values.
   * Useful when attributes are parsed after push.
   * @param {Object} attrValues
   */
  updateCurrent(attrValues) {
    if (this.path.length > 0) {
      const current = this.path[this.path.length - 1];
      if (attrValues !== null && attrValues !== undefined) {
        current.values = attrValues;
      }
    }
  }

  /**
   * Get current tag name.
   * @returns {string|undefined}
   */
  getCurrentTag() {
    return this.path.length > 0 ? this.path[this.path.length - 1].tag : undefined;
  }

  /**
   * Get current namespace.
   * @returns {string|undefined}
   */
  getCurrentNamespace() {
    return this.path.length > 0 ? this.path[this.path.length - 1].namespace : undefined;
  }

  /**
   * Get current node's attribute value.
   * @param {string} attrName
   * @returns {*}
   */
  getAttrValue(attrName) {
    if (this.path.length === 0) return undefined;
    return this.path[this.path.length - 1].values?.[attrName];
  }

  /**
   * Check if current node has an attribute.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAttr(attrName) {
    if (this.path.length === 0) return false;
    const current = this.path[this.path.length - 1];
    return current.values !== undefined && attrName in current.values;
  }

  /**
   * Get the value of a "kept" attribute from the nearest ancestor (or
   * current node) that declared it via `push(tag, attrs, ns, { keep: [...] })`.
   * Unlike getAttrValue(), this works regardless of how deep the path has
   * gone since the attribute was pushed — but only for attribute names that
   * were explicitly marked with `keep` at push time. Cost is proportional to
   * the number of currently-kept attributes (typically 0-3), not path depth.
   * @param {string} attrName
   * @returns {*} the value, or undefined if no ancestor kept this attribute
   */
  getAnyParentAttr(attrName) {
    const kept = this._keptAttrs;
    for (let i = kept.length - 1; i >= 0; i--) {
      if (kept[i].name === attrName) return kept[i].value;
    }
    return undefined;
  }

  /**
   * Check whether any ancestor (or the current node) kept the given
   * attribute via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAnyParentAttr(attrName) {
    const kept = this._keptAttrs;
    for (let i = kept.length - 1; i >= 0; i--) {
      if (kept[i].name === attrName) return true;
    }
    return false;
  }

  /**
   * Get current node's sibling position (child index in parent).
   * @returns {number}
   */
  getPosition() {
    if (this.path.length === 0) return -1;
    return this.path[this.path.length - 1].position ?? 0;
  }

  /**
   * Get current node's repeat counter (occurrence count of this tag name).
   * @returns {number}
   */
  getCounter() {
    if (this.path.length === 0) return -1;
    return this.path[this.path.length - 1].counter ?? 0;
  }

  /**
   * Get current node's sibling index (alias for getPosition).
   * @returns {number}
   * @deprecated Use getPosition() or getCounter() instead
   */
  getIndex() {
    return this.getPosition();
  }

  /**
   * Get current path depth.
   * @returns {number}
   */
  getDepth() {
    return this.path.length;
  }

  /**
   * Get path as string.
   * @param {string} [separator] - Optional separator (uses default if not provided)
   * @param {boolean} [includeNamespace=true]
   * @returns {string}
   */
  toString(separator, includeNamespace = true) {
    const sep = separator || this.separator;
    const isDefault = (sep === this.separator && includeNamespace === true);

    if (isDefault) {
      if (this._pathStringCache !== null) {
        return this._pathStringCache;
      }
      const result = this.path.map(n =>
        (n.namespace) ? `${n.namespace}:${n.tag}` : n.tag
      ).join(sep);
      this._pathStringCache = result;
      return result;
    }

    return this.path.map(n =>
      (includeNamespace && n.namespace) ? `${n.namespace}:${n.tag}` : n.tag
    ).join(sep);
  }

  /**
   * Get path as array of tag names.
   * @returns {string[]}
   */
  toArray() {
    return this.path.map(n => n.tag);
  }

  /**
   * Reset the path to empty.
   */
  reset() {
    this._pathStringCache = null;
    this.path = [];
    this.siblingStacks = [];
    this._keptAttrs = [];
  }

  /**
   * Match current path against an Expression.
   * @param {Expression} expression
   * @returns {boolean}
   */
  matches(expression) {
    const segments = expression.segments;

    if (segments.length === 0) {
      return false;
    }

    if (expression.hasDeepWildcard()) {
      return this._matchWithDeepWildcard(segments);
    }

    return this._matchSimple(segments);
  }

  /**
   * @private
   */
  _matchSimple(segments) {
    if (this.path.length !== segments.length) {
      return false;
    }

    for (let i = 0; i < segments.length; i++) {
      if (!this._matchSegment(segments[i], this.path[i], i === this.path.length - 1)) {
        return false;
      }
    }

    return true;
  }

  /**
   * @private
   */
  _matchWithDeepWildcard(segments) {
    let pathIdx = this.path.length - 1;
    let segIdx = segments.length - 1;

    while (segIdx >= 0 && pathIdx >= 0) {
      const segment = segments[segIdx];

      if (segment.type === 'deep-wildcard') {
        segIdx--;

        if (segIdx < 0) {
          return true;
        }

        const nextSeg = segments[segIdx];
        let found = false;

        for (let i = pathIdx; i >= 0; i--) {
          if (this._matchSegment(nextSeg, this.path[i], i === this.path.length - 1)) {
            pathIdx = i - 1;
            segIdx--;
            found = true;
            break;
          }
        }

        if (!found) {
          return false;
        }
      } else {
        if (!this._matchSegment(segment, this.path[pathIdx], pathIdx === this.path.length - 1)) {
          return false;
        }
        pathIdx--;
        segIdx--;
      }
    }

    return segIdx < 0;
  }

  /**
   * @private
   */
  _matchSegment(segment, node, isCurrentNode) {
    if (segment.tag !== '*' && segment.tag !== node.tag) {
      return false;
    }

    if (segment.namespace !== undefined) {
      if (segment.namespace !== '*' && segment.namespace !== node.namespace) {
        return false;
      }
    }

    if (segment.attrName !== undefined) {
      if (!isCurrentNode) {
        return false;
      }

      if (!node.values || !(segment.attrName in node.values)) {
        return false;
      }

      if (segment.attrValue !== undefined) {
        if (String(node.values[segment.attrName]) !== String(segment.attrValue)) {
          return false;
        }
      }
    }

    if (segment.position !== undefined) {
      if (!isCurrentNode) {
        return false;
      }

      const counter = node.counter ?? 0;

      if (segment.position === 'first' && counter !== 0) {
        return false;
      } else if (segment.position === 'odd' && counter % 2 !== 1) {
        return false;
      } else if (segment.position === 'even' && counter % 2 !== 0) {
        return false;
      } else if (segment.position === 'nth' && counter !== segment.positionValue) {
        return false;
      }
    }

    return true;
  }

  /**
   * Match any expression in the given set against the current path.
   * @param {ExpressionSet} exprSet
   * @returns {boolean}
   */
  matchesAny(exprSet) {
    return exprSet.matchesAny(this);
  }

  /**
   * Create a snapshot of current state.
   * @returns {Object}
   */
  snapshot() {
    return {
      path: this.path.map(node => ({ ...node })),
      siblingStacks: this.siblingStacks.map(level => level ? { counts: new Map(level.counts), total: level.total } : level),
      keptAttrs: this._keptAttrs.map(entry => ({ ...entry }))
    };
  }

  /**
   * Restore state from snapshot.
   * @param {Object} snapshot
   */
  restore(snapshot) {
    this._pathStringCache = null;
    this.path = snapshot.path.map(node => ({ ...node }));
    this.siblingStacks = snapshot.siblingStacks.map(level => level ? { counts: new Map(level.counts), total: level.total } : level);
    this._keptAttrs = (snapshot.keptAttrs || []).map(entry => ({ ...entry }));
  }

  /**
   * Return the read-only {@link MatcherView} for this matcher.
   *
   * The same instance is returned on every call — no allocation occurs.
   * It always reflects the current parser state and is safe to pass to
   * user callbacks without risk of accidental mutation.
   *
   * @returns {MatcherView}
   *
   * @example
   * const view = matcher.readOnly();
   * // pass view to callbacks — it stays in sync automatically
   * view.matches(expr);       // ✓
   * view.getCurrentTag();     // ✓
   * // view.push(...)         // ✗ method does not exist — caught by TypeScript
   */
  readOnly() {
    return this._view;
  }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/path-expression-matcher@1.6.2/node_modules/path-expression-matcher/src/Expression.js
/**
 * Expression - Parses and stores a tag pattern expression
 * 
 * Patterns are parsed once and stored in an optimized structure for fast matching.
 * 
 * @example
 * const expr = new Expression("root.users.user");
 * const expr2 = new Expression("..user[id]:first");
 * const expr3 = new Expression("root/users/user", { separator: '/' });
 */
class Expression {
  /**
   * Create a new Expression
   * @param {string} pattern - Pattern string (e.g., "root.users.user", "..user[id]")
   * @param {Object} options - Configuration options
   * @param {string} options.separator - Path separator (default: '.')
   */
  constructor(pattern, options = {}, data) {
    this.pattern = pattern;
    this.separator = options.separator || '.';
    this.segments = this._parse(pattern);
    this.data = data;
    // Cache expensive checks for performance (O(1) instead of O(n))
    this._hasDeepWildcard = this.segments.some(seg => seg.type === 'deep-wildcard');
    this._hasAttributeCondition = this.segments.some(seg => seg.attrName !== undefined);
    this._hasPositionSelector = this.segments.some(seg => seg.position !== undefined);
  }

  /**
   * Parse pattern string into segments
   * @private
   * @param {string} pattern - Pattern to parse
   * @returns {Array} Array of segment objects
   */
  _parse(pattern) {
    const segments = [];

    // Split by separator but handle ".." specially
    let i = 0;
    let currentPart = '';

    while (i < pattern.length) {
      if (pattern[i] === this.separator) {
        // Check if next char is also separator (deep wildcard)
        if (i + 1 < pattern.length && pattern[i + 1] === this.separator) {
          // Flush current part if any
          if (currentPart.trim()) {
            segments.push(this._parseSegment(currentPart.trim()));
            currentPart = '';
          }
          // Add deep wildcard
          segments.push({ type: 'deep-wildcard' });
          i += 2; // Skip both separators
        } else {
          // Regular separator
          if (currentPart.trim()) {
            segments.push(this._parseSegment(currentPart.trim()));
          }
          currentPart = '';
          i++;
        }
      } else {
        currentPart += pattern[i];
        i++;
      }
    }

    // Flush remaining part
    if (currentPart.trim()) {
      segments.push(this._parseSegment(currentPart.trim()));
    }

    return segments;
  }

  /**
   * Parse a single segment
   * @private
   * @param {string} part - Segment string (e.g., "user", "ns::user", "user[id]", "ns::user:first")
   * @returns {Object} Segment object
   */
  _parseSegment(part) {
    const segment = { type: 'tag' };

    // NEW NAMESPACE SYNTAX (v2.0):
    // ============================
    // Namespace uses DOUBLE colon (::)
    // Position uses SINGLE colon (:)
    // 
    // Examples:
    //   "user"              → tag
    //   "user:first"        → tag + position
    //   "user[id]"          → tag + attribute
    //   "user[id]:first"    → tag + attribute + position
    //   "ns::user"          → namespace + tag
    //   "ns::user:first"    → namespace + tag + position
    //   "ns::user[id]"      → namespace + tag + attribute
    //   "ns::user[id]:first" → namespace + tag + attribute + position
    //   "ns::first"         → namespace + tag named "first" (NO ambiguity!)
    //
    // This eliminates all ambiguity:
    //   :: = namespace separator
    //   :  = position selector
    //   [] = attributes

    // Step 1: Extract brackets [attr] or [attr=value]
    let bracketContent = null;
    let withoutBrackets = part;

    const bracketMatch = part.match(/^([^\[]+)(\[[^\]]*\])(.*)$/);
    if (bracketMatch) {
      withoutBrackets = bracketMatch[1] + bracketMatch[3];
      if (bracketMatch[2]) {
        const content = bracketMatch[2].slice(1, -1);
        if (content) {
          bracketContent = content;
        }
      }
    }

    // Step 2: Check for namespace (double colon ::)
    let namespace = undefined;
    let tagAndPosition = withoutBrackets;

    if (withoutBrackets.includes('::')) {
      const nsIndex = withoutBrackets.indexOf('::');
      namespace = withoutBrackets.substring(0, nsIndex).trim();
      tagAndPosition = withoutBrackets.substring(nsIndex + 2).trim(); // Skip ::

      if (!namespace) {
        throw new Error(`Invalid namespace in pattern: ${part}`);
      }
    }

    // Step 3: Parse tag and position (single colon :)
    let tag = undefined;
    let positionMatch = null;

    if (tagAndPosition.includes(':')) {
      const colonIndex = tagAndPosition.lastIndexOf(':'); // Use last colon for position
      const tagPart = tagAndPosition.substring(0, colonIndex).trim();
      const posPart = tagAndPosition.substring(colonIndex + 1).trim();

      // Verify position is a valid keyword
      const isPositionKeyword = ['first', 'last', 'odd', 'even'].includes(posPart) ||
        /^nth\(\d+\)$/.test(posPart);

      if (isPositionKeyword) {
        tag = tagPart;
        positionMatch = posPart;
      } else {
        // Not a valid position keyword, treat whole thing as tag
        tag = tagAndPosition;
      }
    } else {
      tag = tagAndPosition;
    }

    if (!tag) {
      throw new Error(`Invalid segment pattern: ${part}`);
    }

    segment.tag = tag;
    if (namespace) {
      segment.namespace = namespace;
    }

    // Step 4: Parse attributes
    if (bracketContent) {
      if (bracketContent.includes('=')) {
        const eqIndex = bracketContent.indexOf('=');
        segment.attrName = bracketContent.substring(0, eqIndex).trim();
        segment.attrValue = bracketContent.substring(eqIndex + 1).trim();
      } else {
        segment.attrName = bracketContent.trim();
      }
    }

    // Step 5: Parse position selector
    if (positionMatch) {
      const nthMatch = positionMatch.match(/^nth\((\d+)\)$/);
      if (nthMatch) {
        segment.position = 'nth';
        segment.positionValue = parseInt(nthMatch[1], 10);
      } else {
        segment.position = positionMatch;
      }
    }

    return segment;
  }

  /**
   * Get the number of segments
   * @returns {number}
   */
  get length() {
    return this.segments.length;
  }

  /**
   * Check if expression contains deep wildcard
   * @returns {boolean}
   */
  hasDeepWildcard() {
    return this._hasDeepWildcard;
  }

  /**
   * Check if expression has attribute conditions
   * @returns {boolean}
   */
  hasAttributeCondition() {
    return this._hasAttributeCondition;
  }

  /**
   * Check if expression has position selectors
   * @returns {boolean}
   */
  hasPositionSelector() {
    return this._hasPositionSelector;
  }

  /**
   * Get string representation
   * @returns {string}
   */
  toString() {
    return this.pattern;
  }
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/path-expression-matcher@1.6.2/node_modules/path-expression-matcher/src/ExpressionSet.js
/**
 * ExpressionSet - An indexed collection of Expressions for efficient bulk matching
 *
 * Instead of iterating all expressions on every tag, ExpressionSet pre-indexes
 * them at insertion time by depth and terminal tag name. At match time, only
 * the relevant bucket is evaluated — typically reducing checks from O(E) to O(1)
 * lookup plus O(small bucket) matches.
 *
 * Three buckets are maintained:
 *  - `_byDepthAndTag`  — exact depth + exact tag name  (tightest, used first)
 *  - `_wildcardByDepth` — exact depth + wildcard tag `*` (depth-matched only)
 *  - `_deepWildcards`  — expressions containing `..`  (cannot be depth-indexed)
 *
 * @example
 * import { Expression, ExpressionSet } from 'fast-xml-tagger';
 *
 * // Build once at config time
 * const stopNodes = new ExpressionSet();
 * stopNodes.add(new Expression('root.users.user'));
 * stopNodes.add(new Expression('root.config.setting'));
 * stopNodes.add(new Expression('..script'));
 *
 * // Query on every tag — hot path
 * if (stopNodes.matchesAny(matcher)) { ... }
 */
class ExpressionSet {
  constructor() {
    /** @type {Map<string, import('./Expression.js').default[]>} depth:tag → expressions */
    this._byDepthAndTag = new Map();

    /** @type {Map<number, import('./Expression.js').default[]>} depth → wildcard-tag expressions */
    this._wildcardByDepth = new Map();

    /** @type {import('./Expression.js').default[]} expressions containing deep wildcard (..) */
    this._deepWildcards = [];

    /** @type {Map<string, import('./Expression.js').default[]>} terminalTag → deep wildcard expressions */
    this._deepByTerminalTag = new Map();

    /** @type {Set<string>} pattern strings already added — used for deduplication */
    this._patterns = new Set();

    /** @type {boolean} whether the set is sealed against further additions */
    this._sealed = false;
  }

  /**
   * Add an Expression to the set.
   * Duplicate patterns (same pattern string) are silently ignored.
   *
   * @param {import('./Expression.js').default} expression - A pre-constructed Expression instance
   * @returns {this} for chaining
   * @throws {TypeError} if called after seal()
   *
   * @example
   * set.add(new Expression('root.users.user'));
   * set.add(new Expression('..script'));
   */
  add(expression) {
    if (this._sealed) {
      throw new TypeError(
        'ExpressionSet is sealed. Create a new ExpressionSet to add more expressions.'
      );
    }

    // Deduplicate by pattern string
    if (this._patterns.has(expression.pattern)) return this;
    this._patterns.add(expression.pattern);

    if (expression.hasDeepWildcard()) {
      const lastSeg = expression.segments[expression.segments.length - 1];
      if (lastSeg && lastSeg.type !== 'deep-wildcard' && lastSeg.tag !== '*') {
        const tag = lastSeg.tag;
        if (!this._deepByTerminalTag.has(tag)) this._deepByTerminalTag.set(tag, []);
        this._deepByTerminalTag.get(tag).push(expression);
      } else {
        this._deepWildcards.push(expression);
      }
      return this;
    }

    const depth = expression.length;
    const lastSeg = expression.segments[expression.segments.length - 1];
    const tag = lastSeg?.tag;

    if (!tag || tag === '*') {
      // Can index by depth but not by tag
      if (!this._wildcardByDepth.has(depth)) this._wildcardByDepth.set(depth, []);
      this._wildcardByDepth.get(depth).push(expression);
    } else {
      // Tightest bucket: depth + tag
      const key = `${depth}:${tag}`;
      if (!this._byDepthAndTag.has(key)) this._byDepthAndTag.set(key, []);
      this._byDepthAndTag.get(key).push(expression);
    }

    return this;
  }

  /**
   * Add multiple expressions at once.
   *
   * @param {import('./Expression.js').default[]} expressions - Array of Expression instances
   * @returns {this} for chaining
   *
   * @example
   * set.addAll([
   *   new Expression('root.users.user'),
   *   new Expression('root.config.setting'),
   * ]);
   */
  addAll(expressions) {
    for (const expr of expressions) this.add(expr);
    return this;
  }

  /**
   * Check whether a pattern string is already present in the set.
   *
   * @param {import('./Expression.js').default} expression
   * @returns {boolean}
   */
  has(expression) {
    return this._patterns.has(expression.pattern);
  }

  /**
   * Number of expressions in the set.
   * @type {number}
   */
  get size() {
    return this._patterns.size;
  }

  /**
   * Seal the set against further modifications.
   * Useful to prevent accidental mutations after config is built.
   * Calling add() or addAll() on a sealed set throws a TypeError.
   *
   * @returns {this}
   */
  seal() {
    this._sealed = true;
    return this;
  }

  /**
   * Whether the set has been sealed.
   * @type {boolean}
   */
  get isSealed() {
    return this._sealed;
  }

  /**
   * Test whether the matcher's current path matches any expression in the set.
   *
   * Evaluation order (cheapest → most expensive):
   *  1. Exact depth + tag bucket  — O(1) lookup, typically 0–2 expressions
   *  2. Depth-only wildcard bucket — O(1) lookup, rare
   *  3. Deep-wildcard list         — always checked, but usually small
   *
   * @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
   * @returns {boolean} true if any expression matches the current path
   *
   * @example
   * if (stopNodes.matchesAny(matcher)) {
   *   // handle stop node
   * }
   */
  matchesAny(matcher) {
    return this.findMatch(matcher) !== null;
  }
  /**
 * Find and return the first Expression that matches the matcher's current path.
 *
 * Uses the same evaluation order as matchesAny (cheapest → most expensive):
 *  1. Exact depth + tag bucket
 *  2. Depth-only wildcard bucket
 *  3. Deep-wildcard list
 *
 * @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
 * @returns {import('./Expression.js').default | null} the first matching Expression, or null
 *
 * @example
 * const expr = stopNodes.findMatch(matcher);
 * if (expr) {
 *   // access expr.config, expr.pattern, etc.
 * }
 */
  findMatch(matcher) {
    const depth = matcher.getDepth();
    const tag = matcher.getCurrentTag();

    // 1. Tightest bucket — most expressions live here
    const exactKey = `${depth}:${tag}`;
    const exactBucket = this._byDepthAndTag.get(exactKey);
    if (exactBucket) {
      for (let i = 0; i < exactBucket.length; i++) {
        if (matcher.matches(exactBucket[i])) return exactBucket[i];
      }
    }

    // 2. Depth-matched wildcard-tag expressions
    const wildcardBucket = this._wildcardByDepth.get(depth);
    if (wildcardBucket) {
      for (let i = 0; i < wildcardBucket.length; i++) {
        if (matcher.matches(wildcardBucket[i])) return wildcardBucket[i];
      }
    }

    // 3. Deep wildcards — indexed by terminal tag, then unindexed fallback
    const deepBucket = this._deepByTerminalTag.get(tag);
    if (deepBucket) {
      for (let i = 0; i < deepBucket.length; i++) {
        if (matcher.matches(deepBucket[i])) return deepBucket[i];
      }
    }
    for (let i = 0; i < this._deepWildcards.length; i++) {
      if (matcher.matches(this._deepWildcards[i])) return this._deepWildcards[i];
    }

    return null;
  }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/@nodable+entities@3.0.0/node_modules/@nodable/entities/src/entities.js
// ---------------------------------------------------------------------------
// Complete HTML5 named entity reference
// Organized by logical categories for easy maintenance and selective importing
// ---------------------------------------------------------------------------

/**
 * Basic Latin & Special Characters
 * @type {Record<string, string>}
 */
const BASIC_LATIN = (/* unused pure expression or super */ null && ({
  amp: '&',
  AMP: '&',
  lt: '<',
  LT: '<',
  gt: '>',
  GT: '>',
  quot: '"',
  QUOT: '"',
  apos: "'",
  lsquo: '‘',
  rsquo: '’',
  ldquo: '“',
  rdquo: '”',
  lsquor: '‚',
  rsquor: '’',
  ldquor: '„',
  bdquo: '„',
  comma: ',',
  period: '.',
  colon: ':',
  semi: ';',
  excl: '!',
  quest: '?',
  num: '#',
  dollar: '$',
  percent: '%',
  ast: '*',
  commat: '@',
  lowbar: '_',
  verbar: '|',
  vert: '|',
  sol: '/',
  bsol: '\\',
  lbrace: '{',
  rbrace: '}',
  lbrack: '[',
  rbrack: ']',
  lpar: '(',
  rpar: ')',
  nbsp: '\u00a0',
  iexcl: '¡',
  cent: '¢',
  pound: '£',
  curren: '¤',
  yen: '¥',
  brvbar: '¦',
  sect: '§',
  uml: '¨',
  copy: '©',
  COPY: '©',
  ordf: 'ª',
  laquo: '«',
  not: '¬',
  shy: '\u00ad',
  reg: '®',
  REG: '®',
  macr: '¯',
  deg: '°',
  plusmn: '±',
  sup2: '²',
  sup3: '³',
  acute: '´',
  micro: 'µ',
  para: '¶',
  middot: '·',
  cedil: '¸',
  sup1: '¹',
  ordm: 'º',
  raquo: '»',
  frac14: '¼',
  frac12: '½',
  half: '½',
  frac34: '¾',
  iquest: '¿',
  times: '×',
  div: '÷',
  divide: '÷',
}));

/**
 * Latin Extended & Accented Letters (A-Z)
 * @type {Record<string, string>}
 */
const LATIN_ACCENTS = (/* unused pure expression or super */ null && ({
  Agrave: 'À',
  agrave: 'à',
  Aacute: 'Á',
  aacute: 'á',
  Acirc: 'Â',
  acirc: 'â',
  Atilde: 'Ã',
  atilde: 'ã',
  Auml: 'Ä',
  auml: 'ä',
  Aring: 'Å',
  aring: 'å',
  AElig: 'Æ',
  aelig: 'æ',
  Ccedil: 'Ç',
  ccedil: 'ç',
  Egrave: 'È',
  egrave: 'è',
  Eacute: 'É',
  eacute: 'é',
  Ecirc: 'Ê',
  ecirc: 'ê',
  Euml: 'Ë',
  euml: 'ë',
  Igrave: 'Ì',
  igrave: 'ì',
  Iacute: 'Í',
  iacute: 'í',
  Icirc: 'Î',
  icirc: 'î',
  Iuml: 'Ï',
  iuml: 'ï',
  ETH: 'Ð',
  eth: 'ð',
  Ntilde: 'Ñ',
  ntilde: 'ñ',
  Ograve: 'Ò',
  ograve: 'ò',
  Oacute: 'Ó',
  oacute: 'ó',
  Ocirc: 'Ô',
  ocirc: 'ô',
  Otilde: 'Õ',
  otilde: 'õ',
  Ouml: 'Ö',
  ouml: 'ö',
  Oslash: 'Ø',
  oslash: 'ø',
  Ugrave: 'Ù',
  ugrave: 'ù',
  Uacute: 'Ú',
  uacute: 'ú',
  Ucirc: 'Û',
  ucirc: 'û',
  Uuml: 'Ü',
  uuml: 'ü',
  Yacute: 'Ý',
  yacute: 'ý',
  THORN: 'Þ',
  thorn: 'þ',
  szlig: 'ß',
  yuml: 'ÿ',
  Yuml: 'Ÿ',
}));

/**
 * Latin Extended (Letters with diacritics)
 * @type {Record<string, string>}
 */
const LATIN_EXTENDED = (/* unused pure expression or super */ null && ({
  Amacr: 'Ā',
  amacr: 'ā',
  Abreve: 'Ă',
  abreve: 'ă',
  Aogon: 'Ą',
  aogon: 'ą',
  Cacute: 'Ć',
  cacute: 'ć',
  Ccirc: 'Ĉ',
  ccirc: 'ĉ',
  Cdot: 'Ċ',
  cdot: 'ċ',
  Ccaron: 'Č',
  ccaron: 'č',
  Dcaron: 'Ď',
  dcaron: 'ď',
  Dstrok: 'Đ',
  dstrok: 'đ',
  Emacr: 'Ē',
  emacr: 'ē',
  Ecaron: 'Ě',
  ecaron: 'ě',
  Edot: 'Ė',
  edot: 'ė',
  Eogon: 'Ę',
  eogon: 'ę',
  Gcirc: 'Ĝ',
  gcirc: 'ĝ',
  Gbreve: 'Ğ',
  gbreve: 'ğ',
  Gdot: 'Ġ',
  gdot: 'ġ',
  Gcedil: 'Ģ',
  Hcirc: 'Ĥ',
  hcirc: 'ĥ',
  Hstrok: 'Ħ',
  hstrok: 'ħ',
  Itilde: 'Ĩ',
  itilde: 'ĩ',
  Imacr: 'Ī',
  imacr: 'ī',
  Iogon: 'Į',
  iogon: 'į',
  Idot: 'İ',
  IJlig: 'Ĳ',
  ijlig: 'ĳ',
  Jcirc: 'Ĵ',
  jcirc: 'ĵ',
  Kcedil: 'Ķ',
  kcedil: 'ķ',
  kgreen: 'ĸ',
  Lacute: 'Ĺ',
  lacute: 'ĺ',
  Lcedil: 'Ļ',
  lcedil: 'ļ',
  Lcaron: 'Ľ',
  lcaron: 'ľ',
  Lmidot: 'Ŀ',
  lmidot: 'ŀ',
  Lstrok: 'Ł',
  lstrok: 'ł',
  Nacute: 'Ń',
  nacute: 'ń',
  Ncaron: 'Ň',
  ncaron: 'ň',
  Ncedil: 'Ņ',
  ncedil: 'ņ',
  ENG: 'Ŋ',
  eng: 'ŋ',
  Omacr: 'Ō',
  omacr: 'ō',
  Odblac: 'Ő',
  odblac: 'ő',
  OElig: 'Œ',
  oelig: 'œ',
  Racute: 'Ŕ',
  racute: 'ŕ',
  Rcaron: 'Ř',
  rcaron: 'ř',
  Rcedil: 'Ŗ',
  rcedil: 'ŗ',
  Sacute: 'Ś',
  sacute: 'ś',
  Scirc: 'Ŝ',
  scirc: 'ŝ',
  Scedil: 'Ş',
  scedil: 'ş',
  Scaron: 'Š',
  scaron: 'š',
  Tcedil: 'Ţ',
  tcedil: 'ţ',
  Tcaron: 'Ť',
  tcaron: 'ť',
  Tstrok: 'Ŧ',
  tstrok: 'ŧ',
  Utilde: 'Ũ',
  utilde: 'ũ',
  Umacr: 'Ū',
  umacr: 'ū',
  Ubreve: 'Ŭ',
  ubreve: 'ŭ',
  Uring: 'Ů',
  uring: 'ů',
  Udblac: 'Ű',
  udblac: 'ű',
  Uogon: 'Ų',
  uogon: 'ų',
  Wcirc: 'Ŵ',
  wcirc: 'ŵ',
  Ycirc: 'Ŷ',
  ycirc: 'ŷ',
  Zacute: 'Ź',
  zacute: 'ź',
  Zdot: 'Ż',
  zdot: 'ż',
  Zcaron: 'Ž',
  zcaron: 'ž',
}));

/**
 * Greek Letters
 * @type {Record<string, string>}
 */
const GREEK = (/* unused pure expression or super */ null && ({
  Alpha: 'Α',
  alpha: 'α',
  Beta: 'Β',
  beta: 'β',
  Gamma: 'Γ',
  gamma: 'γ',
  Delta: 'Δ',
  delta: 'δ',
  Epsilon: 'Ε',
  epsilon: 'ε',
  epsiv: 'ϵ',
  varepsilon: 'ϵ',
  Zeta: 'Ζ',
  zeta: 'ζ',
  Eta: 'Η',
  eta: 'η',
  Theta: 'Θ',
  theta: 'θ',
  thetasym: 'ϑ',
  vartheta: 'ϑ',
  Iota: 'Ι',
  iota: 'ι',
  Kappa: 'Κ',
  kappa: 'κ',
  kappav: 'ϰ',
  varkappa: 'ϰ',
  Lambda: 'Λ',
  lambda: 'λ',
  Mu: 'Μ',
  mu: 'μ',
  Nu: 'Ν',
  nu: 'ν',
  Xi: 'Ξ',
  xi: 'ξ',
  Omicron: 'Ο',
  omicron: 'ο',
  Pi: 'Π',
  pi: 'π',
  piv: 'ϖ',
  varpi: 'ϖ',
  Rho: 'Ρ',
  rho: 'ρ',
  rhov: 'ϱ',
  varrho: 'ϱ',
  Sigma: 'Σ',
  sigma: 'σ',
  sigmaf: 'ς',
  sigmav: 'ς',
  varsigma: 'ς',
  Tau: 'Τ',
  tau: 'τ',
  Upsilon: 'Υ',
  upsilon: 'υ',
  upsi: 'υ',
  Upsi: 'ϒ',
  upsih: 'ϒ',
  Phi: 'Φ',
  phi: 'φ',
  phiv: 'ϕ',
  varphi: 'ϕ',
  Chi: 'Χ',
  chi: 'χ',
  Psi: 'Ψ',
  psi: 'ψ',
  Omega: 'Ω',
  omega: 'ω',
  ohm: 'Ω',
  Gammad: 'Ϝ',
  gammad: 'ϝ',
  digamma: 'ϝ',
}));

/**
 * Cyrillic Letters
 * @type {Record<string, string>}
 */
const CYRILLIC = (/* unused pure expression or super */ null && ({
  Afr: '𝔄',
  afr: '𝔞',
  Acy: 'А',
  acy: 'а',
  Bcy: 'Б',
  bcy: 'б',
  Vcy: 'В',
  vcy: 'в',
  Gcy: 'Г',
  gcy: 'г',
  Dcy: 'Д',
  dcy: 'д',
  IEcy: 'Е',
  iecy: 'е',
  IOcy: 'Ё',
  iocy: 'ё',
  ZHcy: 'Ж',
  zhcy: 'ж',
  Zcy: 'З',
  zcy: 'з',
  Icy: 'И',
  icy: 'и',
  Jcy: 'Й',
  jcy: 'й',
  Kcy: 'К',
  kcy: 'к',
  Lcy: 'Л',
  lcy: 'л',
  Mcy: 'М',
  mcy: 'м',
  Ncy: 'Н',
  ncy: 'н',
  Ocy: 'О',
  ocy: 'о',
  Pcy: 'П',
  pcy: 'п',
  Rcy: 'Р',
  rcy: 'р',
  Scy: 'С',
  scy: 'с',
  Tcy: 'Т',
  tcy: 'т',
  Ucy: 'У',
  ucy: 'у',
  Fcy: 'Ф',
  fcy: 'ф',
  KHcy: 'Х',
  khcy: 'х',
  TScy: 'Ц',
  tscy: 'ц',
  CHcy: 'Ч',
  chcy: 'ч',
  SHcy: 'Ш',
  shcy: 'ш',
  SHCHcy: 'Щ',
  shchcy: 'щ',
  HARDcy: 'Ъ',
  hardcy: 'ъ',
  Ycy: 'Ы',
  ycy: 'ы',
  SOFTcy: 'Ь',
  softcy: 'ь',
  Ecy: 'Э',
  ecy: 'э',
  YUcy: 'Ю',
  yucy: 'ю',
  YAcy: 'Я',
  yacy: 'я',
  DJcy: 'Ђ',
  djcy: 'ђ',
  GJcy: 'Ѓ',
  gjcy: 'ѓ',
  Jukcy: 'Є',
  jukcy: 'є',
  DScy: 'Ѕ',
  dscy: 'ѕ',
  Iukcy: 'І',
  iukcy: 'і',
  YIcy: 'Ї',
  yicy: 'ї',
  Jsercy: 'Ј',
  jsercy: 'ј',
  LJcy: 'Љ',
  ljcy: 'љ',
  NJcy: 'Њ',
  njcy: 'њ',
  TSHcy: 'Ћ',
  tshcy: 'ћ',
  KJcy: 'Ќ',
  kjcy: 'ќ',
  Ubrcy: 'Ў',
  ubrcy: 'ў',
  DZcy: 'Џ',
  dzcy: 'џ',
}));

/**
 * Mathematical Operators & Relations
 * @type {Record<string, string>}
 */
const MATH = (/* unused pure expression or super */ null && ({
  plus: '+',
  pm: '±',
  times: '×',
  div: '÷',
  divide: '÷',
  sdot: '⋅',
  star: '☆',
  starf: '★',
  bigstar: '★',
  lowast: '∗',
  ast: '*',
  midast: '*',
  compfn: '∘',
  smallcircle: '∘',
  bullet: '•',
  bull: '•',
  nbsp: '\u00a0',
  hellip: '…',
  mldr: '…',
  prime: '′',
  Prime: '″',
  tprime: '‴',
  bprime: '‵',
  backprime: '‵',
  minus: '−',
  minusd: '∸',
  dotminus: '∸',
  plusdo: '∔',
  dotplus: '∔',
  plusmn: '±',
  minusplus: '∓',
  mnplus: '∓',
  mp: '∓',
  setminus: '∖',
  smallsetminus: '∖',
  Backslash: '∖',
  setmn: '∖',
  ssetmn: '∖',
  lowbar: '_',
  verbar: '|',
  vert: '|',
  VerticalLine: '|',
  colon: ':',
  Colon: '∷',
  Proportion: '∷',
  ratio: '∶',
  equals: '=',
  ne: '≠',
  nequiv: '≢',
  equiv: '≡',
  Congruent: '≡',
  sim: '∼',
  thicksim: '∼',
  thksim: '∼',
  sime: '≃',
  simeq: '≃',
  TildeEqual: '≃',
  asymp: '≈',
  approx: '≈',
  thickapprox: '≈',
  thkap: '≈',
  TildeTilde: '≈',
  ncong: '≇',
  cong: '≅',
  TildeFullEqual: '≅',
  asympeq: '≍',
  CupCap: '≍',
  bump: '≎',
  Bumpeq: '≎',
  HumpDownHump: '≎',
  bumpe: '≏',
  bumpeq: '≏',
  HumpEqual: '≏',
  le: '≤',
  LessEqual: '≤',
  ge: '≥',
  GreaterEqual: '≥',
  lesseqgtr: '⋚',
  lesseqqgtr: '⪋',
  greater: '>',
  less: '<',
}));

/**
 * Mathematical Operators (Advanced)
 * @type {Record<string, string>}
 */
const MATH_ADVANCED = (/* unused pure expression or super */ null && ({
  alefsym: 'ℵ',
  aleph: 'ℵ',
  beth: 'ℶ',
  gimel: 'ℷ',
  daleth: 'ℸ',
  forall: '∀',
  ForAll: '∀',
  part: '∂',
  PartialD: '∂',
  exist: '∃',
  Exists: '∃',
  nexist: '∄',
  nexists: '∄',
  empty: '∅',
  emptyset: '∅',
  emptyv: '∅',
  varnothing: '∅',
  nabla: '∇',
  Del: '∇',
  isin: '∈',
  isinv: '∈',
  in: '∈',
  Element: '∈',
  notin: '∉',
  notinva: '∉',
  ni: '∋',
  niv: '∋',
  SuchThat: '∋',
  ReverseElement: '∋',
  notni: '∌',
  notniva: '∌',
  prod: '∏',
  Product: '∏',
  coprod: '∐',
  Coproduct: '∐',
  sum: '∑',
  Sum: '∑',
  minus: '−',
  mp: '∓',
  plusdo: '∔',
  dotplus: '∔',
  setminus: '∖',
  lowast: '∗',
  radic: '√',
  Sqrt: '√',
  prop: '∝',
  propto: '∝',
  Proportional: '∝',
  varpropto: '∝',
  infin: '∞',
  infintie: '⧝',
  ang: '∠',
  angle: '∠',
  angmsd: '∡',
  measuredangle: '∡',
  angsph: '∢',
  mid: '∣',
  VerticalBar: '∣',
  nmid: '∤',
  nsmid: '∤',
  npar: '∦',
  parallel: '∥',
  spar: '∥',
  nparallel: '∦',
  nspar: '∦',
  and: '∧',
  wedge: '∧',
  or: '∨',
  vee: '∨',
  cap: '∩',
  cup: '∪',
  int: '∫',
  Integral: '∫',
  conint: '∮',
  ContourIntegral: '∮',
  Conint: '∯',
  DoubleContourIntegral: '∯',
  Cconint: '∰',
  there4: '∴',
  therefore: '∴',
  Therefore: '∴',
  becaus: '∵',
  because: '∵',
  Because: '∵',
  ratio: '∶',
  Proportion: '∷',
  minusd: '∸',
  dotminus: '∸',
  mDDot: '∺',
  homtht: '∻',
  sim: '∼',
  bsimg: '∽',
  backsim: '∽',
  ac: '∾',
  mstpos: '∾',
  acd: '∿',
  VerticalTilde: '≀',
  wr: '≀',
  wreath: '≀',
  nsime: '≄',
  nsimeq: '≄',
  ncong: '≇',
  simne: '≆',
  ncongdot: '⩭̸',
  ngsim: '≵',
  nsim: '≁',
  napprox: '≉',
  nap: '≉',
  ngeq: '≱',
  nge: '≱',
  nleq: '≰',
  nle: '≰',
  ngtr: '≯',
  ngt: '≯',
  nless: '≮',
  nlt: '≮',
  nprec: '⊀',
  npr: '⊀',
  nsucc: '⊁',
  nsc: '⊁',
}));

/**
 * Arrows
 * @type {Record<string, string>}
 */
const ARROWS = (/* unused pure expression or super */ null && ({
  larr: '←',
  leftarrow: '←',
  LeftArrow: '←',
  uarr: '↑',
  uparrow: '↑',
  UpArrow: '↑',
  rarr: '→',
  rightarrow: '→',
  RightArrow: '→',
  darr: '↓',
  downarrow: '↓',
  DownArrow: '↓',
  harr: '↔',
  leftrightarrow: '↔',
  LeftRightArrow: '↔',
  varr: '↕',
  updownarrow: '↕',
  UpDownArrow: '↕',
  nwarr: '↖',
  nwarrow: '↖',
  UpperLeftArrow: '↖',
  nearr: '↗',
  nearrow: '↗',
  UpperRightArrow: '↗',
  searr: '↘',
  searrow: '↘',
  LowerRightArrow: '↘',
  swarr: '↙',
  swarrow: '↙',
  LowerLeftArrow: '↙',
  lArr: '⇐',
  Leftarrow: '⇐',
  uArr: '⇑',
  Uparrow: '⇑',
  rArr: '⇒',
  Rightarrow: '⇒',
  dArr: '⇓',
  Downarrow: '⇓',
  hArr: '⇔',
  Leftrightarrow: '⇔',
  iff: '⇔',
  vArr: '⇕',
  Updownarrow: '⇕',
  lAarr: '⇚',
  Lleftarrow: '⇚',
  rAarr: '⇛',
  Rrightarrow: '⇛',
  lrarr: '⇆',
  leftrightarrows: '⇆',
  rlarr: '⇄',
  rightleftarrows: '⇄',
  lrhar: '⇋',
  leftrightharpoons: '⇋',
  ReverseEquilibrium: '⇋',
  rlhar: '⇌',
  rightleftharpoons: '⇌',
  Equilibrium: '⇌',
  udarr: '⇅',
  UpArrowDownArrow: '⇅',
  duarr: '⇵',
  DownArrowUpArrow: '⇵',
  llarr: '⇇',
  leftleftarrows: '⇇',
  rrarr: '⇉',
  rightrightarrows: '⇉',
  ddarr: '⇊',
  downdownarrows: '⇊',
  har: '↽',
  lhard: '↽',
  leftharpoondown: '↽',
  lharu: '↼',
  leftharpoonup: '↼',
  rhard: '⇁',
  rightharpoondown: '⇁',
  rharu: '⇀',
  rightharpoonup: '⇀',
  lsh: '↰',
  Lsh: '↰',
  rsh: '↱',
  Rsh: '↱',
  ldsh: '↲',
  rdsh: '↳',
  hookleftarrow: '↩',
  hookrightarrow: '↪',
  mapstoleft: '↤',
  mapstoup: '↥',
  map: '↦',
  mapsto: '↦',
  mapstodown: '↧',
  crarr: '↵',
  nleftarrow: '↚',
  nleftrightarrow: '↮',
  nrightarrow: '↛',
  nrarr: '↛',
  larrtl: '↢',
  rarrtl: '↣',
  leftarrowtail: '↢',
  rightarrowtail: '↣',
  twoheadleftarrow: '↞',
  twoheadrightarrow: '↠',
  Larr: '↞',
  Rarr: '↠',
  larrhk: '↩',
  rarrhk: '↪',
  larrlp: '↫',
  looparrowleft: '↫',
  rarrlp: '↬',
  looparrowright: '↬',
  harrw: '↭',
  leftrightsquigarrow: '↭',
  nrarrw: '↝̸',
  rarrw: '↝',
  rightsquigarrow: '↝',
  larrbfs: '⤟',
  rarrbfs: '⤠',
  nvHarr: '⤄',
  nvlArr: '⤂',
  nvrArr: '⤃',
  larrfs: '⤝',
  rarrfs: '⤞',
  Map: '⤅',
  larrsim: '⥳',
  rarrsim: '⥴',
  harrcir: '⥈',
  Uarrocir: '⥉',
  lurdshar: '⥊',
  ldrdhar: '⥧',
  ldrushar: '⥋',
  rdldhar: '⥩',
  lrhard: '⥭',
  uharr: '↾',
  uharl: '↿',
  dharr: '⇂',
  dharl: '⇃',
  Uarr: '↟',
  Darr: '↡',
  zigrarr: '⇝',
  nwArr: '⇖',
  neArr: '⇗',
  seArr: '⇘',
  swArr: '⇙',
  nharr: '↮',
  nhArr: '⇎',
  nlarr: '↚',
  nlArr: '⇍',
  nrArr: '⇏',
  larrb: '⇤',
  LeftArrowBar: '⇤',
  rarrb: '⇥',
  RightArrowBar: '⇥',
}));

/**
 * Geometric Shapes
 * @type {Record<string, string>}
 */
const SHAPES = (/* unused pure expression or super */ null && ({
  square: '□',
  Square: '□',
  squ: '□',
  squf: '▪',
  squarf: '▪',
  blacksquar: '▪',
  blacksquare: '▪',
  FilledVerySmallSquare: '▪',
  blk34: '▓',
  blk12: '▒',
  blk14: '░',
  block: '█',
  srect: '▭',
  rect: '▭',
  sdot: '⋅',
  sdotb: '⊡',
  dotsquare: '⊡',
  triangle: '▵',
  tri: '▵',
  trine: '▵',
  utri: '▵',
  triangledown: '▿',
  dtri: '▿',
  tridown: '▿',
  triangleleft: '◃',
  ltri: '◃',
  triangleright: '▹',
  rtri: '▹',
  blacktriangle: '▴',
  utrif: '▴',
  blacktriangledown: '▾',
  dtrif: '▾',
  blacktriangleleft: '◂',
  ltrif: '◂',
  blacktriangleright: '▸',
  rtrif: '▸',
  loz: '◊',
  lozenge: '◊',
  blacklozenge: '⧫',
  lozf: '⧫',
  bigcirc: '◯',
  xcirc: '◯',
  circ: 'ˆ',
  Circle: '○',
  cir: '○',
  o: '○',
  bullet: '•',
  bull: '•',
  hellip: '…',
  mldr: '…',
  nldr: '‥',
  boxh: '─',
  HorizontalLine: '─',
  boxv: '│',
  boxdr: '┌',
  boxdl: '┐',
  boxur: '└',
  boxul: '┘',
  boxvr: '├',
  boxvl: '┤',
  boxhd: '┬',
  boxhu: '┴',
  boxvh: '┼',
  boxH: '═',
  boxV: '║',
  boxdR: '╒',
  boxDr: '╓',
  boxDR: '╔',
  boxDl: '╕',
  boxdL: '╖',
  boxDL: '╗',
  boxuR: '╘',
  boxUr: '╙',
  boxUR: '╚',
  boxUl: '╜',
  boxuL: '╛',
  boxUL: '╝',
  boxvR: '╞',
  boxVr: '╟',
  boxVR: '╠',
  boxVl: '╢',
  boxvL: '╡',
  boxVL: '╣',
  boxHd: '╤',
  boxhD: '╥',
  boxHD: '╦',
  boxHu: '╧',
  boxhU: '╨',
  boxHU: '╩',
  boxvH: '╪',
  boxVh: '╫',
  boxVH: '╬',
}));

/**
 * Punctuation & Diacritics
 * @type {Record<string, string>}
 */
const PUNCTUATION = (/* unused pure expression or super */ null && ({
  excl: '!',
  iexcl: '¡',
  brvbar: '¦',
  sect: '§',
  uml: '¨',
  copy: '©',
  ordf: 'ª',
  laquo: '«',
  not: '¬',
  shy: '\u00ad',
  reg: '®',
  macr: '¯',
  deg: '°',
  plusmn: '±',
  sup2: '²',
  sup3: '³',
  acute: '´',
  micro: 'µ',
  para: '¶',
  middot: '·',
  cedil: '¸',
  sup1: '¹',
  ordm: 'º',
  raquo: '»',
  frac14: '¼',
  frac12: '½',
  frac34: '¾',
  iquest: '¿',
  nbsp: '\u00a0',
  comma: ',',
  period: '.',
  colon: ':',
  semi: ';',
  vert: '|',
  Verbar: '‖',
  verbar: '|',
  dblac: '˝',
  circ: 'ˆ',
  caron: 'ˇ',
  breve: '˘',
  dot: '˙',
  ring: '˚',
  ogon: '˛',
  tilde: '˜',
  DiacriticalGrave: '`',
  DiacriticalAcute: '´',
  DiacriticalTilde: '˜',
  DiacriticalDot: '˙',
  DiacriticalDoubleAcute: '˝',
  grave: '`',
}));

/**
 * Currency Symbols
 * @type {Record<string, string>}
 */
const CURRENCY = {
  cent: '¢',
  pound: '£',
  curren: '¤',
  yen: '¥',
  euro: '€',
  dollar: '$',
  fnof: 'ƒ',
  inr: '₹',
  af: '؋',
  birr: 'ብር',
  peso: '₱',
  rub: '₽',
  won: '₩',
  yuan: '¥',
  cedil: '¸',
};

/**
 * Fractions
 * @type {Record<string, string>}
 */
const FRACTIONS = (/* unused pure expression or super */ null && ({
  frac12: '½',
  half: '½',
  frac13: '⅓',
  frac14: '¼',
  frac15: '⅕',
  frac16: '⅙',
  frac18: '⅛',
  frac23: '⅔',
  frac25: '⅖',
  frac34: '¾',
  frac35: '⅗',
  frac38: '⅜',
  frac45: '⅘',
  frac56: '⅚',
  frac58: '⅝',
  frac78: '⅞',
  frasl: '⁄',
}));

/**
 * Miscellaneous Symbols
 * @type {Record<string, string>}
 */
const MISC_SYMBOLS = (/* unused pure expression or super */ null && ({
  trade: '™',
  TRADE: '™',
  telrec: '⌕',
  target: '⌖',
  ulcorn: '⌜',
  ulcorner: '⌜',
  urcorn: '⌝',
  urcorner: '⌝',
  dlcorn: '⌞',
  llcorner: '⌞',
  drcorn: '⌟',
  lrcorner: '⌟',
  intercal: '⊺',
  intcal: '⊺',
  oplus: '⊕',
  CirclePlus: '⊕',
  ominus: '⊖',
  CircleMinus: '⊖',
  otimes: '⊗',
  CircleTimes: '⊗',
  osol: '⊘',
  odot: '⊙',
  CircleDot: '⊙',
  oast: '⊛',
  circledast: '⊛',
  odash: '⊝',
  circleddash: '⊝',
  ocirc: '⊚',
  circledcirc: '⊚',
  boxplus: '⊞',
  plusb: '⊞',
  boxminus: '⊟',
  minusb: '⊟',
  boxtimes: '⊠',
  timesb: '⊠',
  boxdot: '⊡',
  sdotb: '⊡',
  veebar: '⊻',
  vee: '∨',
  barvee: '⊽',
  and: '∧',
  wedge: '∧',
  Cap: '⋒',
  Cup: '⋓',
  Fork: '⋔',
  pitchfork: '⋔',
  epar: '⋕',
  ltlarr: '⥶',
  nvap: '≍⃒',
  nvsim: '∼⃒',
  nvge: '≥⃒',
  nvle: '≤⃒',
  nvlt: '<⃒',
  nvgt: '>⃒',
  nvltrie: '⊴⃒',
  nvrtrie: '⊵⃒',
  Vdash: '⊩',
  dashv: '⊣',
  vDash: '⊨',
  Vvdash: '⊪',
  nvdash: '⊬',
  nvDash: '⊭',
  nVdash: '⊮',
  nVDash: '⊯',
}));

const XML = {
  amp: "&",
  apos: "'",
  gt: ">",
  lt: "<",
  quot: "\""
}
const COMMON_HTML = {
  nbsp: '\u00a0',
  copy: '\u00a9',
  reg: '\u00ae',
  trade: '\u2122',
  mdash: '\u2014',
  ndash: '\u2013',
  hellip: '\u2026',
  laquo: '\u00ab',
  raquo: '\u00bb',
  lsquo: '\u2018',
  rsquo: '\u2019',
  ldquo: '\u201c',
  rdquo: '\u201d',
  bull: '\u2022',
  para: '\u00b6',
  sect: '\u00a7',
  deg: '\u00b0',
  frac12: '\u00bd',
  frac14: '\u00bc',
  frac34: '\u00be',
}
// ---------------------------------------------------------------------------
// Note: NUMERIC_ENTITIES (&#NNN; / &#xHH;) are handled by the scanner directly
// via String.fromCodePoint() without any map lookup.
// ---------------------------------------------------------------------------
;// CONCATENATED MODULE: ./node_modules/.pnpm/@nodable+entities@3.0.0/node_modules/@nodable/entities/src/EntityDecoder.js
// ---------------------------------------------------------------------------
// Built-in named entity map  (name → replacement string)
// No regex, no {regex,val} objects — just flat key/value pairs.
// ---------------------------------------------------------------------------



// ---------------------------------------------------------------------------
// Entity hook action constants
// ---------------------------------------------------------------------------

/**
 * Action constants for `onExternalEntity` and `onInputEntity` hooks.
 *
 * Use these instead of raw strings to avoid typos:
 *
 * @example
 * import EntityDecoder, { ENTITY_ACTION } from './EntityDecoder.js';
 * const dec = new EntityDecoder({
 *   onInputEntity: (name, value) => ENTITY_ACTION.BLOCK,
 * });
 */
const ENTITY_ACTION = Object.freeze({
  /** Resolve and expand the entity normally. */
  ALLOW: 'allow',
  /** Silently skip this entity — it will not be registered. */
  BLOCK: 'block',
  /** Throw an error, aborting entity registration entirely. */
  THROW: 'throw',
});

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const SPECIAL_CHARS = new Set('!?\\\\/[]$%{}^&*()<>|+');

/**
 * Validate that an entity name contains no dangerous characters.
 * @param {string} name
 * @returns {string} the name, unchanged
 * @throws {Error} on invalid characters
 */
function EntityDecoder_validateEntityName(name) {
  if (name[0] === '#') {
    throw new Error(`[EntityReplacer] Invalid character '#' in entity name: "${name}"`);
  }
  for (const ch of name) {
    if (SPECIAL_CHARS.has(ch)) {
      throw new Error(`[EntityReplacer] Invalid character '${ch}' in entity name: "${name}"`);
    }
  }
  return name;
}

/**
 * Merge one or more entity maps into a flat name→string map.
 * Accepts either:
 *   - plain string values:             { amp: '&' }
 *   - legacy {regex,val} / {regx,val}: { lt: { regex: /.../, val: '<' } }
 *
 * Values containing '&' are skipped (recursive expansion risk).
 *
 * @param {...object} maps
 * @returns {Record<string, string>}
 */
function mergeEntityMaps(...maps) {
  const out = Object.create(null);
  for (const map of maps) {
    if (!map) continue;
    for (const key of Object.keys(map)) {
      const raw = map[key];
      if (typeof raw === 'string') {
        out[key] = raw;
      } else if (raw && typeof raw === 'object' && raw.val !== undefined) {
        // Legacy {regex,val} or {regx,val} — extract the string val only
        const val = raw.val;
        if (typeof val === 'string') {
          out[key] = val;
        }
        // function vals are not supported in the scanner — skip
      }
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// applyLimitsTo helpers
// ---------------------------------------------------------------------------

const LIMIT_TIER_EXTERNAL = 'external'; // input/runtime + persistent external maps
const LIMIT_TIER_BASE = 'base';     // DEFAULT_XML_ENTITIES + namedEntities (system) maps
const LIMIT_TIER_ALL = 'all';      // every entity regardless of tier

/**
 * Resolve `applyLimitsTo` option into a normalised Set of tier strings.
 * Accepted values: 'external' | 'base' | 'all' | string[]
 * Default: 'external' (only untrusted injected entities are counted).
 * @param {string|string[]|undefined} raw
 * @returns {Set<string>}
 */
function parseLimitTiers(raw) {
  if (!raw || raw === LIMIT_TIER_EXTERNAL) return new Set([LIMIT_TIER_EXTERNAL]);
  if (raw === LIMIT_TIER_ALL) return new Set([LIMIT_TIER_ALL]);
  if (raw === LIMIT_TIER_BASE) return new Set([LIMIT_TIER_BASE]);
  if (Array.isArray(raw)) return new Set(raw);
  return new Set([LIMIT_TIER_EXTERNAL]); // safe default for unrecognised values
}

// ---------------------------------------------------------------------------
// NCR (Numeric Character Reference) classification
// ---------------------------------------------------------------------------

// Severity order — higher number = stricter action.
// Used to enforce minimum action levels for specific codepoint ranges.
const NCR_LEVEL = Object.freeze({ allow: 0, leave: 1, remove: 2, throw: 3 });

// XML 1.0 §2.2: allowed chars are #x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD] | [#x10000-#x10FFFF]
// Restricted C0: U+0001–U+001F excluding U+0009, U+000A, U+000D
const XML10_ALLOWED_C0 = new Set([0x09, 0x0A, 0x0D]);

/**
 * Parse the `ncr` constructor option into flat, hot-path-friendly fields.
 * @param {object|undefined} ncr
 * @returns {{ xmlVersion: number, onLevel: number, nullLevel: number }}
 */
function parseNCRConfig(ncr) {
  if (!ncr) {
    return { xmlVersion: 1.0, onLevel: NCR_LEVEL.allow, nullLevel: NCR_LEVEL.remove };
  }
  const xmlVersion = ncr.xmlVersion === 1.1 ? 1.1 : 1.0;
  const onLevel = NCR_LEVEL[ncr.onNCR] ?? NCR_LEVEL.allow;
  const nullLevel = NCR_LEVEL[ncr.nullNCR] ?? NCR_LEVEL.remove;
  // 'allow' is not meaningful for null — clamp to at least 'remove'
  const clampedNull = Math.max(nullLevel, NCR_LEVEL.remove);
  return { xmlVersion, onLevel, nullLevel: clampedNull };
}

// ---------------------------------------------------------------------------
// EntityReplacer
// ---------------------------------------------------------------------------

/**
 * Single-pass, zero-regex entity replacer for XML/HTML content.
 *
 * Algorithm: scan the string once for '&', read to ';', resolve via map
 * or direct codepoint conversion, build output chunks, join once at the end.
 *
 * Entity lookup priority (highest → lowest):
 *   1. input / runtime  (DOCTYPE entities for current document)
 *   2. persistent external (survive across documents)
 *   3. base named map   (DEFAULT_XML_ENTITIES + user-supplied namedEntities)
 *
 * Both input and external resolve as the 'external' tier for limit purposes.
 * Base map entities resolve as the 'base' tier.
 *
 * Numeric / hex references (&#NNN; / &#xHH;) are resolved directly via
 * String.fromCodePoint() — no map needed. They count as 'base' tier.
 *
 * @example
 * const replacer = new EntityReplacer({ namedEntities: COMMON_HTML });
 * replacer.setExternalEntities({ brand: 'Acme' });
 *
 * const instance = replacer.reset();
 * instance.addInputEntities({ version: '1.0' });
 * instance.encode('&brand; v&version; &lt;'); // 'Acme v1.0 <'
 */
class EntityDecoder {
  /**
   * @param {object} [options]
   * @param {object|null}  [options.namedEntities]        — extra named entities merged into base map
   * @param {object}  [options.limit]                 — security limits
   * @param {number}       [options.limit.maxTotalExpansions=0]  — 0 = unlimited
   * @param {number}       [options.limit.maxExpandedLength=0]   — 0 = unlimited
   * @param {'external'|'base'|'all'|string[]} [options.limit.applyLimitsTo='external']
   *   Which entity tiers count against the security limits:
   *   - 'external' (default) — only input/runtime + persistent external entities
   *   - 'base'               — only DEFAULT_XML_ENTITIES + namedEntities
   *   - 'all'                — every entity regardless of tier
   *   - string[]             — explicit combination, e.g. ['external', 'base']
   * @param {((resolved: string, original: string) => string)|null} [options.postCheck=null]
   * @param {string[]} [options.remove=[]] — entity names (e.g. ['nbsp', '#13']) to delete (replace with empty string)
   * @param {string[]} [options.leave=[]]  — entity names to keep as literal (unchanged in output)
   * @param {object}   [options.ncr]       — Numeric Character Reference controls
   * @param {1.0|1.1}  [options.ncr.xmlVersion=1.0]
   *   XML version governing which codepoint ranges are restricted:
   *   - 1.0 — C0 controls U+0001–U+001F (except U+0009/000A/000D) are prohibited
   *   - 1.1 — C0 controls are allowed when written as NCRs; C1 (U+007F–U+009F) decoded as-is
   * @param {'allow'|'leave'|'remove'|'throw'} [options.ncr.onNCR='allow']
   *   Base action for numeric references. Severity order: allow < leave < remove < throw.
   *   For codepoint ranges that carry a minimum level (surrogates → remove, XML 1.0 C0 → remove),
   *   the effective action is max(onNCR, rangeMinimum).
   * @param {'remove'|'throw'} [options.ncr.nullNCR='remove']
   *   Action for U+0000 (null). 'allow' and 'leave' are clamped to 'remove' since null is never safe.
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} [options.onExternalEntity=null]
   *   Hook called when an external entity is registered via `setExternalEntities()` or
   *   `addExternalEntity()`. Return `ENTITY_ACTION.ALLOW` to accept the entity,
   *   `ENTITY_ACTION.BLOCK` to silently skip it, or `ENTITY_ACTION.THROW` to abort with an error.
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} [options.onInputEntity=null]
   *   Hook called when an input entity is registered via `addInputEntities()`. Return
   *   `ENTITY_ACTION.ALLOW` to accept, `ENTITY_ACTION.BLOCK` to silently skip, or
   *   `ENTITY_ACTION.THROW` to abort with an error.
   */
  constructor(options = {}) {
    this._limit = options.limit || {};
    this._maxTotalExpansions = this._limit.maxTotalExpansions || 0;
    this._maxExpandedLength = this._limit.maxExpandedLength || 0;
    this._postCheck = typeof options.postCheck === 'function' ? options.postCheck : r => r;
    this._limitTiers = parseLimitTiers(this._limit.applyLimitsTo ?? LIMIT_TIER_EXTERNAL);
    this._numericAllowed = options.numericAllowed ?? true;
    // Base map: DEFAULT_XML_ENTITIES + user-supplied extras. Immutable after construction.
    this._baseMap = mergeEntityMaps(XML, options.namedEntities || null);

    // Persistent external entities — survive across documents.
    // Stored as a separate map so reset() never touches them.
    /** @type {Record<string, string>} */
    this._externalMap = Object.create(null);

    // Input / runtime entities — current document only, wiped on reset().
    /** @type {Record<string, string>} */
    this._inputMap = Object.create(null);

    // Per-document counters
    this._totalExpansions = 0;
    this._expandedLength = 0;

    // --- New: remove / leave sets ---
    /** @type {Set<string>} */
    this._removeSet = new Set(options.remove && Array.isArray(options.remove) ? options.remove : []);
    /** @type {Set<string>} */
    this._leaveSet = new Set(options.leave && Array.isArray(options.leave) ? options.leave : []);

    // --- NCR config (parsed into flat fields for hot-path speed) ---
    const ncrCfg = parseNCRConfig(options.ncr);
    this._ncrXmlVersion = ncrCfg.xmlVersion;
    this._ncrOnLevel = ncrCfg.onLevel;
    this._ncrNullLevel = ncrCfg.nullLevel;

    // --- Registration hooks ---
    /** @type {((name: string, value: string) => 'allow'|'block'|'throw')|null} */
    this._onExternalEntity = typeof options.onExternalEntity === 'function'
      ? options.onExternalEntity
      : null;
    /** @type {((name: string, value: string) => 'allow'|'block'|'throw')|null} */
    this._onInputEntity = typeof options.onInputEntity === 'function'
      ? options.onInputEntity
      : null;
  }

  // -------------------------------------------------------------------------
  // Private: registration hook dispatch
  // -------------------------------------------------------------------------

  /**
   * Invoke a registration hook for a single entity name/value pair.
   * Returns true when the entity should be accepted, false when it should be
   * silently skipped (BLOCK), and throws when the hook returns THROW.
   *
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} hook
   * @param {string} name
   * @param {string} value
   * @param {string} context  — used in error messages ('external' | 'input')
   * @returns {boolean}  true = accept, false = skip
   */
  _applyRegistrationHook(hook, name, value, context) {
    if (!hook) return true; // no hook → always accept
    const action = hook(name, value);
    if (action === ENTITY_ACTION.BLOCK) return false;
    if (action === ENTITY_ACTION.THROW) {
      throw new Error(
        `[EntityDecoder] Registration of ${context} entity "&${name};" was rejected by hook`
      );
    }
    return true; // ALLOW or any unknown return value → accept
  }

  // -------------------------------------------------------------------------
  // Persistent external entity registration
  // -------------------------------------------------------------------------

  /**
   * Replace the full set of persistent external entities.
   * All keys are validated — throws on invalid characters.
   * If `onExternalEntity` is set, it is called once per entry; entries that
   * return `ENTITY_ACTION.BLOCK` are silently omitted, `ENTITY_ACTION.THROW`
   * aborts the whole call.
   * @param {Record<string, string | { regex?: RegExp, val: string }>} map
   */
  setExternalEntities(map) {
    if (map) {
      for (const key of Object.keys(map)) {
        EntityDecoder_validateEntityName(key);
      }
    }
    if (!this._onExternalEntity) {
      this._externalMap = mergeEntityMaps(map);
      return;
    }
    // Hook present — resolve values first, then filter
    const flat = mergeEntityMaps(map);
    const filtered = Object.create(null);
    for (const [name, value] of Object.entries(flat)) {
      if (this._applyRegistrationHook(this._onExternalEntity, name, value, 'external')) {
        filtered[name] = value;
      }
    }
    this._externalMap = filtered;
  }

  /**
   * Add a single persistent external entity.
   * If `onExternalEntity` is set it is called before the entity is stored;
   * `ENTITY_ACTION.BLOCK` silently skips storage, `ENTITY_ACTION.THROW` raises.
   * @param {string} key
   * @param {string} value
   */
  addExternalEntity(key, value) {
    EntityDecoder_validateEntityName(key);
    if (typeof value === 'string' && value.indexOf('&') === -1) {
      if (this._applyRegistrationHook(this._onExternalEntity, key, value, 'external')) {
        this._externalMap[key] = value;
      }
    }
  }

  // -------------------------------------------------------------------------
  // Input / runtime entity registration (per document)
  // -------------------------------------------------------------------------

  /**
   * Inject DOCTYPE entities for the current document.
   * Also resets per-document expansion counters.
   * If `onInputEntity` is set it is called once per entry; entries returning
   * `ENTITY_ACTION.BLOCK` are silently omitted, `ENTITY_ACTION.THROW` aborts.
   * @param {Record<string, string | { regx?: RegExp, regex?: RegExp, val: string }>} map
   */
  addInputEntities(map) {
    this._totalExpansions = 0;
    this._expandedLength = 0;
    if (!this._onInputEntity) {
      this._inputMap = mergeEntityMaps(map);
      return;
    }
    const flat = mergeEntityMaps(map);
    const filtered = Object.create(null);
    for (const [name, value] of Object.entries(flat)) {
      if (this._applyRegistrationHook(this._onInputEntity, name, value, 'input')) {
        filtered[name] = value;
      }
    }
    this._inputMap = filtered;
  }

  // -------------------------------------------------------------------------
  // Per-document reset
  // -------------------------------------------------------------------------

  /**
   * Wipe input/runtime entities and reset counters.
   * Call this before processing each new document.
   * @returns {this}
   */
  reset() {
    this._inputMap = Object.create(null);
    this._totalExpansions = 0;
    this._expandedLength = 0;
    return this;
  }

  // -------------------------------------------------------------------------
  // XML version (can be set after construction, e.g. once parser reads <?xml?>)
  // -------------------------------------------------------------------------

  /**
   * Update the XML version used for NCR classification.
   * Call this as soon as the document's `<?xml version="...">` declaration is parsed.
   * @param {1.0|1.1|number} version
   */
  setXmlVersion(version) {
    this._ncrXmlVersion = version === 1.1 ? 1.1 : 1.0;
  }

  // -------------------------------------------------------------------------
  // Primary API
  // -------------------------------------------------------------------------

  /**
   * Replace all entity references in `str` in a single pass.
   *
   * @param {string} str
   * @returns {string}
   */
  decode(str) {
    if (typeof str !== 'string' || str.length === 0) return str;
    //TODO: check if needed
    if (str.indexOf('&') === -1) return str; // fast path — no entities at all

    const original = str;
    const chunks = [];
    const len = str.length;
    let last = 0; // start of next unprocessed literal chunk
    let i = 0;

    const limitExpansions = this._maxTotalExpansions > 0;
    const limitLength = this._maxExpandedLength > 0;
    const checkLimits = limitExpansions || limitLength;

    while (i < len) {
      // Scan forward to next '&'
      if (str.charCodeAt(i) !== 38 /* '&' */) { i++; continue; }

      // --- Found '&' at position i ---

      // Scan forward to ';'
      let j = i + 1;
      while (j < len && str.charCodeAt(j) !== 59 /* ';' */ && (j - i) <= 32) j++;

      if (j >= len || str.charCodeAt(j) !== 59) {
        // No closing ';' within window — treat '&' as literal
        i++;
        continue;
      }

      // Raw token between '&' and ';' (exclusive)
      const token = str.slice(i + 1, j);
      if (token.length === 0) { i++; continue; }

      let replacement;
      let tier; // which limit tier this entity belongs to

      if (this._removeSet.has(token)) {
        // Remove entity: replace with empty string
        replacement = '';
        // If entity was unknown (replacement undefined), we still need a tier for limits.
        // Treat as external tier because it's user-directed removal of an unknown reference.
        if (tier === undefined) {
          tier = LIMIT_TIER_EXTERNAL;
        }
      } else if (this._leaveSet.has(token)) {
        // Do not replace — keep original &token; as literal
        i++;
        continue;
      } else if (token.charCodeAt(0) === 35 /* '#' */) {
        // ---- Numeric / NCR reference ----
        // NCR classification always runs first — prohibited codepoints must be
        // caught regardless of numericAllowed.
        const ncrResult = this._resolveNCR(token);
        if (ncrResult === undefined) {
          // 'leave' action — keep original &token; as-is
          i++;
          continue;
        }
        replacement = ncrResult; // '' for remove, char string for allow
        tier = LIMIT_TIER_BASE;
      } else {
        // ---- Named reference ----
        const resolved = this._resolveName(token);
        replacement = resolved?.value;
        tier = resolved?.tier;
      }

      if (replacement === undefined) {
        // Unknown entity — leave as-is, advance past '&' only
        i++;
        continue;
      }

      // Flush literal chunk before this entity
      if (i > last) chunks.push(str.slice(last, i));
      chunks.push(replacement);
      last = j + 1; // skip past ';'
      i = last;

      // Apply expansion limits only if this tier is being tracked
      if (checkLimits && this._tierCounts(tier)) {
        if (limitExpansions) {
          this._totalExpansions++;
          if (this._totalExpansions > this._maxTotalExpansions) {
            throw new Error(
              `[EntityReplacer] Entity expansion count limit exceeded: ` +
              `${this._totalExpansions} > ${this._maxTotalExpansions}`
            );
          }
        }
        if (limitLength) {
          // delta: replacement.length minus the raw &token; length (token.length + 2 for '&' and ';')
          const delta = replacement.length - (token.length + 2);
          if (delta > 0) {
            this._expandedLength += delta;
            if (this._expandedLength > this._maxExpandedLength) {
              throw new Error(
                `[EntityReplacer] Expanded content length limit exceeded: ` +
                `${this._expandedLength} > ${this._maxExpandedLength}`
              );
            }
          }
        }
      }
    }

    // Flush trailing literal
    if (last < len) chunks.push(str.slice(last));

    // If nothing was replaced, chunks is empty — return original
    const result = chunks.length === 0 ? str : chunks.join('');

    return this._postCheck(result, original);
  }

  // -------------------------------------------------------------------------
  // Private: limit tier check
  // -------------------------------------------------------------------------

  /**
   * Returns true if a resolved entity of the given tier should count
   * against the expansion/length limits.
   * @param {string} tier  — LIMIT_TIER_EXTERNAL | LIMIT_TIER_BASE
   * @returns {boolean}
   */
  _tierCounts(tier) {
    if (this._limitTiers.has(LIMIT_TIER_ALL)) return true;
    return this._limitTiers.has(tier);
  }

  // -------------------------------------------------------------------------
  // Private: entity resolution
  // -------------------------------------------------------------------------

  /**
   * Resolve a named entity token (without & and ;).
   * Priority: inputMap > externalMap > baseMap
   * Returns the resolved value tagged with its limit tier.
   *
   * @param {string} name
   * @returns {{ value: string, tier: string }|undefined}
   */
  _resolveName(name) {
    // input and external both count as 'external' tier for limit purposes —
    // they are injected at runtime and are the untrusted surface.
    if (name in this._inputMap) return { value: this._inputMap[name], tier: LIMIT_TIER_EXTERNAL };
    if (name in this._externalMap) return { value: this._externalMap[name], tier: LIMIT_TIER_EXTERNAL };
    if (name in this._baseMap) return { value: this._baseMap[name], tier: LIMIT_TIER_BASE };
    return undefined;
  }

  /**
   * Classify a codepoint and return the minimum action level that must be applied.
   * Returns -1 when no minimum is imposed (normal allow path).
   *
   * Ranges checked (in priority order):
   *   1. U+0000            — null, governed by nullNCR (always ≥ remove)
   *   2. U+D800–U+DFFF     — surrogates, always prohibited (min: remove)
   *   3. U+0001–U+001F \ {0x09,0x0A,0x0D}  — XML 1.0 restricted C0 (min: remove)
   *      (skipped in XML 1.1 — C0 controls are allowed when written as NCRs)
   *
   * @param {number} cp  — codepoint
   * @returns {number}   — minimum NCR_LEVEL value, or -1 for no restriction
   */
  _classifyNCR(cp) {
    // 1. Null
    if (cp === 0) return this._ncrNullLevel;

    // 2. Surrogates — always prohibited, minimum 'remove'
    if (cp >= 0xD800 && cp <= 0xDFFF) return NCR_LEVEL.remove;

    // 3. XML 1.0 restricted C0 controls
    if (this._ncrXmlVersion === 1.0) {
      if (cp >= 0x01 && cp <= 0x1F && !XML10_ALLOWED_C0.has(cp)) return NCR_LEVEL.remove;
    }

    return -1; // no restriction
  }

  /**
   * Execute a resolved NCR action.
   *
   * @param {number} action   — NCR_LEVEL value
   * @param {string} token    — raw token (e.g. '#38') for error messages
   * @param {number} cp       — codepoint, used only for error messages
   * @returns {string|undefined}
   *   - decoded character string  → 'allow'
   *   - ''                        → 'remove'
   *   - undefined                 → 'leave' (caller must skip past '&' only)
   *   - throws Error              → 'throw'
   */
  _applyNCRAction(action, token, cp) {
    switch (action) {
      case NCR_LEVEL.allow: return String.fromCodePoint(cp);
      case NCR_LEVEL.remove: return '';
      case NCR_LEVEL.leave: return undefined; // signal: keep literal
      case NCR_LEVEL.throw:
        throw new Error(
          `[EntityDecoder] Prohibited numeric character reference ` +
          `&${token}; (U+${cp.toString(16).toUpperCase().padStart(4, '0')})`
        );
      default: return String.fromCodePoint(cp);
    }
  }

  /**
   * Full NCR resolution pipeline for a numeric token.
   *
   * Steps:
   *   1. Parse the codepoint (decimal or hex).
   *   2. Validate the raw codepoint range (NaN, <0, >0x10FFFF).
   *   3. If numericAllowed is false and no minimum restriction applies → leave as-is.
   *   4. Classify the codepoint to find the minimum required action level.
   *   5. Resolve effective action = max(onNCR, minimum).
   *   6. Apply and return.
   *
   * @param {string} token  — e.g. '#38', '#x26', '#X26'
   * @returns {string|undefined}
   *   - string (incl. '')  — replacement ('' = remove)
   *   - undefined          — leave original &token; as-is
   */
  _resolveNCR(token) {
    // Step 1: parse codepoint
    const second = token.charCodeAt(1);
    let cp;
    if (second === 120 /* x */ || second === 88 /* X */) {
      cp = parseInt(token.slice(2), 16);
    } else {
      cp = parseInt(token.slice(1), 10);
    }

    // Step 2: out-of-range → leave as-is unconditionally
    if (Number.isNaN(cp) || cp < 0 || cp > 0x10FFFF) return undefined;

    // Step 3: classify to get minimum action level
    const minimum = this._classifyNCR(cp);

    // Step 4: if numericAllowed is false and no hard minimum → leave
    if (!this._numericAllowed && minimum < NCR_LEVEL.remove) return undefined;

    // Step 5: effective action = max(configured onNCR, range minimum)
    const effective = minimum === -1
      ? this._ncrOnLevel
      : Math.max(this._ncrOnLevel, minimum);

    // Step 6: apply
    return this._applyNCRAction(effective, token, cp);
  }
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/sql.js
/**
 * SQL context patterns — high-precision rules only.
 *
 * These rules have very low false-positive risk and are safe to apply to
 * general user text (names, descriptions, search queries, etc.).
 * All patterns are ReDoS-safe — unlike the `sql-injection` npm package
 * which has an active CVE on its own detection regexes.
 *
 * For exhaustive coverage including noisier heuristics (comment sequences,
 * hex literals, stacked queries with semicolons), use 'SQL-STRICT' instead.
 * Apply 'SQL-STRICT' only to strings that are specifically SQL fragments,
 * not to general free-text fields.
 */

const SQL_PATTERNS = [
  {
    id: 'sql-block-comment-open',
    description: 'SQL block comment open: /* ... */ — unusual in legitimate user text',
    pattern: /\/\*/,
  },
  {
    id: 'sql-union-select',
    description: 'UNION SELECT — most common SQL injection aggregation attack',
    pattern: /\bUNION\s{1,20}(?:ALL\s{1,20})?SELECT\b/i,
  },
  {
    id: 'sql-drop-table',
    description: 'DROP TABLE — destructive DDL injection',
    pattern: /\bDROP\s{1,20}TABLE\b/i,
  },
  {
    id: 'sql-drop-database',
    description: 'DROP DATABASE — destructive DDL injection',
    pattern: /\bDROP\s{1,20}DATABASE\b/i,
  },
  {
    id: 'sql-insert-into',
    description: 'INSERT INTO — data injection',
    pattern: /\bINSERT\s{1,20}INTO\b/i,
  },
  {
    id: 'sql-delete-from',
    description: 'DELETE FROM — data deletion injection',
    pattern: /\bDELETE\s{1,20}FROM\b/i,
  },
  {
    id: 'sql-update-set',
    description: 'UPDATE ... SET — data modification injection',
    // Allows arbitrary content between UPDATE and SET (table name, alias, etc.)
    pattern: /\bUPDATE\b[\s\S]{1,60}\bSET\b/i,
  },
  {
    id: 'sql-exec-xp',
    description: 'EXEC xp_ — MSSQL extended stored procedure execution',
    pattern: /\bEXEC(?:UTE)?\s{1,20}xp_/i,
  },
  {
    id: 'sql-tautology-string',
    description: "Classic string tautology: ' OR '1'='1 or \" OR \"1\"=\"1\"",
    // Last quote is optional — injection may truncate it: ' OR '1'='1--
    pattern: /'\s{0,10}OR\s{0,10}'[^']{0,20}'\s*=\s*'[^']{0,20}/i,
  },
  {
    id: 'sql-tautology-numeric',
    description: 'Numeric tautology: OR 1=1',
    pattern: /\bOR\s{1,10}1\s*=\s*1\b/i,
  },
  {
    id: 'sql-always-true-zero',
    description: 'Numeric tautology: OR 0=0',
    pattern: /\bOR\s{1,10}0\s*=\s*0\b/i,
  },
  {
    id: 'sql-sleep-benchmark',
    description: 'Time-based blind injection: SLEEP() or BENCHMARK()',
    pattern: /\b(?:SLEEP|BENCHMARK)\s*\(/i,
  },
  {
    id: 'sql-waitfor-delay',
    description: 'MSSQL time-based blind injection: WAITFOR DELAY',
    pattern: /\bWAITFOR\s{1,20}DELAY\b/i,
  },
  {
    id: 'sql-char-function',
    description: 'CHAR() function — used to obfuscate injected strings',
    pattern: /\bCHAR\s*\(\s*\d{1,3}/i,
  },
  {
    id: 'sql-information-schema',
    description: 'INFORMATION_SCHEMA — reconnaissance query for table/column enumeration',
    pattern: /\bINFORMATION_SCHEMA\b/i,
  },
];

/* export default */ const sql = (SQL_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/sql-strict.js
/**
 * SQL-STRICT context patterns.
 *
 * Extends the base 'SQL' context with three additional rules that are
 * effective at detecting real injections but carry a higher false-positive
 * risk on general free-text input.
 *
 * Use 'SQL-STRICT' when:
 *   - The string is specifically a SQL fragment or database identifier
 *   - You control the input domain (e.g. a dedicated SQL search field)
 *   - You can tolerate occasional false positives in exchange for broader coverage
 *
 * Use 'SQL' (not STRICT) when:
 *   - The field is general user text (names, descriptions, comments)
 *   - False positives would block legitimate content (e.g. "see note -- above")
 *
 * Rules moved here from 'SQL' due to false-positive risk:
 *
 *   sql-line-comment   — "--" fires on "see note -- above", "value--", CSS var(--primary)
 *   sql-stacked-query  — "; SELECT" fires on legitimate prose with semicolons + SQL words
 *   sql-hex-encoding   — "0xDEAD" fires on hex values in technical docs and log output
 */



const SQL_STRICT_EXTRA = [
  {
    id: 'sql-line-comment',
    description: 'SQL line comment: -- followed by whitespace or end of string',
    pattern: /--(?:\s|$)/,
  },
  {
    id: 'sql-stacked-query',
    description: 'Stacked queries: semicolon immediately followed by a SQL keyword',
    pattern: /;\s{0,10}(?:SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC)\b/i,
  },
  {
    id: 'sql-hex-encoding',
    description: 'Hex-encoded string injection: 0x41414141 style (MySQL)',
    pattern: /\b0x[0-9a-f]{4,}/i,
  },
];

// SQL-STRICT = all base SQL rules + the three noisy extras
const SQL_STRICT_PATTERNS = [...sql, ...SQL_STRICT_EXTRA];

/* export default */ const sql_strict = (SQL_STRICT_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/html.js
/**
 * HTML context patterns.
 *
 * Detects XSS vectors that are dangerous when a string ends up rendered as HTML.
 * All patterns use bounded quantifiers to ensure linear-time matching (ReDoS-safe).
 *
 * Each entry is { pattern: RegExp, id: string, description: string }
 * so callers can inspect which rule fired if they need to.
 */

const HTML_PATTERNS = [
  {
    id: 'html-script-open',
    description: '<script opening tag',
    pattern: /<script[\s>/]/i,
  },
  {
    id: 'html-script-close',
    description: '</script closing tag',
    pattern: /<\/script[\s>]/i,
  },
  {
    id: 'html-javascript-protocol',
    description: 'javascript: URI scheme (with optional whitespace/encoding)',
    // Handles j&#x61;vascript:, j\u0061vascript:, and whitespace variants
    pattern: /j[\t\n\r ]*a[\t\n\r ]*v[\t\n\r ]*a[\t\n\r ]*s[\t\n\r ]*c[\t\n\r ]*r[\t\n\r ]*i[\t\n\r ]*p[\t\n\r ]*t[\t\n\r ]*:/i,
  },
  {
    id: 'html-vbscript-protocol',
    description: 'vbscript: URI scheme',
    pattern: /vbscript[\t\n\r ]*:/i,
  },
  {
    id: 'html-data-html',
    description: 'data:text/html URI — can execute scripts in browsers',
    pattern: /data[\t\n\r ]*:[\t\n\r ]*text\/html/i,
  },
  {
    id: 'html-data-xhtml',
    description: 'data:application/xhtml+xml URI',
    pattern: /data[\t\n\r ]*:[\t\n\r ]*application\/xhtml/i,
  },
  {
    id: 'html-data-svg',
    description: 'data:image/svg+xml URI — can execute scripts',
    pattern: /data[\t\n\r ]*:[\t\n\r ]*image\/svg\+xml/i,
  },
  {
    id: 'html-inline-event-handler',
    description: 'Inline event handler attributes: onclick=, onerror=, onload=, etc.',
    // \bon ensures we match a word boundary so "phonetic=" is not caught
    pattern: /\bon\w{1,30}\s*=/i,
  },
  {
    id: 'html-entity-obfuscated-script',
    description: 'HTML-entity-encoded <script (e.g. &#x3C;script or &lt;script)',
    // Entities include optional trailing semicolon: &#x3C; or &#x3C (both valid in HTML5)
    pattern: /(?:&#x0*3[Cc];?|&#0*60;?|&lt;)\s*script/i,
  },
  {
    id: 'html-entity-obfuscated-javascript',
    description: 'HTML-entity-encoded javascript: (partial — catches common &#106; or &#x6a; for "j")',
    pattern: /(?:&#x0*6[Aa];?|&#0*106;?)\s*(?:&#x0*61;?|a)[\s\S]{0,80}script\s*:/i,
  },
  {
    id: 'html-style-expression',
    description: 'CSS expression() — IE-era code execution in style attributes',
    pattern: /style[\s\S]{0,20}expression\s*\(/i,
  },
  {
    id: 'html-object-embed',
    description: '<object or <embed tags that can load active content',
    pattern: /<(?:object|embed)[\s>/]/i,
  },
  {
    id: 'html-base-tag',
    description: '<base href= — can hijack all relative URLs on a page',
    pattern: /<base[\s>]/i,
  },
  {
    id: 'html-meta-refresh',
    description: '<meta http-equiv="refresh" — can redirect users',
    pattern: /<meta[\s\S]{0,40}http-equiv[\s\S]{0,20}refresh/i,
  },
  {
    id: 'html-srcdoc',
    description: 'srcdoc= attribute on iframes — embeds HTML that can run scripts',
    pattern: /srcdoc\s*=/i,
  },
  {
    id: 'html-iframe',
    description: '<iframe tag',
    pattern: /<iframe[\s>/]/i,
  },
  {
    id: 'html-form',
    description: '<form tag — can be used for phishing / credential harvesting injection',
    pattern: /<form[\s>/]/i,
  },
];

/* export default */ const html = (HTML_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/xml.js
/**
 * XML context patterns.
 *
 * Detects injection vectors that are specifically dangerous when a string
 * is inserted into an XML document (not HTML rendering context).
 *
 * Key distinction from HTML: these patterns target parser-level attacks —
 * things that can confuse or subvert an XML parser, trigger external entity
 * resolution, or inject DTD content. HTML rendering concerns (XSS) belong
 * in the HTML context.
 */

const XML_PATTERNS = [
  {
    id: 'xml-cdata-injection',
    description: 'CDATA section injection: <![CDATA[ breaks out of text node context',
    pattern: /<!\[CDATA\[/i,
  },
  {
    id: 'xml-cdata-close',
    description: 'CDATA close sequence: ]]> can terminate an enclosing CDATA section',
    pattern: /\]\]>/,
  },
  {
    id: 'xml-processing-instruction',
    description: 'XML processing instruction: <?xml-stylesheet or <?php etc.',
    pattern: /<\?(?:xml[\- ]|php|asp)/i,
  },
  {
    id: 'xml-doctype-injection',
    description: 'DOCTYPE declaration embedded in content — can define entities',
    // Match <!DOCTYPE followed by end-of-string, whitespace, or [ (internal subset)
    pattern: /<!DOCTYPE(?:[\s[]|$)/i,
  },
  {
    id: 'xml-entity-system',
    description: 'SYSTEM keyword — used in external entity declarations (XXE)',
    pattern: /\bSYSTEM\s+["']/i,
  },
  {
    id: 'xml-entity-public',
    description: 'PUBLIC keyword — used in external entity declarations (XXE)',
    pattern: /\bPUBLIC\s+["']/i,
  },
  {
    id: 'xml-entity-declaration',
    description: '<!ENTITY declaration — defines entities, potential XXE or entity expansion',
    pattern: /<!ENTITY[\s%]/i,
  },
  {
    id: 'xml-billion-laughs',
    description: 'Entity reference chaining / billion laughs: repeated &eX; style references',
    // Heuristic: 3+ consecutive entity refs suggests expansion attack
    pattern: /(?:&\w{1,20};){3,}/,
  },
  {
    id: 'xml-namespace-confusion',
    description: 'xmlns: attribute injection — can redefine namespaces to confuse parsers',
    // pattern: /\bxmlns\s*(?::\w{1,40})?\s*=/i,
    pattern: /\bxmlns(?::\w{1,40})?\s*=/i,
  },
  {
    id: 'xml-comment-injection',
    description: '<!-- comment injection — can hide content from some parsers',
    pattern: /<!--/,
  },
  {
    id: 'xml-comment-close',
    description: '--> closes an enclosing XML comment',
    pattern: /-->/,
  },
  {
    id: 'xml-pi-close',
    description: '?> closes an enclosing processing instruction',
    pattern: /\?>/,
  },
];

/* export default */ const contexts_xml = (XML_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/svg.js
/**
 * SVG context patterns.
 *
 * SVG is XML-based but renders in browsers, giving it a unique attack surface
 * that combines XML parser behaviour with browser rendering and JavaScript execution.
 *
 * Many of these vectors bypass HTML sanitizers that don't understand SVG semantics
 * (DOMPurify has documented bypass vulnerabilities specifically in SVG/XML context).
 */

const SVG_PATTERNS = [
  {
    id: 'svg-script-element',
    description: '<script element inside SVG executes JavaScript',
    pattern: /<script[\s>/]/i,
  },
  {
    id: 'svg-xlink-href-javascript',
    description: 'xlink:href with javascript: — classic SVG XSS via <a> or <use>',
    pattern: /xlink\s*:\s*href\s*=\s*["']?\s*javascript\s*:/i,
  },
  {
    id: 'svg-href-javascript',
    description: 'href= with javascript: in SVG context (<a>, <animate>, etc.)',
    pattern: /href\s*=\s*["']?\s*javascript\s*:/i,
  },
  {
    id: 'svg-foreignobject',
    description: '<foreignObject embeds HTML inside SVG — can execute scripts',
    pattern: /<foreignObject[\s>/]/i,
  },
  {
    id: 'svg-use-external',
    description: '<use xlink:href or href pointing to external resource (non-fragment URL)',
    // Match <use with href= where the value starts with a non-# character (external URL)
    // [\"'][^#] catches quoted values not starting with #; [^\"'#\s>] catches unquoted
    pattern: /<use[\s\S]{0,60}(?:xlink\s*:\s*)?href\s*=\s*(?:["'][^#]|[^"'#\s>])/i,
  },
  {
    id: 'svg-animate-href',
    description: '<animate attributeName="href" — can dynamically change href to javascript:',
    pattern: /<animate[\s\S]{0,80}attributeName\s*=\s*["'][\s]*href["']/i,
  },
  {
    id: 'svg-animate-xlinkhref',
    description: '<animate attributeName="xlink:href"',
    pattern: /<animate[\s\S]{0,80}attributeName\s*=\s*["'][\s]*xlink\s*:\s*href["']/i,
  },
  {
    id: 'svg-set-javascript',
    description: '<set to="javascript:..." — sets an attribute to a javascript: URI',
    pattern: /<set[\s\S]{0,80}to\s*=\s*["']?\s*javascript\s*:/i,
  },
  {
    id: 'svg-event-handler',
    description: 'SVG-specific event handler attributes: onload=, onerror=, onactivate=, etc.',
    pattern: /\bon(?:load|error|activate|begin|end|repeat|focus|blur|click|mouse\w{1,20}|key\w{1,20})\s*=/i,
  },
  {
    id: 'svg-handler-generic',
    description: 'Generic on* handler catch-all for SVG attributes',
    pattern: /\bon\w{1,30}\s*=/i,
  },
  {
    id: 'svg-filter-feimage',
    description: '<feImage href= — filter primitive that can load external resources',
    pattern: /<feImage[\s\S]{0,80}(?:xlink\s*:\s*)?href\s*=/i,
  },
  {
    id: 'svg-image-external',
    description: '<image xlink:href with http/https or javascript protocol',
    pattern: /<image[\s\S]{0,80}(?:xlink\s*:\s*)?href\s*=\s*["']?\s*(?:https?|javascript)\s*:/i,
  },
  {
    id: 'svg-style-javascript',
    description: 'style= attribute containing javascript: (e.g. background:url(javascript:...))',
    pattern: /style\s*=[\s\S]{0,60}javascript\s*:/i,
  },
];

/* export default */ const svg = (SVG_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/shell.js
/**
 * SHELL context patterns.
 *
 * Detects shell injection vectors and path traversal patterns.
 * Designed for use when a string will be passed to a shell command,
 * used as a file path, or interpolated into OS-level operations.
 */

const SHELL_PATTERNS = [
  {
    id: 'shell-path-traversal-unix',
    description: 'Unix path traversal: ../  — climbing the directory tree',
    pattern: /\.\.\//,
  },
  {
    id: 'shell-path-traversal-windows',
    description: 'Windows path traversal: ..\\ — climbing the directory tree',
    pattern: /\.\.\\/,
  },
  {
    id: 'shell-path-traversal-encoded',
    description: 'URL-encoded path traversal: %2e%2e or %2f variants',
    pattern: /%2e%2e|%2f\.\.|\.\.%2f/i,
  },
  {
    id: 'shell-null-byte',
    description: 'Null byte injection: \\x00 or %00 — truncates strings in C-backed functions',
    pattern: /\x00|%00/,
  },
  {
    id: 'shell-semicolon',
    description: 'Semicolon command separator: cmd1; cmd2',
    pattern: /;/,
  },
  {
    id: 'shell-pipe',
    description: 'Pipe operator: cmd1 | cmd2',
    pattern: /\|/,
  },
  {
    id: 'shell-and-operator',
    description: 'AND operator: cmd1 && cmd2',
    pattern: /&&/,
  },
  {
    id: 'shell-or-operator',
    description: 'OR operator: cmd1 || cmd2',
    pattern: /\|\|/,
  },
  {
    id: 'shell-backtick',
    description: 'Backtick command substitution: `cmd`',
    pattern: /`/,
  },
  {
    id: 'shell-dollar-paren',
    description: 'Dollar-paren command substitution: $(cmd)',
    pattern: /\$\(/,
  },
  {
    id: 'shell-dollar-brace',
    description: 'Dollar-brace variable expansion: ${var} — can be abused for injection',
    pattern: /\$\{/,
  },
  {
    id: 'shell-redirect-out',
    description: 'Output redirection: cmd > file or cmd >> file',
    pattern: />{1,2}/,
  },
  {
    id: 'shell-redirect-in',
    description: 'Input redirection: cmd < file',
    pattern: /</,
  },
  {
    id: 'shell-newline-injection',
    description: 'Newline injection: \\n or \\r — can inject new shell commands',
    pattern: /[\n\r]/,
  },
  {
    id: 'shell-glob-star',
    description: 'Glob expansion: * or ? — can expand to unintended files',
    // Only flag when combined with path separators to reduce false positives
    pattern: /[/\\][*?]/,
  },
  {
    id: 'shell-absolute-root',
    description: 'Absolute root path injection: string starting with / or \\ (Windows UNC)',
    pattern: /^(?:\/|\\\\)/,
  },
  {
    id: 'shell-windows-drive',
    description: 'Windows drive letter path injection: C:\\ or D:/',
    pattern: /^[a-zA-Z]:[/\\]/,
  },
  {
    id: 'shell-curl-wget',
    description: 'curl/wget with URL or flags — can exfiltrate data or download payloads',
    // Require a URL scheme (http/https/ftp) or a flag (-) to reduce false positives
    // "curl is a tool" won't match; "curl http://..." or "curl -s ..." will
    pattern: /\b(?:curl|wget)\s+(?:https?:\/\/|ftp:\/\/|-)/i,
  },
];

/* export default */ const shell = (SHELL_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/redos.js
/**
 * REDOS context patterns.
 *
 * Detects strings that, if used as regular expressions, could cause
 * catastrophic backtracking (ReDoS — Regular Expression Denial of Service).
 *
 * These patterns detect the structural forms that lead to exponential or
 * polynomial backtracking in NFA-based regex engines (V8, PCRE, Java, etc.).
 *
 * Use this context when user-supplied strings will be compiled into RegExp objects.
 */

const REDOS_PATTERNS = [
  {
    id: 'redos-nested-quantifier-plus',
    description: 'Nested + quantifier inside a group with outer quantifier: (a+)+, (.+b)*, etc.',
    // Matches any group containing a + quantifier, with an outer * or + — catches (a+)+, (.+b)*, etc.
    pattern: /\([^)]*\+[^)]*\)[+*]/,
  },
  {
    id: 'redos-nested-quantifier-star',
    description: 'Nested * quantifier: (a*)* or (a*)+ — catastrophic backtracking',
    pattern: /\([^)]*\*[^)]*\)[*+]/,
  },
  {
    id: 'redos-nested-groups',
    description: 'Doubly nested quantified groups: ((a+)+) — guaranteed catastrophic',
    pattern: /\(\([^)]{0,40}\)[+*]\)[+*]/,
  },
  {
    id: 'redos-alternation-overlap',
    description: 'Overlapping alternation under quantifier: (a|a)+ — ambiguous NFA paths',
    // Detect repeated identical alternatives under a quantifier
    pattern: /\(([^|()]{1,20})\|(?:\1)(?:\|[^|()]{1,20}){0,5}\)[+*?]{1,2}/,
  },
  {
    id: 'redos-star-plus-concat',
    description: '(x*x)+ pattern — triggers super-linear backtracking',
    pattern: /\([^)]{0,10}\*[^)]{0,10}\)[+*]/,
  },
  {
    id: 'redos-dot-star-greedy',
    description: '(.*){n,} or (.+){n,} — repeated greedy dot quantifiers',
    pattern: /\(\.[*+]\)\{?\d/,
  },
  {
    id: 'redos-large-repetition',
    description: 'Very large fixed or range repetition count {1000,} or {1000,n} — denial of service via backtracking',
    // Matches { followed by 4+ digits (≥1000), then optional ,digits }
    pattern: /\{\d{4,}(?:,\d*)?\}/,
  },
  {
    id: 'redos-catastrophic-alternation',
    description: 'Long alternation with many similar branches — polynomial backtracking risk',
    // Heuristic: 10+ pipe-separated alternatives in a single group
    pattern: /\([^)]{0,200}(?:\|[^|)]{0,50}){9,}\)/,
  },
];

/* export default */ const redos = (REDOS_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/nosql.js
/**
 * NOSQL context patterns.
 *
 * Detects injection vectors specific to NoSQL databases (primarily MongoDB)
 * and JavaScript-evaluated queries.
 *
 * Attack categories:
 *   1. MongoDB query operator injection: $where, $ne, $gt, $regex, $or, $and, etc.
 *      These operators, when injected into a JSON query object, can bypass
 *      authentication or exfiltrate data without knowing passwords.
 *
 *   2. JavaScript execution: $where clauses execute arbitrary JS server-side.
 *
 *   3. Prototype pollution: __proto__, constructor.prototype — can corrupt
 *      the prototype chain of all objects in the Node.js process.
 *
 * Pattern note: MongoDB operators appear as JSON keys. In JSON, keys are
 * quoted: {"$where": ...} so the pattern must allow an optional closing
 * quote between the operator name and the colon: /\$where["'\s]*:/
 */

// Shared suffix: optional closing quote/whitespace before the colon
// Handles: $op: (bare), "$op": (JSON), '$op': (single-quoted)
const SEP = /["'\s]*:/;
const nosql_sep = '["\'\\s]*:';

const NOSQL_PATTERNS = [
  // ─── MongoDB $ operator injection ────────────────────────────────────────
  {
    id: 'nosql-where-operator',
    description: '$where — executes arbitrary JavaScript server-side in MongoDB',
    pattern: new RegExp(`\\$where${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-ne-operator',
    description: '$ne — "not equal" operator used to bypass equality checks',
    pattern: new RegExp(`\\$ne${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-gt-operator',
    description: '$gt — "greater than" used to bypass password/value checks',
    pattern: new RegExp(`\\$gte?${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-lt-operator',
    description: '$lt / $lte — "less than" bypass variants',
    pattern: new RegExp(`\\$lte?${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-regex-operator',
    description: '$regex — can be used to extract data character by character (blind injection)',
    pattern: new RegExp(`\\$regex${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-or-operator',
    description: '$or — logical OR; used to create always-true conditions',
    pattern: new RegExp(`\\$or${nosql_sep}\\s*\\[`, 'i'),
  },
  {
    id: 'nosql-and-operator',
    description: '$and — logical AND operator injection',
    pattern: new RegExp(`\\$and${nosql_sep}\\s*\\[`, 'i'),
  },
  {
    id: 'nosql-nor-operator',
    description: '$nor — logical NOR operator injection',
    pattern: new RegExp(`\\$nor${nosql_sep}\\s*\\[`, 'i'),
  },
  {
    id: 'nosql-exists-operator',
    description: '$exists — can enumerate fields to determine schema',
    pattern: new RegExp(`\\$exists${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-in-operator',
    description: '$in — matches any value in a list; can enumerate values',
    pattern: new RegExp(`\\$in${nosql_sep}\\s*\\[`, 'i'),
  },
  {
    id: 'nosql-expr-operator',
    description: '$expr — allows aggregation expressions in queries (MongoDB 3.6+)',
    pattern: new RegExp(`\\$expr${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-function-operator',
    description: '$function — executes arbitrary JavaScript in MongoDB 4.4+',
    pattern: new RegExp(`\\$function${nosql_sep}`, 'i'),
  },
  {
    id: 'nosql-accumulator-operator',
    description: '$accumulator — custom aggregation with arbitrary JS execution',
    pattern: new RegExp(`\\$accumulator${nosql_sep}`, 'i'),
  },
  // ─── Prototype pollution ─────────────────────────────────────────────────
  {
    id: 'nosql-proto-pollution',
    description: '__proto__ — prototype pollution via object key injection',
    pattern: /__proto__/,
  },
  {
    id: 'nosql-constructor-prototype',
    description: 'constructor.prototype — alternative prototype pollution vector (dot notation or JSON key)',
    // Matches dot-notation (obj.constructor.prototype) and JSON key adjacency
    // ("constructor": {"prototype": ...})
    pattern: /constructor[\s"':.,{\[]*prototype/i,
  },
  {
    id: 'nosql-proto-bracket',
    description: '["__proto__"] — bracket-notation prototype pollution',
    pattern: /\[["']__proto__["']\]/,
  },
];

/* export default */ const nosql = (NOSQL_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/contexts/log.js
/**
 * LOG context patterns.
 *
 * Detects injection vectors that are dangerous when a string is written
 * to a log file, passed to a logging framework, or interpolated into
 * a log message that will be parsed or displayed.
 *
 * Attack categories:
 *   1. CRLF injection — injects fake log lines by embedding newlines
 *   2. Log4Shell (CVE-2021-44228) — ${jndi:...} triggers JNDI lookup in Log4j
 *   3. SSTI in log templates — {{...}}, #{...} trigger template evaluation
 *      if the log message is passed through a template engine
 *   4. Null byte injection — truncates log entries in some implementations
 *   5. ANSI escape injection — manipulates terminal output when logs are
 *      tailed in a terminal (colour codes, cursor movement, etc.)
 *
 * Note: Newline characters (\n, \r) will produce false positives for
 * multi-line legitimate values. Use this context only for single-line
 * log field values (usernames, IDs, request parameters, etc.).
 */

const LOG_PATTERNS = [
  // ─── CRLF / newline injection ─────────────────────────────────────────────
  {
    id: 'log-crlf-injection',
    description: 'CRLF injection: literal \\r or \\n embeds fake log lines',
    pattern: /[\r\n]/,
  },
  {
    id: 'log-url-encoded-crlf',
    description: 'URL-encoded CRLF: %0d, %0a, %0D, %0A — decoded by some log parsers',
    pattern: /%0[dDaA]/,
  },
  {
    id: 'log-unicode-newline',
    description: 'Unicode newline variants: U+2028 (line separator), U+2029 (paragraph separator)',
    pattern: /[\u2028\u2029]/,
  },

  // ─── Log4Shell / JNDI injection (CVE-2021-44228) ─────────────────────────
  {
    id: 'log-log4shell-jndi',
    description: 'Log4Shell: ${jndi:...} triggers remote code execution in Apache Log4j',
    pattern: /\$\{jndi\s*:/i,
  },
  {
    id: 'log-log4shell-obfuscated',
    description: 'Obfuscated Log4Shell: ${::-j}... lookup-bypass prefix used to evade WAF detection',
    // ${::- is the Log4j lookup-bypass escape sequence; presence alone is suspicious
    pattern: /\$\{::-/,
  },
  {
    id: 'log-log4j-lookup',
    description: 'Log4j lookup syntax: ${env:...}, ${sys:...}, ${ctx:...} — data exfiltration',
    pattern: /\$\{(?:env|sys|ctx|main|map|sd|web|docker|k8s|spring)\s*:/i,
  },

  // ─── Server-Side Template Injection (SSTI) in log messages ───────────────
  {
    id: 'log-ssti-double-brace',
    description: 'SSTI double-brace: {{expression}} — Jinja2, Twig, Handlebars, etc.',
    pattern: /\{\{[\s\S]{0,80}\}\}/,
  },
  {
    id: 'log-ssti-hash-brace',
    description: 'SSTI hash-brace: #{expression} — Thymeleaf, Velocity, Ruby ERB',
    pattern: /#\{[\s\S]{0,80}\}/,
  },
  {
    id: 'log-ssti-dollar-brace',
    description: 'SSTI/EL injection: ${expression with operators or method calls} — JSP EL, Freemarker, SpEL',
    // Require that the ${...} content looks like an expression, not a plain variable name.
    // Flags if the content contains: . ( * + operators, or known SSTI keywords.
    // This avoids flagging ${PATH}, ${HOME} etc. (plain shell variables).
    pattern: /\$\{[^}]*(?:\.|\(|\*|\+|\bclass\b|\bruntime\b|\bprocess\b|\bexec\b)[^}]{0,80}\}/i,
  },
  {
    id: 'log-ssti-percent-tag',
    description: 'SSTI ERB/ASP tag: <%= expression %> — Ruby ERB, ASP',
    pattern: /<%=[\s\S]{0,80}%>/,
  },

  // ─── Null byte ────────────────────────────────────────────────────────────
  {
    id: 'log-null-byte',
    description: 'Null byte: \\x00 or %00 — can truncate log entries in C-backed loggers',
    pattern: /\x00|%00/,
  },

  // ─── ANSI escape injection ────────────────────────────────────────────────
  {
    id: 'log-ansi-escape',
    description: 'ANSI escape sequence: ESC[ — can manipulate terminal output when logs are tailed',
    pattern: /\x1b\[/,
  },
];

/* export default */ const log = (LOG_PATTERNS);

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-unsafe@2.0.2/node_modules/is-unsafe/src/index.js
/**
 * is-unsafe v2
 *
 * Zero-dependency, DOM-free, pure predicate for detecting unsafe strings
 * across HTML, XML, SVG, SQL, SQL-STRICT, SHELL, REDOS, NOSQL, and LOG contexts.
 *
 * v2 change: contexts are imported as named pattern arrays rather than resolved
 * via a string-keyed registry. This makes each context independently
 * tree-shakeable — bundlers can drop any context you never import.
 *
 * @module is-unsafe
 */

// ─── Context pattern arrays (named exports) ────────────────────────────────
// Import only the ones you need. Each is independently tree-shakeable.










// SQL-STRICT needs a quoted identifier because of the hyphen



// ─── VALID_CONTEXTS convenience re-export ─────────────────────────────────
// Importing this pulls in ALL contexts. Use it only when you need all of them
// (e.g. for validation UI, tooling, or exhaustive audits).
// If you only need a subset, import the named contexts directly instead.










// ─── Attach labels to named contexts ──────────────────────────────────────
// Each built-in PatternList carries its canonical name so matchList can read
// list.label directly — no registry lookup needed at match time.
// Custom PatternLists default to 'CUSTOM' unless the caller sets list.label.

html.label       = 'HTML';
contexts_xml.label        = 'XML';
svg.label        = 'SVG';
sql.label        = 'SQL';
sql_strict.label = 'SQL-STRICT';
shell.label      = 'SHELL';
redos.label      = 'REDOS';
nosql.label      = 'NOSQL';
log.label        = 'LOG';

const VALID_CONTEXTS = Object.freeze({
  HTML: html,
  XML: contexts_xml,
  SVG: svg,
  SQL: sql,
  'SQL-STRICT': sql_strict,
  SHELL: shell,
  REDOS: redos,
  NOSQL: nosql,
  LOG: log,
});

// ─── Types ────────────────────────────────────────────────────────────────

/**
 * @typedef {{ id: string, description: string, pattern: RegExp }} Rule
 */

/**
 * @typedef {Rule[]} PatternList
 */

/**
 * @typedef {Object} MatchResult
 * @property {string} context     - Label identifying which context matched ('HTML', 'CUSTOM', etc.)
 * @property {string} id          - Rule identifier
 * @property {string} description - Human-readable description of what was matched
 * @property {RegExp} pattern     - The pattern that matched
 */

// ─── Internal helpers ──────────────────────────────────────────────────────

/**
 * @param {unknown} value
 */
function assertString(value) {
  if (typeof value !== 'string') {
    throw new TypeError(
      `is-unsafe: first argument must be a string, got ${typeof value}`
    );
  }
}

/**
 * @param {unknown} context
 */
function assertContext(context) {
  if (context instanceof RegExp) return;

  if (Array.isArray(context)) {
    if (context.length === 0) {
      throw new TypeError('is-unsafe: context must not be an empty array');
    }
    // Detect array-of-arrays vs flat pattern list
    if (Array.isArray(context[0])) {
      // Array of PatternLists
      for (const list of context) {
        if (!Array.isArray(list) || list.length === 0) {
          throw new TypeError(
            'is-unsafe: each context in the array must be a non-empty pattern array (PatternList)'
          );
        }
      }
    }
    // else: flat PatternList — trust it, no deep validation needed
    return;
  }

  throw new TypeError(
    `is-unsafe: second argument must be a PatternList (e.g. HTML), ` +
    `an array of PatternLists (e.g. [HTML, XML]), or a RegExp. Got: ${typeof context}`
  );
}

/**
 * Normalise any valid context arg into an array of PatternLists.
 *
 * @param {Rule[]|Rule[][]|RegExp} context
 * @returns {{ lists: Rule[][]|null, regex: RegExp|null }}
 */
function normalise(context) {
  if (context instanceof RegExp) return { lists: null, regex: context };
  // Distinguish PatternList (array of rule objects) from array of PatternLists
  if (Array.isArray(context[0])) return { lists: context, regex: null };
  return { lists: [context], regex: null };
}

/**
 * Test value against a single PatternList. Returns the first MatchResult or null.
 *
 * @param {string} value
 * @param {Rule[]} list
 * @returns {MatchResult|null}
 */
function matchList(value, list) {
  const label = list.label ?? 'CUSTOM';
  for (const rule of list) {
    if (rule.pattern.test(value)) {
      return { context: label, id: rule.id, description: rule.description, pattern: rule.pattern };
    }
  }
  return null;
}

// ─── Public API ───────────────────────────────────────────────────────────

/**
 * Returns `true` if `value` is unsafe in the given context(s), `false` otherwise.
 *
 * @param {string} value - The string to test
 * @param {PatternList | PatternList[] | RegExp} context
 *   - A PatternList imported from is-unsafe (e.g. `HTML`, `XML`)
 *   - An array of PatternLists — returns true if unsafe in **any** of them
 *   - A custom RegExp — returns true if the pattern matches
 * @returns {boolean}
 *
 * @example
 * import { isUnsafe, HTML, SQL } from 'is-unsafe';
 *
 * isUnsafe('<script>alert(1)</script>', HTML)       // true
 * isUnsafe('hello world', HTML)                     // false
 * isUnsafe('value', [HTML, SQL])                    // false
 * isUnsafe('value', /my-pattern/i)                  // false
 */
function isUnsafe(value, context) {
  assertString(value);
  assertContext(context);

  const { lists, regex } = normalise(context);

  if (regex) return regex.test(value);

  for (const list of lists) {
    if (matchList(value, list) !== null) return true;
  }
  return false;
}

/**
 * Like `isUnsafe`, but returns the first `MatchResult` describing **why**
 * the value was flagged, or `null` if it is safe.
 *
 * @param {string} value
 * @param {PatternList | PatternList[] | RegExp} context
 * @returns {MatchResult|null}
 *
 * @example
 * import { whyUnsafe, HTML } from 'is-unsafe';
 *
 * whyUnsafe('<script>alert(1)</script>', HTML)
 * // { context: 'HTML', id: 'html-script-open', description: '...', pattern: /.../ }
 */
function whyUnsafe(value, context) {
  assertString(value);
  assertContext(context);

  const { lists, regex } = normalise(context);

  if (regex) {
    return regex.test(value)
      ? { context: 'CUSTOM', id: 'custom-regex', description: 'Matched caller-supplied pattern', pattern: regex }
      : null;
  }

  for (const list of lists) {
    const result = matchList(value, list);
    if (result !== null) return result;
  }
  return null;
}

/**
 * Returns **all** matching rules across the given context(s), or an empty
 * array if the value is safe. Useful for comprehensive auditing.
 *
 * @param {string} value
 * @param {PatternList | PatternList[] | RegExp} context
 * @returns {MatchResult[]}
 */
function allUnsafe(value, context) {
  assertString(value);
  assertContext(context);

  const { lists, regex } = normalise(context);
  const results = [];

  if (regex) {
    if (regex.test(value)) {
      results.push({ context: 'CUSTOM', id: 'custom-regex', description: 'Matched caller-supplied pattern', pattern: regex });
    }
    return results;
  }

  for (const list of lists) {
    const label = list.label ?? 'CUSTOM';
    for (const rule of list) {
      if (rule.pattern.test(value)) {
        results.push({ context: label, id: rule.id, description: rule.description, pattern: rule.pattern });
      }
    }
  }

  return results;
}


/* export default */ const src = ((/* unused pure expression or super */ null && (isUnsafe)));

;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js

///@ts-check












// const regx =
//   '<((!\\[CDATA\\[([\\s\\S]*?)(]]>))|((NAME:)?(NAME))([^>]*)>|((\\/)(NAME)\\s*>))([^<]*)'
//   .replace(/NAME/g, util.nameRegexp);

//const tagsRegx = new RegExp("<(\\/?[\\w:\\-\._]+)([^>]*)>(\\s*"+cdataRegx+")*([^<]+)?","g");
//const tagsRegx = new RegExp("<(\\/?)((\\w*:)?([\\w:\\-\._]+))([^>]*)>([^<]*)("+cdataRegx+"([^<]*))*([^<]+)?","g");

// Helper functions for attribute and namespace handling

/**
 * Extract raw attributes (without prefix) from prefixed attribute map
 * @param {object} prefixedAttrs - Attributes with prefix from buildAttributesMap
 * @param {object} options - Parser options containing attributeNamePrefix
 * @returns {object} Raw attributes for matcher
 */
function extractRawAttributes(prefixedAttrs, options) {
  if (!prefixedAttrs) return {};

  // Handle attributesGroupName option
  const attrs = options.attributesGroupName
    ? prefixedAttrs[options.attributesGroupName]
    : prefixedAttrs;

  if (!attrs) return {};

  const rawAttrs = {};
  for (const key in attrs) {
    // Remove the attribute prefix to get raw name
    if (key.startsWith(options.attributeNamePrefix)) {
      const rawName = key.substring(options.attributeNamePrefix.length);
      rawAttrs[rawName] = attrs[key];
    } else {
      // Attribute without prefix (shouldn't normally happen, but be safe)
      rawAttrs[key] = attrs[key];
    }
  }
  return rawAttrs;
}

/**
 * Extract namespace from raw tag name
 * @param {string} rawTagName - Tag name possibly with namespace (e.g., "soap:Envelope")
 * @returns {string|undefined} Namespace or undefined
 */
function extractNamespace(rawTagName) {
  if (!rawTagName || typeof rawTagName !== 'string') return undefined;

  const colonIndex = rawTagName.indexOf(':');
  if (colonIndex !== -1 && colonIndex > 0) {
    const ns = rawTagName.substring(0, colonIndex);
    // Don't treat xmlns as a namespace
    if (ns !== 'xmlns') {
      return ns;
    }
  }
  return undefined;
}

class OrderedObjParser {
  constructor(options, externalEntities) {
    this.options = options;
    this.currentNode = null;
    this.tagsNodeStack = [];
    this.parseXml = parseXml;
    this.parseTextData = parseTextData;
    this.resolveNameSpace = resolveNameSpace;
    this.buildAttributesMap = buildAttributesMap;
    this.isItStopNode = isItStopNode;
    this.replaceEntitiesValue = replaceEntitiesValue;
    this.readStopNodeData = readStopNodeData;
    this.saveTextToParentTag = saveTextToParentTag;
    this.addChild = addChild;
    this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes)
    this.entityExpansionCount = 0;
    this.currentExpandedLength = 0;
    this.doctypefound = false;
    let namedEntities = { ...XML };
    if (this.options.entityDecoder) {
      this.entityDecoder = this.options.entityDecoder
    } else {
      if (typeof this.options.htmlEntities === "object") namedEntities = this.options.htmlEntities;
      else if (this.options.htmlEntities === true) namedEntities = { ...COMMON_HTML, ...CURRENCY };
      this.entityDecoder = new EntityDecoder({
        namedEntities: { ...namedEntities, ...externalEntities },
        numericAllowed: this.options.htmlEntities,
        limit: {
          maxTotalExpansions: this.options.processEntities.maxTotalExpansions,
          maxExpandedLength: this.options.processEntities.maxExpandedLength,
          applyLimitsTo: this.options.processEntities.appliesTo,
        },
        // onExternalEntity: (name, value) => isUnsafe(value) ? 'block' : 'allow',
        onInputEntity: (name, value) =>
          //TODO: VALID_CONTEXTS.HTML should be set only if this.options.htmlEntities
          isUnsafe(value, [html, contexts_xml]) ? ENTITY_ACTION.BLOCK : ENTITY_ACTION.ALLOW,

        //postCheck: resolved => resolved
      });
    }

    // Initialize path matcher for path-expression-matcher
    this.matcher = new Matcher();
    this.readonlyMatcher = this.matcher.readOnly();

    // Flag to track if current node is a stop node (optimization)
    this.isCurrentNodeStopNode = false;

    // Pre-compile stopNodes expressions
    this.stopNodeExpressionsSet = new ExpressionSet();
    const stopNodesOpts = this.options.stopNodes;
    if (stopNodesOpts && stopNodesOpts.length > 0) {
      for (let i = 0; i < stopNodesOpts.length; i++) {
        const stopNodeExp = stopNodesOpts[i];
        if (typeof stopNodeExp === 'string') {
          // Convert string to Expression object
          this.stopNodeExpressionsSet.add(new Expression(stopNodeExp));
        } else if (stopNodeExp instanceof Expression) {
          // Already an Expression object
          this.stopNodeExpressionsSet.add(stopNodeExp);
        }
      }
      this.stopNodeExpressionsSet.seal();
    }
  }

}


/**
 * @param {string} val
 * @param {string} tagName
 * @param {string|Matcher} jPath - jPath string or Matcher instance based on options.jPath
 * @param {boolean} dontTrim
 * @param {boolean} hasAttributes
 * @param {boolean} isLeafNode
 * @param {boolean} escapeEntities
 */
function parseTextData(val, tagName, jPath, dontTrim, hasAttributes, isLeafNode, escapeEntities) {
  const options = this.options;
  if (val !== undefined) {
    if (options.trimValues && !dontTrim) {
      val = val.trim();
    }
    if (val.length > 0) {
      if (!escapeEntities) val = this.replaceEntitiesValue(val, tagName, jPath);

      // Pass jPath string or matcher based on options.jPath setting
      const jPathOrMatcher = options.jPath ? jPath.toString() : jPath;
      const newval = options.tagValueProcessor(tagName, val, jPathOrMatcher, hasAttributes, isLeafNode);
      if (newval === null || newval === undefined) {
        //don't parse
        return val;
      } else if (typeof newval !== typeof val || newval !== val) {
        //overwrite
        return newval;
      } else if (options.trimValues) {
        return parseValue(val, options.parseTagValue, options.numberParseOptions);
      } else {
        const trimmedVal = val.trim();
        if (trimmedVal === val) {
          return parseValue(val, options.parseTagValue, options.numberParseOptions);
        } else {
          return val;
        }
      }
    }
  }
}

function resolveNameSpace(tagname) {
  if (this.options.removeNSPrefix) {
    const tags = tagname.split(':');
    const prefix = tagname.charAt(0) === '/' ? '/' : '';
    if (tags[0] === 'xmlns') {
      return '';
    }
    if (tags.length === 2) {
      tagname = prefix + tags[1];
    }
  }
  return tagname;
}

//TODO: change regex to capture NS
//const attrsRegx = new RegExp("([\\w\\-\\.\\:]+)\\s*=\\s*(['\"])((.|\n)*?)\\2","gm");
const attrsRegx = new RegExp('([^\\s=]+)\\s*(=\\s*([\'"])([\\s\\S]*?)\\3)?', 'gm');

function buildAttributesMap(attrStr, jPath, tagName, force = false) {
  const options = this.options;
  if (force === true || (options.ignoreAttributes !== true && typeof attrStr === 'string')) {
    // attrStr = attrStr.replace(/\r?\n/g, ' ');
    //attrStr = attrStr || attrStr.trim();

    const matches = getAllMatches(attrStr, attrsRegx);
    const len = matches.length; //don't make it inline
    const attrs = {};

    // Pre-process values once: trim + entity replacement
    // Reused in both matcher update and second pass
    const processedVals = new Array(len);
    let hasRawAttrs = false;
    const rawAttrsForMatcher = {};

    for (let i = 0; i < len; i++) {
      const attrName = this.resolveNameSpace(matches[i][1]);
      const oldVal = matches[i][4];

      if (attrName.length && oldVal !== undefined) {
        let val = oldVal;
        if (options.trimValues) val = val.trim();
        val = this.replaceEntitiesValue(val, tagName, this.readonlyMatcher);
        processedVals[i] = val;

        rawAttrsForMatcher[attrName] = val;
        hasRawAttrs = true;
      }
    }

    // Update matcher ONCE before second pass, if applicable
    if (hasRawAttrs && typeof jPath === 'object' && jPath.updateCurrent) {
      jPath.updateCurrent(rawAttrsForMatcher);
    }

    // Hoist toString() once — path doesn't change during attribute processing
    const jPathStr = options.jPath ? jPath.toString() : this.readonlyMatcher;

    // Second pass: apply processors, build final attrs
    let hasAttrs = false;
    for (let i = 0; i < len; i++) {
      const attrName = this.resolveNameSpace(matches[i][1]);

      if (this.ignoreAttributesFn(attrName, jPathStr)) continue;

      let aName = options.attributeNamePrefix + attrName;

      if (attrName.length) {
        if (options.transformAttributeName) {
          aName = options.transformAttributeName(aName);
        }
        aName = sanitizeName(aName, options);

        if (matches[i][4] !== undefined) {
          // Reuse already-processed value — no double entity replacement
          const oldVal = processedVals[i];

          const newVal = options.attributeValueProcessor(attrName, oldVal, jPathStr);
          if (newVal === null || newVal === undefined) {
            attrs[aName] = oldVal;
          } else if (typeof newVal !== typeof oldVal || newVal !== oldVal) {
            attrs[aName] = newVal;
          } else {
            attrs[aName] = parseValue(oldVal, options.parseAttributeValue, options.numberParseOptions);
          }
          hasAttrs = true;
        } else if (options.allowBooleanAttributes) {
          attrs[aName] = true;
          hasAttrs = true;
        }
      }
    }

    if (!hasAttrs) return;

    if (options.attributesGroupName && !options.preserveOrder) {
      const attrCollection = {};
      attrCollection[options.attributesGroupName] = attrs;
      return attrCollection;
    }
    return attrs;
  }
}
const parseXml = function (xmlData) {
  xmlData = xmlData.replace(/\r\n?/g, "\n"); //TODO: remove this line
  const xmlObj = new XmlNode('!xml');
  let currentNode = xmlObj;
  let textData = "";

  // Reset matcher for new document
  this.matcher.reset();
  this.entityDecoder.reset();

  // Reset entity expansion counters for this document
  this.entityExpansionCount = 0;
  this.currentExpandedLength = 0;
  this.doctypefound = false;
  const options = this.options;
  const docTypeReader = new DocTypeReader(options.processEntities);
  const xmlLen = xmlData.length;
  for (let i = 0; i < xmlLen; i++) {//for each char in XML data
    const ch = xmlData[i];
    if (ch === '<') {
      // const nextIndex = i+1;
      // const _2ndChar = xmlData[nextIndex];
      const c1 = xmlData.charCodeAt(i + 1);
      if (c1 === 47) {//Closing Tag '/'
        const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.")
        let tagName = xmlData.substring(i + 2, closeIndex).trim();

        if (options.removeNSPrefix) {
          const colonIndex = tagName.indexOf(":");
          if (colonIndex !== -1) {
            tagName = tagName.substr(colonIndex + 1);
          }
        }

        tagName = transformTagName(options.transformTagName, tagName, "", options).tagName;

        if (currentNode) {
          textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        }

        //check if last tag of nested tag was unpaired tag
        const lastTagName = this.matcher.getCurrentTag();
        if (tagName && options.unpairedTagsSet.has(tagName)) {
          throw new Error(`Unpaired tag can not be used as closing tag: </${tagName}>`);
        }
        if (lastTagName && options.unpairedTagsSet.has(lastTagName)) {
          // Pop the unpaired tag
          this.matcher.pop();
          this.tagsNodeStack.pop();
        }
        // Pop the closing tag
        this.matcher.pop();
        this.isCurrentNodeStopNode = false; // Reset flag when closing tag

        //a closing tag with no matching opening tag leaves the stack empty
        currentNode = this.tagsNodeStack.pop() || xmlObj;//avoid recursion, set the parent tag scope

        if (options.captureMetaData && currentNode) {
          currentNode.addEndIndex(closeIndex + 1);
        }
        textData = "";
        i = closeIndex;
      } else if (c1 === 63) { //'?'

        let tagData = readTagExp(xmlData, i, false, "?>");
        if (!tagData) throw new Error("Pi Tag is not closed.");

        textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        const attsMap = this.buildAttributesMap(tagData.tagExp, this.matcher, tagData.tagName, true);
        if (attsMap) {
          const ver = attsMap[this.options.attributeNamePrefix + "version"];
          this.entityDecoder.setXmlVersion(Number(ver) || 1.0);
          docTypeReader.setXmlVersion(Number(ver) || 1.0);
        }
        if ((options.ignoreDeclaration && tagData.tagName === "?xml") || options.ignorePiTags) {
          //do nothing
        } else {

          const childNode = new XmlNode(tagData.tagName);
          childNode.add(options.textNodeName, "");

          if (tagData.tagName !== tagData.tagExp && tagData.attrExpPresent && options.ignoreAttributes !== true) {
            childNode[":@"] = attsMap
          }
          this.addChild(currentNode, childNode, this.readonlyMatcher, i);

          if (options.captureMetaData) {
            // closeIndex points at '?' of the closing '?>'
            currentNode.addEndIndex(tagData.closeIndex + 2);
          }
        }


        i = tagData.closeIndex + 1;
      } else if (c1 === 33
        && xmlData.charCodeAt(i + 2) === 45
        && xmlData.charCodeAt(i + 3) === 45) { //'!--'
        const endIndex = findClosingIndex(xmlData, "-->", i + 4, "Comment is not closed.")
        if (options.commentPropName) {
          const comment = xmlData.substring(i + 4, endIndex - 2);

          textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);

          currentNode.add(options.commentPropName, [{ [options.textNodeName]: comment }]);
        }
        i = endIndex;
      } else if (c1 === 33
        && xmlData.charCodeAt(i + 2) === 68) { //'!D'
        if (this.doctypefound) throw new Error("Multiple DOCTYPE declarations found.");
        this.doctypefound = true;
        const result = docTypeReader.readDocType(xmlData, i);
        this.entityDecoder.addInputEntities(result.entities);
        i = result.i;
      } else if (c1 === 33
        && xmlData.charCodeAt(i + 2) === 91) { // '!['
        const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
        const tagExp = xmlData.substring(i + 9, closeIndex);

        textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);

        let val = this.parseTextData(tagExp, currentNode.tagname, this.readonlyMatcher, true, false, true, true);
        if (val == undefined) val = "";

        //cdata should be set even if it is 0 length string
        if (options.cdataPropName) {
          currentNode.add(options.cdataPropName, [{ [options.textNodeName]: tagExp }]);
        } else {
          currentNode.add(options.textNodeName, val);
        }

        i = closeIndex + 2;
      } else {//Opening tag
        let result = readTagExp(xmlData, i, options.removeNSPrefix);

        // Safety check: readTagExp can return undefined
        if (!result) {
          // Log context for debugging
          const context = xmlData.substring(Math.max(0, i - 50), Math.min(xmlLen, i + 50));
          throw new Error(`readTagExp returned undefined at position ${i}. Context: "${context}"`);
        }

        let tagName = result.tagName;
        const rawTagName = result.rawTagName;
        let tagExp = result.tagExp;
        let attrExpPresent = result.attrExpPresent;
        let closeIndex = result.closeIndex;

        ({ tagName, tagExp } = transformTagName(options.transformTagName, tagName, tagExp, options));

        if (options.strictReservedNames &&
          (tagName === options.commentPropName
            || tagName === options.cdataPropName
            || tagName === options.textNodeName
            || tagName === options.attributesGroupName
          )) {
          throw new Error(`Invalid tag name: ${tagName}`);
        }

        //save text as child node
        if (currentNode && textData) {
          if (currentNode.tagname !== '!xml') {
            //when nested tag is found
            textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher, false);
          }
        }

        //check if last tag was unpaired tag
        const lastTag = currentNode;
        if (lastTag && options.unpairedTagsSet.has(lastTag.tagname)) {
          currentNode = this.tagsNodeStack.pop();
          this.matcher.pop();
        }

        // Clean up self-closing syntax BEFORE processing attributes
        // This is where tagExp gets the trailing / removed
        let isSelfClosing = false;
        if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
          isSelfClosing = true;
          if (tagName[tagName.length - 1] === "/") {
            tagName = tagName.substr(0, tagName.length - 1);
            tagExp = tagName;
          } else {
            tagExp = tagExp.substr(0, tagExp.length - 1);
          }

          // Re-check attrExpPresent after cleaning
          attrExpPresent = (tagName !== tagExp);
        }

        // Now process attributes with CLEAN tagExp (no trailing /)
        let prefixedAttrs = null;
        let rawAttrs = {};
        let namespace = undefined;

        // Extract namespace from rawTagName
        namespace = extractNamespace(rawTagName);

        // Push tag to matcher FIRST (with empty attrs for now) so callbacks see correct path
        if (tagName !== xmlObj.tagname) {
          this.matcher.push(tagName, {}, namespace);
        }

        // Now build attributes - callbacks will see correct matcher state
        if (tagName !== tagExp && attrExpPresent) {
          // Build attributes (returns prefixed attributes for the tree)
          // Note: buildAttributesMap now internally updates the matcher with raw attributes
          prefixedAttrs = this.buildAttributesMap(tagExp, this.matcher, tagName);

          if (prefixedAttrs) {
            // Extract raw attributes (without prefix) for our use
            //TODO: seems a performance overhead
            rawAttrs = extractRawAttributes(prefixedAttrs, options);
          }
        }

        // Now check if this is a stop node (after attributes are set)
        if (tagName !== xmlObj.tagname) {
          this.isCurrentNodeStopNode = this.isItStopNode();
        }

        const startIndex = i;
        if (this.isCurrentNodeStopNode) {
          let tagContent = "";

          // For self-closing tags, content is empty
          if (isSelfClosing) {
            i = result.closeIndex;
          }
          //unpaired tag
          else if (options.unpairedTagsSet.has(tagName)) {
            i = result.closeIndex;
          }
          //normal tag
          else {
            //read until closing tag is found
            const result = this.readStopNodeData(xmlData, rawTagName, closeIndex + 1);
            if (!result) throw new Error(`Unexpected end of ${rawTagName}`);
            i = result.i;
            tagContent = result.tagContent;
          }

          const childNode = new XmlNode(tagName);

          if (prefixedAttrs) {
            childNode[":@"] = prefixedAttrs;
          }

          // For stop nodes, store raw content as-is without any processing
          childNode.add(options.textNodeName, tagContent);

          this.matcher.pop(); // Pop the stop node tag
          this.isCurrentNodeStopNode = false; // Reset flag

          this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);

          if (options.captureMetaData) {
            currentNode.addEndIndex(i + 1);
          }
        } else {
          //selfClosing tag
          if (isSelfClosing) {
            ({ tagName, tagExp } = transformTagName(options.transformTagName, tagName, tagExp, options));

            const childNode = new XmlNode(tagName);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);

            if (options.captureMetaData) {
              currentNode.addEndIndex(closeIndex + 1);
            }
            this.matcher.pop(); // Pop self-closing tag
            this.isCurrentNodeStopNode = false; // Reset flag
          }
          else if (options.unpairedTagsSet.has(tagName)) {//unpaired tag
            const childNode = new XmlNode(tagName);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);

            if (options.captureMetaData) {
              currentNode.addEndIndex(result.closeIndex + 1);
            }
            this.matcher.pop(); // Pop unpaired tag
            this.isCurrentNodeStopNode = false; // Reset flag
            i = result.closeIndex;
            // Continue to next iteration without changing currentNode
            continue;
          }
          //opening tag
          else {
            const childNode = new XmlNode(tagName);
            if (this.tagsNodeStack.length > options.maxNestedTags) {
              throw new Error("Maximum nested tags exceeded");
            }
            this.tagsNodeStack.push(currentNode);

            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
            currentNode = childNode;
          }
          textData = "";
          i = closeIndex;
        }
      }
    } else {
      textData += xmlData[i];
    }
  }
  return xmlObj.child;
}

function addChild(currentNode, childNode, matcher, startIndex) {
  // unset startIndex if not requested
  if (!this.options.captureMetaData) startIndex = undefined;

  // Pass jPath string or matcher based on options.jPath setting
  const jPathOrMatcher = this.options.jPath ? matcher.toString() : matcher;
  const result = this.options.updateTag(childNode.tagname, jPathOrMatcher, childNode[":@"])
  if (result === false) {
    //do nothing
  } else if (typeof result === "string") {
    childNode.tagname = result
    currentNode.addChild(childNode, startIndex);
  } else {
    currentNode.addChild(childNode, startIndex);
  }
}

/**
 * @param {object} val - Entity object with regex and val properties
 * @param {string} tagName - Tag name
 * @param {string|Matcher} jPath - jPath string or Matcher instance based on options.jPath
 */
function replaceEntitiesValue(val, tagName, jPath) {
  const entityConfig = this.options.processEntities;

  if (!entityConfig || !entityConfig.enabled) {
    return val;
  }

  // Check if tag is allowed to contain entities
  if (entityConfig.allowedTags) {
    const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
    const allowed = Array.isArray(entityConfig.allowedTags)
      ? entityConfig.allowedTags.includes(tagName)
      : entityConfig.allowedTags(tagName, jPathOrMatcher);

    if (!allowed) {
      return val;
    }
  }

  // Apply custom tag filter if provided
  if (entityConfig.tagFilter) {
    const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
    if (!entityConfig.tagFilter(tagName, jPathOrMatcher)) {
      return val; // Skip based on custom filter
    }
  }

  return this.entityDecoder.decode(val);
}


function saveTextToParentTag(textData, parentNode, matcher, isLeafNode) {
  if (textData) { //store previously collected data as textNode
    if (isLeafNode === undefined) isLeafNode = parentNode.child.length === 0

    textData = this.parseTextData(textData,
      parentNode.tagname,
      matcher,
      false,
      parentNode[":@"] ? Object.keys(parentNode[":@"]).length !== 0 : false,
      isLeafNode);

    if (textData !== undefined && textData !== "")
      parentNode.add(this.options.textNodeName, textData);
    textData = "";
  }
  return textData;
}

/**
 * @param {Array<Expression>} stopNodeExpressions - Array of compiled Expression objects
 * @param {Matcher} matcher - Current path matcher
 */
function isItStopNode() {
  if (this.stopNodeExpressionsSet.size === 0) return false;

  return this.matcher.matchesAny(this.stopNodeExpressionsSet);
}

/**
 * Returns the tag Expression and where it is ending handling single-double quotes situation
 * @param {string} xmlData 
 * @param {number} i starting index
 * @returns 
 */
function tagExpWithClosingIndex(xmlData, i, closingChar = ">") {
  //TODO: ignore boolean attributes in tag expression
  //TODO: if ignore attributes, dont read full attribute expression but the end. But read for xml declaration
  let attrBoundary = 0;
  const len = xmlData.length;
  const closeCode0 = closingChar.charCodeAt(0);
  const closeCode1 = closingChar.length > 1 ? closingChar.charCodeAt(1) : -1;

  let result = '';
  let segmentStart = i;

  for (let index = i; index < len; index++) {
    const code = xmlData.charCodeAt(index);

    if (attrBoundary) {
      if (code === attrBoundary) attrBoundary = 0;
    } else if (code === 34 || code === 39) { // " or '
      attrBoundary = code;
    } else if (code === closeCode0) {
      if (closeCode1 !== -1) {
        if (xmlData.charCodeAt(index + 1) === closeCode1) {
          result += xmlData.substring(segmentStart, index);
          return { data: result, index };
        }
      } else {
        result += xmlData.substring(segmentStart, index);
        return { data: result, index };
      }
    } else if (code === 9 && !attrBoundary) { // \t - only replace with space outside attribute values
      // Flush accumulated segment, add space, start new segment
      result += xmlData.substring(segmentStart, index) + ' ';
      segmentStart = index + 1;
    }
  }
}

function findClosingIndex(xmlData, str, i, errMsg) {
  const closingIndex = xmlData.indexOf(str, i);
  if (closingIndex === -1) {
    throw new Error(errMsg)
  } else {
    return closingIndex + str.length - 1;
  }
}

function findClosingChar(xmlData, char, i, errMsg) {
  const closingIndex = xmlData.indexOf(char, i);
  if (closingIndex === -1) throw new Error(errMsg);
  return closingIndex; // no offset needed
}

function readTagExp(xmlData, i, removeNSPrefix, closingChar = ">") {
  const result = tagExpWithClosingIndex(xmlData, i + 1, closingChar);
  if (!result) return;
  let tagExp = result.data;
  const closeIndex = result.index;
  const separatorIndex = tagExp.search(/\s/);
  let tagName = tagExp;
  let attrExpPresent = true;
  if (separatorIndex !== -1) {//separate tag name and attributes expression
    tagName = tagExp.substring(0, separatorIndex);
    tagExp = tagExp.substring(separatorIndex + 1).trimStart();
  }

  const rawTagName = tagName;
  if (removeNSPrefix) {
    const colonIndex = tagName.indexOf(":");
    if (colonIndex !== -1) {
      tagName = tagName.substr(colonIndex + 1);
      attrExpPresent = tagName !== result.data.substr(colonIndex + 1);
    }
  }

  return {
    tagName: tagName,
    tagExp: tagExp,
    closeIndex: closeIndex,
    attrExpPresent: attrExpPresent,
    rawTagName: rawTagName,
  }
}
/**
 * find paired tag for a stop node
 * @param {string} xmlData 
 * @param {string} tagName 
 * @param {number} i 
 */
function readStopNodeData(xmlData, tagName, i) {
  const startIndex = i;
  // Starting at 1 since we already have an open tag
  let openTagCount = 1;

  const xmllen = xmlData.length;
  for (; i < xmllen; i++) {
    if (xmlData[i] === "<") {
      const c1 = xmlData.charCodeAt(i + 1);
      if (c1 === 47) {//close tag '/'
        const closeIndex = findClosingChar(xmlData, ">", i, `${tagName} is not closed`);
        let closeTagName = xmlData.substring(i + 2, closeIndex).trim();
        if (closeTagName === tagName) {
          openTagCount--;
          if (openTagCount === 0) {
            return {
              tagContent: xmlData.substring(startIndex, i),
              i: closeIndex
            }
          }
        }
        i = closeIndex;
      } else if (c1 === 63) { //?
        const closeIndex = findClosingIndex(xmlData, "?>", i + 1, "StopNode is not closed.")
        i = closeIndex;
      } else if (c1 === 33
        && xmlData.charCodeAt(i + 2) === 45
        && xmlData.charCodeAt(i + 3) === 45) { // '!--'
        const closeIndex = findClosingIndex(xmlData, "-->", i + 3, "StopNode is not closed.")
        i = closeIndex;
      } else if (c1 === 33
        && xmlData.charCodeAt(i + 2) === 91) { // '!['
        const closeIndex = findClosingIndex(xmlData, "]]>", i, "StopNode is not closed.") - 2;
        i = closeIndex;
      } else {
        const tagData = readTagExp(xmlData, i, false)

        if (tagData) {
          const openTagName = tagData && tagData.tagName;
          if (openTagName === tagName && tagData.tagExp[tagData.tagExp.length - 1] !== "/") {
            openTagCount++;
          }
          i = tagData.closeIndex;
        }
      }
    }
  }//end for loop
}

function parseValue(val, shouldParse, options) {
  if (shouldParse && typeof val === 'string') {
    //console.log(options)
    const newval = val.trim();
    if (newval === 'true') return true;
    else if (newval === 'false') return false;
    else return toNumber(val, options);
  } else {
    if (isExist(val)) {
      return val;
    } else {
      return '';
    }
  }
}

function fromCodePoint(str, base, prefix) {
  const codePoint = Number.parseInt(str, base);

  if (codePoint >= 0 && codePoint <= 0x10FFFF) {
    return String.fromCodePoint(codePoint);
  } else {
    return prefix + str + ";";
  }
}

function transformTagName(fn, tagName, tagExp, options) {
  if (fn) {
    const newTagName = fn(tagName);
    if (tagExp === tagName) {
      tagExp = newTagName
    }
    tagName = newTagName;
  }
  tagName = sanitizeName(tagName, options);
  return { tagName, tagExp };
}



function sanitizeName(name, options) {
  if (criticalProperties.includes(name)) {
    throw new Error(`[SECURITY] Invalid name: "${name}" is a reserved JavaScript keyword that could cause prototype pollution`);
  } else if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
    return options.onDangerousProperty(name);
  }
  return name;
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/xmlparser/node2json.js





const node2json_METADATA_SYMBOL = XmlNode.getMetaDataSymbol();

/**
 * Helper function to strip attribute prefix from attribute map
 * @param {object} attrs - Attributes with prefix (e.g., {"@_class": "code"})
 * @param {string} prefix - Attribute prefix to remove (e.g., "@_")
 * @returns {object} Attributes without prefix (e.g., {"class": "code"})
 */
function stripAttributePrefix(attrs, prefix) {
  if (!attrs || typeof attrs !== 'object') return {};
  if (!prefix) return attrs;

  const rawAttrs = {};
  for (const key in attrs) {
    if (key.startsWith(prefix)) {
      const rawName = key.substring(prefix.length);
      rawAttrs[rawName] = attrs[key];
    } else {
      // Attribute without prefix (shouldn't normally happen, but be safe)
      rawAttrs[key] = attrs[key];
    }
  }
  return rawAttrs;
}

/**
 * 
 * @param {array} node 
 * @param {any} options 
 * @param {Matcher} matcher - Path matcher instance
 * @returns 
 */
function prettify(node, options, matcher, readonlyMatcher) {
  return compress(node, options, matcher, readonlyMatcher);
}

/**
 * @param {array} arr 
 * @param {object} options 
 * @param {Matcher} matcher - Path matcher instance
 * @returns object
 */
function compress(arr, options, matcher, readonlyMatcher) {
  let text;
  const compressedObj = {}; //This is intended to be a plain object
  for (let i = 0; i < arr.length; i++) {
    const tagObj = arr[i];
    const property = propName(tagObj);

    // Push current property to matcher WITH RAW ATTRIBUTES (no prefix)
    if (property !== undefined && property !== options.textNodeName) {
      const rawAttrs = stripAttributePrefix(
        tagObj[":@"] || {},
        options.attributeNamePrefix
      );
      matcher.push(property, rawAttrs);
    }

    if (property === options.textNodeName) {
      if (text === undefined) text = tagObj[property];
      else text += "" + tagObj[property];
    } else if (property === undefined) {
      continue;
    } else if (tagObj[property]) {

      let val = compress(tagObj[property], options, matcher, readonlyMatcher);
      const isLeaf = isLeafTag(val, options);

      if (Object.keys(val).length === 0 && options.alwaysCreateTextNode) {
        val[options.textNodeName] = "";
      }

      if (tagObj[":@"]) {
        assignAttributes(val, tagObj[":@"], readonlyMatcher, options);
      } else if (Object.keys(val).length === 1 && val[options.textNodeName] !== undefined && !options.alwaysCreateTextNode) {
        val = val[options.textNodeName];
      } else if (Object.keys(val).length === 0) {
        if (options.alwaysCreateTextNode) val[options.textNodeName] = "";
        else val = "";
      }

      if (tagObj[node2json_METADATA_SYMBOL] !== undefined && typeof val === "object" && val !== null) {
        val[node2json_METADATA_SYMBOL] = tagObj[node2json_METADATA_SYMBOL]; // copy over metadata
      }


      if (compressedObj[property] !== undefined && Object.prototype.hasOwnProperty.call(compressedObj, property)) {
        if (!Array.isArray(compressedObj[property])) {
          compressedObj[property] = [compressedObj[property]];
        }
        compressedObj[property].push(val);
      } else {
        //TODO: if a node is not an array, then check if it should be an array
        //also determine if it is a leaf node

        // Pass jPath string or readonlyMatcher based on options.jPath setting
        const jPathOrMatcher = options.jPath ? readonlyMatcher.toString() : readonlyMatcher;
        if (options.isArray(property, jPathOrMatcher, isLeaf)) {
          compressedObj[property] = [val];
        } else {
          compressedObj[property] = val;
        }
      }

      // Pop property from matcher after processing
      if (property !== undefined && property !== options.textNodeName) {
        matcher.pop();
      }
    }

  }
  // if(text && text.length > 0) compressedObj[options.textNodeName] = text;
  if (typeof text === "string") {
    if (text.length > 0) compressedObj[options.textNodeName] = text;
  } else if (text !== undefined) compressedObj[options.textNodeName] = text;


  return compressedObj;
}

function propName(obj) {
  const keys = Object.keys(obj);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (key !== ":@") return key;
  }
}

function assignAttributes(obj, attrMap, readonlyMatcher, options) {
  if (attrMap) {
    const keys = Object.keys(attrMap);
    const len = keys.length; //don't make it inline
    for (let i = 0; i < len; i++) {
      const atrrName = keys[i];  // This is the PREFIXED name (e.g., "@_class")

      // Strip prefix for matcher path (for isArray callback)
      const rawAttrName = atrrName.startsWith(options.attributeNamePrefix)
        ? atrrName.substring(options.attributeNamePrefix.length)
        : atrrName;

      // For attributes, we need to create a temporary path
      // Pass jPath string or matcher based on options.jPath setting
      const jPathOrMatcher = options.jPath
        ? readonlyMatcher.toString() + "." + rawAttrName
        : readonlyMatcher;

      if (options.isArray(atrrName, jPathOrMatcher, true, true)) {
        obj[atrrName] = [attrMap[atrrName]];
      } else {
        obj[atrrName] = attrMap[atrrName];
      }
    }
  }
}

function isLeafTag(obj, options) {
  const { textNodeName } = options;
  const propCount = Object.keys(obj).length;

  if (propCount === 0) {
    return true;
  }

  if (
    propCount === 1 &&
    (obj[textNodeName] || typeof obj[textNodeName] === "boolean" || obj[textNodeName] === 0)
  ) {
    return true;
  }

  return false;
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/validator.js




const validator_defaultOptions = {
  allowBooleanAttributes: false, //A tag can have attributes without any value
  unpairedTags: []
};

//const tagsPattern = new RegExp("<\\/?([\\w:\\-_\.]+)\\s*\/?>","g");
function validator_validate(xmlData, options) {
  options = Object.assign({}, validator_defaultOptions, options);

  //xmlData = xmlData.replace(/(\r\n|\n|\r)/gm,"");//make it single line
  //xmlData = xmlData.replace(/(^\s*<\?xml.*?\?>)/g,"");//Remove XML starting tag
  //xmlData = xmlData.replace(/(<!DOCTYPE[\s\w\"\.\/\-\:]+(\[.*\])*\s*>)/g,"");//Remove DOCTYPE
  const tags = [];
  let tagFound = false;

  //indicates that the root tag has been closed (aka. depth 0 has been reached)
  let reachedRoot = false;

  if (xmlData[0] === '\ufeff') {
    // check for byte order mark (BOM)
    xmlData = xmlData.substr(1);
  }

  for (let i = 0; i < xmlData.length; i++) {

    if (xmlData[i] === '<' && xmlData[i + 1] === '?') {
      i += 2;
      i = readPI(xmlData, i);
      if (i.err) return i;
    } else if (xmlData[i] === '<') {
      //starting of tag
      //read until you reach to '>' avoiding any '>' in attribute value
      let tagStartPos = i;
      i++;

      if (xmlData[i] === '!') {
        i = readCommentAndCDATA(xmlData, i);
        continue;
      } else {
        let closingTag = false;
        if (xmlData[i] === '/') {
          //closing tag
          closingTag = true;
          i++;
        }
        //read tagname
        let tagName = '';
        for (; i < xmlData.length &&
          xmlData[i] !== '>' &&
          xmlData[i] !== ' ' &&
          xmlData[i] !== '\t' &&
          xmlData[i] !== '\n' &&
          xmlData[i] !== '\r'; i++
        ) {
          tagName += xmlData[i];
        }
        tagName = tagName.trim();
        //console.log(tagName);

        if (tagName[tagName.length - 1] === '/') {
          //self closing tag without attributes
          tagName = tagName.substring(0, tagName.length - 1);
          //continue;
          i--;
        }
        if (!validateTagName(tagName)) {
          let msg;
          if (tagName.trim().length === 0) {
            msg = "Invalid space after '<'.";
          } else {
            msg = "Tag '" + tagName + "' is an invalid name.";
          }
          return getErrorObject('InvalidTag', msg, getLineNumberForPosition(xmlData, i));
        }

        const result = readAttributeStr(xmlData, i);
        if (result === false) {
          return getErrorObject('InvalidAttr', "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i));
        }
        let attrStr = result.value;
        i = result.index;

        if (attrStr[attrStr.length - 1] === '/') {
          //self closing tag
          const attrStrStart = i - attrStr.length;
          attrStr = attrStr.substring(0, attrStr.length - 1);
          const isValid = validateAttributeString(attrStr, options);
          if (isValid === true) {
            tagFound = true;
            //continue; //text may presents after self closing tag
          } else {
            //the result from the nested function returns the position of the error within the attribute
            //in order to get the 'true' error line, we need to calculate the position where the attribute begins (i - attrStr.length) and then add the position within the attribute
            //this gives us the absolute index in the entire xml, which we can use to find the line at last
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, attrStrStart + isValid.err.line));
          }
        } else if (closingTag) {
          if (!result.tagClosed) {
            return getErrorObject('InvalidTag', "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
          } else if (attrStr.trim().length > 0) {
            return getErrorObject('InvalidTag', "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, tagStartPos));
          } else if (tags.length === 0) {
            return getErrorObject('InvalidTag', "Closing tag '" + tagName + "' has not been opened.", getLineNumberForPosition(xmlData, tagStartPos));
          } else {
            const otg = tags.pop();
            if (tagName !== otg.tagName) {
              let openPos = getLineNumberForPosition(xmlData, otg.tagStartPos);
              return getErrorObject('InvalidTag',
                "Expected closing tag '" + otg.tagName + "' (opened in line " + openPos.line + ", col " + openPos.col + ") instead of closing tag '" + tagName + "'.",
                getLineNumberForPosition(xmlData, tagStartPos));
            }

            //when there are no more tags, we reached the root level.
            if (tags.length == 0) {
              reachedRoot = true;
            }
          }
        } else {
          const isValid = validateAttributeString(attrStr, options);
          if (isValid !== true) {
            //the result from the nested function returns the position of the error within the attribute
            //in order to get the 'true' error line, we need to calculate the position where the attribute begins (i - attrStr.length) and then add the position within the attribute
            //this gives us the absolute index in the entire xml, which we can use to find the line at last
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
          }

          //if the root level has been reached before ...
          if (reachedRoot === true) {
            return getErrorObject('InvalidXml', 'Multiple possible root nodes found.', getLineNumberForPosition(xmlData, i));
          } else if (options.unpairedTags.indexOf(tagName) !== -1) {
            //don't push into stack
          } else {
            tags.push({ tagName, tagStartPos });
          }
          tagFound = true;
        }

        //skip tag text value
        //It may include comments and CDATA value
        for (i++; i < xmlData.length; i++) {
          if (xmlData[i] === '<') {
            if (xmlData[i + 1] === '!') {
              //comment or CADATA
              i++;
              i = readCommentAndCDATA(xmlData, i);
              continue;
            } else if (xmlData[i + 1] === '?') {
              i = readPI(xmlData, ++i);
              if (i.err) return i;
            } else {
              break;
            }
          } else if (xmlData[i] === '&') {
            const afterAmp = validateAmpersand(xmlData, i);
            if (afterAmp == -1)
              return getErrorObject('InvalidChar', "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
            i = afterAmp;
          } else {
            if (reachedRoot === true && !isWhiteSpace(xmlData[i])) {
              return getErrorObject('InvalidXml', "Extra text at the end", getLineNumberForPosition(xmlData, i));
            }
          }
        } //end of reading tag text value
        if (xmlData[i] === '<') {
          i--;
        }
      }
    } else {
      if (isWhiteSpace(xmlData[i])) {
        continue;
      }
      return getErrorObject('InvalidChar', "char '" + xmlData[i] + "' is not expected.", getLineNumberForPosition(xmlData, i));
    }
  }

  if (!tagFound) {
    return getErrorObject('InvalidXml', 'Start tag expected.', 1);
  } else if (tags.length == 1) {
    return getErrorObject('InvalidTag', "Unclosed tag '" + tags[0].tagName + "'.", getLineNumberForPosition(xmlData, tags[0].tagStartPos));
  } else if (tags.length > 0) {
    return getErrorObject('InvalidXml', "Invalid '" +
      JSON.stringify(tags.map(t => t.tagName), null, 4).replace(/\r?\n/g, '') +
      "' found.", { line: 1, col: 1 });
  }

  return true;
};

function isWhiteSpace(char) {
  return char === ' ' || char === '\t' || char === '\n' || char === '\r';
}
/**
 * Read Processing insstructions and skip
 * @param {*} xmlData
 * @param {*} i
 */
function readPI(xmlData, i) {
  const start = i;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] == '?' || xmlData[i] == ' ') {
      //tagname
      const tagname = xmlData.substr(start, i - start);
      if (i > 5 && tagname === 'xml') {
        return getErrorObject('InvalidXml', 'XML declaration allowed only at the start of the document.', getLineNumberForPosition(xmlData, i));
      } else if (xmlData[i] == '?' && xmlData[i + 1] == '>') {
        //check if valid attribut string
        i++;
        break;
      } else {
        continue;
      }
    }
  }
  return i;
}

function readCommentAndCDATA(xmlData, i) {
  if (xmlData.length > i + 5 && xmlData[i + 1] === '-' && xmlData[i + 2] === '-') {
    //comment
    for (i += 3; i < xmlData.length; i++) {
      if (xmlData[i] === '-' && xmlData[i + 1] === '-' && xmlData[i + 2] === '>') {
        i += 2;
        break;
      }
    }
  } else if (
    xmlData.length > i + 8 &&
    xmlData[i + 1] === 'D' &&
    xmlData[i + 2] === 'O' &&
    xmlData[i + 3] === 'C' &&
    xmlData[i + 4] === 'T' &&
    xmlData[i + 5] === 'Y' &&
    xmlData[i + 6] === 'P' &&
    xmlData[i + 7] === 'E'
  ) {
    let angleBracketsCount = 1;
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === '<') {
        angleBracketsCount++;
      } else if (xmlData[i] === '>') {
        angleBracketsCount--;
        if (angleBracketsCount === 0) {
          break;
        }
      }
    }
  } else if (
    xmlData.length > i + 9 &&
    xmlData[i + 1] === '[' &&
    xmlData[i + 2] === 'C' &&
    xmlData[i + 3] === 'D' &&
    xmlData[i + 4] === 'A' &&
    xmlData[i + 5] === 'T' &&
    xmlData[i + 6] === 'A' &&
    xmlData[i + 7] === '['
  ) {
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === ']' && xmlData[i + 1] === ']' && xmlData[i + 2] === '>') {
        i += 2;
        break;
      }
    }
  }

  return i;
}

const doubleQuote = '"';
const singleQuote = "'";

/**
 * Keep reading xmlData until '<' is found outside the attribute value.
 * @param {string} xmlData
 * @param {number} i
 */
function readAttributeStr(xmlData, i) {
  let attrStr = '';
  let startChar = '';
  let tagClosed = false;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
      if (startChar === '') {
        startChar = xmlData[i];
      } else if (startChar !== xmlData[i]) {
        //if vaue is enclosed with double quote then single quotes are allowed inside the value and vice versa
      } else {
        startChar = '';
      }
    } else if (xmlData[i] === '>') {
      if (startChar === '') {
        tagClosed = true;
        break;
      }
    }
    attrStr += xmlData[i];
  }
  if (startChar !== '') {
    return false;
  }

  return {
    value: attrStr,
    index: i,
    tagClosed: tagClosed
  };
}

/**
 * Walk `attrStr` once, left to right, splitting it into attribute tokens.
 *
 * This replaces a regex that used to do the same job
 * (`(\s*)([^\s=]+)(\s*=)?(\s*(['"])(([\s\S])*?)\5)?`). That regex led with an
 * optional whitespace group followed by a required "non-whitespace" group.
 * On a long run of whitespace that never resolves into an attribute name
 * (e.g. a tag with thousands of trailing spaces before `>`), the engine
 * backtracks the whitespace group one character at a time before giving up
 * and moving to the next starting position — one full backtrack per
 * position, which is quadratic in the length of the run.
 *
 * A single forward-only scan can never backtrack, so it can't be made slow
 * this way no matter how much whitespace the input contains — it's always
 * proportional to the length of the string, once.
 *
 * Each returned token mirrors the shape the old regex match array had, so
 * the validation logic below (which reads token[1]..token[6]) didn't need
 * to change:
 *   token.startIndex - where this token begins in attrStr
 *   token[1]          - leading whitespace before the name
 *   token[2]          - the attribute name
 *   token[3]          - whitespace + '=' if present, else undefined
 *   token[4]          - marker (any defined value) if a quoted value was found
 *   token[5]          - the quote character used ('"' or "'")
 *   token[6]          - the value's text, without the surrounding quotes
 *
 * A malformed leading character (e.g. a stray '=' with no name before it)
 * is simply skipped over, one character at a time — the same outcome the
 * old regex produced by failing to match at that position and retrying at
 * the next one.
 */
function scanAttributeTokens(attrStr) {
  const tokens = [];
  const len = attrStr.length;
  let i = 0;

  while (i < len) {
    const tokenStart = i;

    // Leading whitespace before the name.
    while (i < len && isWhiteSpace(attrStr[i])) i++;
    if (i >= len) break; // trailing whitespace only — nothing left to read

    if (attrStr[i] === '=') {
      // No name before this '=' — not a valid attribute start. Move past
      // just this one character and try again from the next position.
      i = tokenStart + 1;
      continue;
    }

    const leadingWs = attrStr.slice(tokenStart, i);

    // Attribute name — everything up to the next whitespace or '='.
    const nameStart = i;
    while (i < len && !isWhiteSpace(attrStr[i]) && attrStr[i] !== '=') i++;
    const name = attrStr.slice(nameStart, i);

    // Optional whitespace + '='.
    let equalsGroup; // whitespace + '=' text, or undefined if absent
    let j = i;
    while (j < len && isWhiteSpace(attrStr[j])) j++;
    if (j < len && attrStr[j] === '=') {
      equalsGroup = attrStr.slice(i, j + 1);
      i = j + 1;
    }

    // Optional whitespace + quoted value.
    let quoteChar;
    let value;
    let k = i;
    while (k < len && isWhiteSpace(attrStr[k])) k++;
    if (k < len && (attrStr[k] === '"' || attrStr[k] === "'")) {
      const valueStart = k + 1;
      const closeIdx = attrStr.indexOf(attrStr[k], valueStart);
      if (closeIdx !== -1) {
        quoteChar = attrStr[k];
        value = attrStr.slice(valueStart, closeIdx);
        i = closeIdx + 1;
      }
      // No closing quote found anywhere in the rest of the string — leave
      // quoteChar/value undefined, same as the old regex's group failing
      // to match a backreference-less run.
    }

    const token = { startIndex: tokenStart };
    token[1] = leadingWs;
    token[2] = name;
    token[3] = equalsGroup;
    token[4] = quoteChar !== undefined ? true : undefined;
    token[5] = quoteChar;
    token[6] = value;
    tokens.push(token);
  }

  return tokens;
}

//attr, ="sd", a="amit's", a="sd"b="saf", ab  cd=""

function validateAttributeString(attrStr, options) {
  //console.log("start:"+attrStr+":end");

  //if(attrStr.trim().length === 0) return true; //empty string

  const matches = scanAttributeTokens(attrStr);
  const attrNames = {};

  for (let i = 0; i < matches.length; i++) {
    if (matches[i][1].length === 0) {
      //nospace before attribute name: a="sd"b="saf"
      return getErrorObject('InvalidAttr', "Attribute '" + matches[i][2] + "' has no space in starting.", getPositionFromMatch(matches[i]))
    } else if (matches[i][3] !== undefined && matches[i][4] === undefined) {
      return getErrorObject('InvalidAttr', "Attribute '" + matches[i][2] + "' is without value.", getPositionFromMatch(matches[i]));
    } else if (matches[i][3] === undefined && !options.allowBooleanAttributes) {
      //independent attribute: ab
      return getErrorObject('InvalidAttr', "boolean attribute '" + matches[i][2] + "' is not allowed.", getPositionFromMatch(matches[i]));
    }
    /* else if(matches[i][6] === undefined){//attribute without value: ab=
                    return { err: { code:"InvalidAttr",msg:"attribute " + matches[i][2] + " has no value assigned."}};
                } */
    const attrName = matches[i][2];
    if (!validateAttrName(attrName)) {
      return getErrorObject('InvalidAttr', "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(matches[i]));
    }
    if (!Object.prototype.hasOwnProperty.call(attrNames, attrName)) {
      //check for duplicate attribute.
      attrNames[attrName] = 1;
    } else {
      return getErrorObject('InvalidAttr', "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(matches[i]));
    }
  }

  return true;
}

function validateNumberAmpersand(xmlData, i) {
  let re = /\d/;
  if (xmlData[i] === 'x') {
    i++;
    re = /[\da-fA-F]/;
  }
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === ';')
      return i;
    if (!xmlData[i].match(re))
      break;
  }
  return -1;
}

function validateAmpersand(xmlData, i) {
  // https://www.w3.org/TR/xml/#dt-charref
  i++;
  if (xmlData[i] === ';')
    return -1;
  if (xmlData[i] === '#') {
    i++;
    return validateNumberAmpersand(xmlData, i);
  }
  let count = 0;
  for (; i < xmlData.length; i++, count++) {
    if (xmlData[i].match(/\w/) && count < 20)
      continue;
    if (xmlData[i] === ';')
      break;
    return -1;
  }
  return i;
}

function getErrorObject(code, message, lineNumber) {
  return {
    err: {
      code: code,
      msg: message,
      line: lineNumber.line || lineNumber,
      col: lineNumber.col,
    },
  };
}

function validateAttrName(attrName) {
  return isName(attrName);
}

// const startsWithXML = /^xml/i;

function validateTagName(tagname) {
  return isName(tagname) /* && !tagname.match(startsWithXML) */;
}

//this function returns the line number for the character at the given index
function getLineNumberForPosition(xmlData, index) {
  const lines = xmlData.substring(0, index).split(/\r?\n/);
  return {
    line: lines.length,

    // column number is last line's length + 1, because column numbering starts at 1:
    col: lines[lines.length - 1].length + 1
  };
}

//this function returns the position of the first character of match within attrStr
function getPositionFromMatch(match) {
  return match.startIndex + match[1].length;
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/fast-xml-parser@5.11.1/node_modules/fast-xml-parser/src/xmlparser/XMLParser.js






class XMLParser {

    constructor(options) {
        this.externalEntities = {};
        this.options = buildOptions(options);

    }
    /**
     * Parse XML dats to JS object 
     * @param {string|Uint8Array} xmlData 
     * @param {boolean|Object} validationOption 
     */
    parse(xmlData, validationOption) {
        if (typeof xmlData !== "string" && xmlData.toString) {
            xmlData = xmlData.toString();
        } else if (typeof xmlData !== "string") {
            throw new Error("XML data is accepted in String or Bytes[] form.")
        }

        if (validationOption) {
            if (validationOption === true) validationOption = {}; //validate with default options

            const result = validator_validate(xmlData, validationOption);
            if (result !== true) {
                throw Error(`${result.err.msg}:${result.err.line}:${result.err.col}`)
            }
        }
        const orderedObjParser = new OrderedObjParser(this.options, this.externalEntities);
        // orderedObjParser.entityDecoder.setExternalEntities(this.externalEntities);
        const orderedResult = orderedObjParser.parseXml(xmlData);
        if (this.options.preserveOrder || orderedResult === undefined) return orderedResult;
        else return prettify(orderedResult, this.options, orderedObjParser.matcher, orderedObjParser.readonlyMatcher);
    }

    /**
     * Add Entity which is not by default supported by this library
     * @param {string} key 
     * @param {string} value 
     */
    addEntity(key, value) {
        if (value.indexOf("&") !== -1) {
            throw new Error("Entity value can't have '&'")
        } else if (key.indexOf("&") !== -1 || key.indexOf(";") !== -1) {
            throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'")
        } else if (value === "&") {
            throw new Error("An entity with value '&' is not permitted");
        } else {
            this.externalEntities[key] = value;
        }
    }

    /**
     * Returns a Symbol that can be used to access the metadata
     * property on a node.
     * 
     * If Symbol is not available in the environment, an ordinary property is used
     * and the name of the property is here returned.
     * 
     * The XMLMetaData property is only present when `captureMetaData`
     * is true in the options.
     */
    static getMetaDataSymbol() {
        return XmlNode.getMetaDataSymbol();
    }
}
;// CONCATENATED MODULE: ../infra/http-dates.ts
// Date-string parsing for storage plugins, without a dependency or the
// `Date` constructor (boa's `Date.parse` coverage is not reliable across
// the formats HTTP/WebDAV/cloud APIs actually return).
//
// All functions return milliseconds since the Unix epoch, or `undefined`
// for anything unparseable — callers map that straight to the optional
// `createdAt` / `modifiedAt` fields of the host `StorageEntry` contract.
//
// Two shapes occur in practice:
// - RFC 1123 ("Sun, 06 Nov 1994 08:49:37 GMT") — WebDAV `getlastmodified`.
// - RFC 3339 / ISO 8601 ("1994-11-06T08:49:37Z", with optional fractional
//   seconds and ±hh:mm offsets) — WebDAV `creationdate`, Microsoft Graph
//   `createdDateTime` / `lastModifiedDateTime`, S3 `LastModified`.
//
// Timestamps are computed against the UTC epoch (leap seconds ignored,
// like every mainstream HTTP client).
/** Days from 1970-01-01 to the first of `month` in `year` (month 1-12). */ function daysFromCivil(year, month, day) {
    const y = month <= 2 ? year - 1 : year;
    const era = Math.floor(y / 400);
    const yoe = y - era * 400; // [0, 399]
    const mp = (month + 9) % 12; // [0, 11]
    const doy = Math.floor((153 * mp + 2) / 5) + day - 1; // [0, 365]
    const doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
    return era * 146097 + doe - 719468;
}
const MONTHS = (/* unused pure expression or super */ null && ({
    jan: 1,
    feb: 2,
    mar: 3,
    apr: 4,
    may: 5,
    jun: 6,
    jul: 7,
    aug: 8,
    sep: 9,
    oct: 10,
    nov: 11,
    dec: 12
}));
/** RFC 1123 / RFC 850-ish HTTP date: "Sun, 06 Nov 1994 08:49:37 GMT".
 *  The weekday name (if present) and "GMT" suffix are not validated —
 *  servers abbreviate inconsistently and the offset is always GMT here. */ function parseHttpDate(s) {
    // Strip an optional "Wkd, " prefix.
    const rest = s.replace(/^[A-Za-z]{3,9},\s*/, "").trim();
    const m = /^(\d{1,2})\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{2,4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(rest);
    if (m == null) return undefined;
    const month = MONTHS[m[2].toLowerCase()];
    if (month == null) return undefined;
    const day = parseInt(m[1], 10);
    let year = parseInt(m[3], 10);
    // Two-digit years: RFC 1123 (years 00-49 => 2000s, 50-99 => 1900s).
    if (m[3].length <= 2) year = year < 50 ? 2000 + year : 1900 + year;
    const hh = parseInt(m[4], 10);
    const mm = parseInt(m[5], 10);
    const ss = m[6] != null ? parseInt(m[6], 10) : 0;
    if (day < 1 || day > 31 || hh > 23 || mm > 59 || ss > 60) return undefined;
    return (daysFromCivil(year, month, day) * 86400 + hh * 3600 + mm * 60 + ss) * 1000;
}
/** RFC 3339 / ISO 8601: "1994-11-06T08:49:37Z", "…T08:49:37.123Z",
 *  "…T08:49:37+08:00". A space may appear where a `T` should (some
 *  servers emit "1994-11-06 08:49:37"). */ function parseIsoDate(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})[Tt ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(Z|z|[+-]\d{2}:?\d{2})?$/.exec(s.trim());
    if (m == null) return undefined;
    const year = parseInt(m[1], 10);
    const month = parseInt(m[2], 10);
    const day = parseInt(m[3], 10);
    const hh = parseInt(m[4], 10);
    const mm = parseInt(m[5], 10);
    const ss = m[6] != null ? parseInt(m[6], 10) : 0;
    if (month < 1 || month > 12 || day < 1 || day > 31 || hh > 23 || mm > 59 || ss > 60) return undefined;
    let seconds = daysFromCivil(year, month, day) * 86400 + hh * 3600 + mm * 60 + ss;
    let ms = m[7] != null ? parseInt((m[7] + "00").slice(0, 3), 10) : 0;
    const offset = m[8];
    if (offset != null && offset !== "Z" && offset !== "z") {
        const sign = offset[0] === "-" ? -1 : 1;
        const digits = offset.slice(1).replace(":", "");
        const oh = parseInt(digits.slice(0, 2), 10);
        const om = parseInt(digits.slice(2, 4), 10);
        seconds -= sign * (oh * 3600 + om * 60);
    }
    return seconds * 1000 + ms;
}
/** Try both known shapes; the input's own shape decides. */ function parseHttpOrIsoDate(s) {
    return parseIsoDate(s) ?? parseHttpDate(s);
}

;// CONCATENATED MODULE: ./src/listing.ts
// ListObjectsV2 response handling — pure (fast-xml-parser is an npm dep that
// runs identically under Node and the plugin runtime). The backend feeds
// fetched XML pages in and gets `StorageEntry[]` out; the selftest exercises
// the mapping against fixture XML.
//
// S3 quirks handled here:
//   - Keys AND CommonPrefixes arrive URL-encoded from AWS; MinIO returns
//     them raw. A tolerant decode (failure keeps the input verbatim) covers
//     both — the decoded form is the canonical key the plugin re-encodes for
//     `storage:get`, so the round-trip stays exact for either flavor.
//   - "Folder" markers: a zero-byte key ending in `/` (the listed dir's own
//     marker, e.g. `music/` inside a `music/`-prefixed listing, or any
//     `a/b/` marker surfaced at the root) is a directory placeholder, not a
//     file — elided.
//   - `<IsTruncated>` + `<NextContinuationToken>` drive the backend's
//     pagination loop (and the token rides the signed query of the next
//     page).



const xmlParser = new XMLParser({
    removeNSPrefix: true,
    // Keep tag text verbatim — Sizes are digit strings we parse ourselves,
    // and strnum would mangle display-ish values.
    parseTagValue: false,
    // Contents / CommonPrefixes repeat; force arrays so single-element
    // pages take the same code path.
    isArray: (name)=>/(?:^|:)(contents|commonprefixes)$/i.test(name)
});
/** Case-insensitive child lookup (matches the WebDAV plugin's `pick`). */ function pick(obj, name) {
    if (obj == null || typeof obj !== "object") return undefined;
    for (const k of Object.keys(obj)){
        if (k.toLowerCase() === name) return obj[k];
    }
    return undefined;
}
function pickAll(obj, name) {
    if (obj == null || typeof obj !== "object") return [];
    const out = [];
    for (const k of Object.keys(obj)){
        if (k.toLowerCase() === name) {
            const v = obj[k];
            out.push(...Array.isArray(v) ? v : [
                v
            ]);
        }
    }
    return out;
}
/** Parse one ListObjectsV2 XML body. Throws on malformed XML (a silent `[]`
 * once hid a runtime gap as an "empty directory" for weeks — same policy as
 * the WebDAV plugin's multistatus parser). */ function parseListPage(xml) {
    const parsed = xmlParser.parse(xml);
    const roots = pickAll(parsed, "listbucketresult");
    if (roots.length === 0) {
        throw new Error("s3: ListObjectsV2 response has no ListBucketResult root");
    }
    const keys = [];
    for (const contents of roots.flatMap((r)=>pickAll(r, "contents"))){
        const key = pick(contents, "key");
        if (typeof key !== "string" || key === "") continue;
        let size;
        const sizeStr = pick(contents, "size");
        if (typeof sizeStr === "string" && /^\d+$/.test(sizeStr.trim())) {
            size = parseInt(sizeStr.trim(), 10);
        }
        const lastmodStr = pick(contents, "lastmodified");
        const modifiedAt = typeof lastmodStr === "string" ? parseIsoDate(lastmodStr) : undefined;
        keys.push({
            key: s3Decode(key),
            size,
            modifiedAt
        });
    }
    const prefixes = [];
    for (const cp of roots.flatMap((r)=>pickAll(r, "commonprefixes"))){
        // <CommonPrefixes><Prefix>…</Prefix></CommonPrefixes> — the inner
        // element is what repeats in practice; accept either nesting.
        const inner = pickAll(cp, "prefix");
        for (const p of inner){
            if (typeof p === "string" && p !== "") prefixes.push(s3Decode(p));
        }
    }
    const truncated = String(pick(roots[0], "istruncated") ?? "false").toLowerCase() === "true";
    const token = pick(roots[0], "nextcontinuationtoken");
    return {
        keys,
        prefixes,
        truncated,
        nextToken: truncated && typeof token === "string" && token !== "" ? token : null
    };
}
/** Last path segment, tolerating a trailing slash. */ function lastSegment(p) {
    const t = p.endsWith("/") ? p.slice(0, -1) : p;
    const parts = t.split("/");
    return parts[parts.length - 1] ?? t;
}
/** Map one page to host entries for a listing of `prefix` (already
 *  dirToPrefix-shaped). Folder-marker keys are elided; dirs sort first. */ function pageToEntries(page, prefix) {
    const out = [];
    const seen = new Set();
    for (const { key, size, modifiedAt } of page.keys){
        if (key === prefix) continue; // the listed dir's own marker
        if (key.endsWith("/")) continue; // nested folder markers, not files
        if (seen.has(key)) continue;
        seen.add(key);
        out.push({
            name: lastSegment(key),
            path: "/" + key,
            size,
            isDir: false,
            // S3 has no creation time; LastModified is the only timestamp.
            modifiedAt
        });
    }
    for (const p of page.prefixes){
        const trimmed = p.endsWith("/") ? p.slice(0, -1) : p;
        if (trimmed === "" || trimmed === prefix.slice(0, -1)) continue;
        if (seen.has(trimmed)) continue;
        seen.add(trimmed);
        out.push({
            name: lastSegment(trimmed),
            path: "/" + trimmed,
            isDir: true
        });
    }
    out.sort((a, b)=>{
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
        if (a.path < b.path) return -1;
        if (a.path > b.path) return 1;
        return 0;
    });
    return out;
}
/** Parse an S3 `<Error>` XML body (operation failures) for its Code/Message —
 *  gives diagnostics like `NoSuchKey` / `RequestTimeTooSkewed` instead of a
 *  bare status. Returns null when the body isn't an S3 error document. */ function parseS3Error(xml) {
    try {
        const parsed = xmlParser.parse(xml);
        const err = pick(parsed, "error");
        if (err == null || typeof err !== "object") return null;
        const code = pick(err, "code");
        const message = pick(err, "message");
        if (typeof code !== "string") return null;
        return {
            code,
            message: typeof message === "string" ? message : ""
        };
    } catch  {
        return null;
    }
}

;// CONCATENATED MODULE: ./src/backend.ts
function backend_define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// S3 / S3-compatible storage provider — a headless JS plugin that serves
// `list` (ListObjectsV2 with a `/` delimiter) and `get` (streaming
// byte-range download), both SigV4-signed, over the `tur:rpc` channel, plus
// an access-key/secret-key connect flow (no OAuth). Any S3-compatible
// endpoint works: AWS S3, Cloudflare R2, MinIO, B2, … — addressing is always
// path-style (`<endpoint>/<bucket>/<key>`), which every flavor accepts.
//
// Multi-instance: each configured endpoint+bucket is one *instance* named
// `s3:<uuid>` (the storage row's `plugin_storage_id`). Per-instance config
// lives in `ease.db` (this plugin's KV) under `storage:<instance>` = JSON
// `{ alias, endpoint, region, bucket, accessKeyId, secretId }`; the secret
// access key lives in `ease.secret` under that `secretId`
// (scope `plugin:com.ease.s3`).
//
// Identity: this headless instance is created by `KeepBackendService` which
// stamps `PluginId("com.ease.s3")` into the per-instance data slot. `ease.*`
// bridge fns resolve the calling plugin from that slot — no pluginId
// argument is needed (or accepted) on any call here.
//
// Handlers, split by caller (the dispatcher routes strictly by scope). The
// host-called ops are contract literals — identical names for every storage
// provider, identity riding the payload (`pluginId` = this manifest's id,
// `storageId` = the `plugin_storage_id` instance) — typed by the shared sigs
// in `../../infra/host-ops.ts` (args/results below describe those sigs):
//
// hostRpc — the Rust host invokes these:
//   - storage:list           { pluginId, storageId, dir }          -> Entry[]
//   - storage:get            { pluginId, storageId, path, offset } -> registerStream: meta
//     { totalLength?, name?, contentType?, dataOffset? } + credit-gated body
//   - storage:removeInstance { pluginId, storageId }               -> {}
//
// viewRpc — this plugin's own view invokes these via `ease.rpc.call`
// (plugin-private sigs in `./rpc.ts`):
//   - s3:test      { storageId?, endpoint, region?, bucket, accessKeyId, secretAccessKey? } -> { result }
//   - s3:connect   { storageId?, endpoint, region?, bucket, alias?, accessKeyId, secretAccessKey? }
//                  -> { storageId, created }
//
// Signing: every request is bodyless GET, so the payload hash is the
// empty-string SHA-256 constant; signed headers are
// `host;range;x-amz-content-sha256;x-amz-date` (range only on downloads).
// The URL and the canonical request share the same encoded path + query
// strings byte-for-byte (see `s3path.ts` / `sigv4.ts`). The `host` header is
// signed but never sent — reqwest derives it from the URL, so its value must
// be the URL authority after default-port normalization.
//
// Error contract: messages prefixed `UNAUTHORIZED` / `TIMEOUT` are mapped by
// the host (`ease-js-storage`) to typed errors so the UI distinguishes auth
// failures (S3 signals bad keys / bad signatures as 403) and timeouts. S3
// `<Error>` documents surface their Code (e.g. `NoSuchKey`,
// `RequestTimeTooSkewed`).

// TextEncoder/TextDecoder polyfill FIRST — npm deps below may rely on them.







// npm deps — bundled by rspack (only `tur:*` / `ease` are externals).
// `@noble/hashes` is pure JS over Uint8Array (no WebCrypto), so it runs in
// the boa runtime; `uuid` uses the host-installed `crypto.getRandomValues`.




/** instance ("s3:<uuid>") -> config. Lazily loaded on first use. */ const instances = new Map();
const DEFAULT_REGION = "us-east-1";
class S3HttpError extends Error {
    constructor(status, code, message){
        super(message), backend_define_property(this, "status", void 0), backend_define_property(this, "code", void 0), this.status = status, this.code = code;
    }
}
function kvKey(instance) {
    return `storage:${instance}`;
}
function configOf(instance) {
    const st = instances.get(instance);
    if (st) return st;
    const raw = db.singleGet(kvKey(instance));
    if (raw == null) {
        throw new Error(`s3: no config for instance ${instance}`);
    }
    const cfg = JSON.parse(raw);
    const conf = {
        alias: cfg.alias ?? instance,
        endpoint: cfg.endpoint ?? "",
        region: cfg.region ?? DEFAULT_REGION,
        bucket: cfg.bucket ?? "",
        accessKeyId: cfg.accessKeyId ?? "",
        secretId: cfg.secretId ?? null,
        secretAccessKey: null
    };
    instances.set(instance, conf);
    return conf;
}
function loadSecret(conf) {
    if (conf.secretAccessKey != null) return conf.secretAccessKey;
    if (conf.secretId == null) return "";
    const v = secret.get(conf.secretId);
    conf.secretAccessKey = v == null ? "" : v;
    return conf.secretAccessKey;
}
// ---------------------------------------------------------------------------
// Signed request core
// ---------------------------------------------------------------------------
function headerOf(headers, name) {
    const lower = name.toLowerCase();
    for (const k of Object.keys(headers)){
        if (k.toLowerCase() === lower) return headers[k];
    }
    return undefined;
}
function isTimeoutMessage(message) {
    return /timed?\s?out|timeout/i.test(message);
}
/** Mark transport/auth errors with the prefixes the host maps to typed
 *  errors. S3 reports credential/signature failures as 401/403. */ function markedError(e) {
    if (e instanceof S3HttpError) {
        if (e.status === 401 || e.status === 403) {
            return new Error(`UNAUTHORIZED: HTTP ${e.status} ${e.code}: ${e.message}`);
        }
        return new Error(`HTTP ${e.status} ${e.code}: ${e.message}`);
    }
    const msg = String(e?.message ?? e);
    if (isTimeoutMessage(msg)) {
        return new Error(`TIMEOUT: ${msg}`);
    }
    return new Error(msg);
}
/** Build the URL + signed headers for one request. `extraHeaders` (lowercase
 *  names, e.g. `range`) join the signed set AND the wire set. */ function buildSignedRequest(conf, secretKey, key, query, extraHeaders) {
    const endpoint = normalizeEndpoint(conf.endpoint);
    const uri = canonicalUri(endpoint, conf.bucket, key);
    const canonicalQuery = canonicalQueryString(query);
    const { amzDate, dateStamp } = amzTimestamps(new Date());
    const region = conf.region || DEFAULT_REGION;
    const headers = {
        host: endpoint.host,
        "x-amz-content-sha256": EMPTY_PAYLOAD_SHA256,
        "x-amz-date": amzDate,
        ...extraHeaders
    };
    const { authorization } = signRequest({
        method: "GET",
        canonicalUri: uri,
        canonicalQuery,
        headers,
        amzDate,
        dateStamp,
        region,
        service: S3_SERVICE
    }, {
        accessKey: conf.accessKeyId,
        secretKey
    });
    const url = endpoint.origin + uri + (canonicalQuery !== "" ? `?${canonicalQuery}` : "");
    const sendHeaders = {
        "x-amz-content-sha256": headers["x-amz-content-sha256"],
        "x-amz-date": headers["x-amz-date"],
        Authorization: authorization
    };
    for (const [name, value] of Object.entries(extraHeaders)){
        // Signed names are lowercase per the SigV4 spec; send conventional
        // HTTP casing on the wire (`Range`).
        sendHeaders[name === "range" ? "Range" : name] = value;
    }
    return {
        url,
        sendHeaders
    };
}
/** Signed bodyless GET returning the full body as text (list / test). */ async function s3GetText(conf, key, query) {
    const { url, sendHeaders } = buildSignedRequest(conf, loadSecret(conf), key, query, {});
    const resp = await request({
        url,
        method: "GET",
        headers: sendHeaders
    }).promise;
    const bodyText = decodeUtf8(resp.body);
    if (resp.status >= 400) {
        const err = parseS3Error(bodyText);
        throw new S3HttpError(resp.status, err?.code ?? "", err?.message ?? `${resp.statusText || ""}`.trim());
    }
    return {
        status: resp.status,
        bodyText
    };
}
// ---------------------------------------------------------------------------
// list
// ---------------------------------------------------------------------------
/** Safety cap: 100 pages x 1000 keys = 100k entries per directory. */ const MAX_LIST_PAGES = 100;
async function listImpl(conf, dir) {
    const prefix = dirToPrefix(dir);
    const out = [];
    let token = null;
    let pages = 0;
    do {
        const params = [
            [
                "list-type",
                "2"
            ],
            [
                "delimiter",
                "/"
            ],
            [
                "max-keys",
                "1000"
            ],
            [
                "prefix",
                prefix
            ]
        ];
        if (token != null) params.push([
            "continuation-token",
            token
        ]);
        const resp = await s3GetText(conf, null, params);
        const page = parseListPage(resp.bodyText);
        out.push(...pageToEntries(page, prefix));
        token = page.nextToken;
        pages += 1;
    }while (token != null && pages < MAX_LIST_PAGES)
    return out;
}
// ---------------------------------------------------------------------------
// get (streaming byte-range download)
// ---------------------------------------------------------------------------
function parseTotalLength(headers) {
    // Prefer Content-Range's total (`bytes start-end/total`) — it gives the
    // full file size; Content-Length on a Range response is the partial length.
    const cr = headerOf(headers, "Content-Range");
    if (cr) {
        const m = /\/(\d+)\s*$/.exec(cr);
        if (m) return parseInt(m[1], 10);
    }
    const cl = headerOf(headers, "Content-Length");
    if (cl && /^\d+$/.test(cl.trim())) return parseInt(cl.trim(), 10);
    return undefined;
}
/**
 * Streaming get opener: one ranged request per stream, Range included in the
 * signed headers. The dispatcher pumps `body` with host-granted credits and
 * calls `release` on any exit (host cancel included) — `t.cancel()`
 * wire-aborts the download. S3 always honors Range (206 + Content-Range),
 * but a gateway that doesn't gets the same `dataOffset: 0` fallback as the
 * WebDAV plugin: the host drops the prefix bytes itself.
 */ async function openGet(conf, path, offset) {
    const { url, sendHeaders } = buildSignedRequest(conf, loadSecret(conf), pathToKey(path), [], {
        range: `bytes=${offset}-`
    });
    // Keep the Task, not just the promise — it is the abort handle.
    const task = requestStream({
        url,
        method: "GET",
        headers: sendHeaders
    });
    let resp;
    try {
        // requestStream's promise rejects (object with `message`) on transport
        // errors; HTTP-level failures resolve with a status instead.
        resp = await task.promise;
    } catch (e) {
        throw markedError(e);
    }
    if (resp.status >= 400) {
        // Fail the RPC itself (throw) so the host's `get` returns Err —
        // callers treat missing entries as `None`. The error rides the reply,
        // not the byte stream.
        task.cancel();
        throw markedError(new S3HttpError(resp.status, "", (resp.statusText ?? "").trim()));
    }
    const contentRange = headerOf(resp.headers, "Content-Range");
    const rangeHonored = contentRange != null || resp.status === 206;
    return {
        meta: {
            totalLength: parseTotalLength(resp.headers),
            name: path.split("/").pop() || path,
            contentType: headerOf(resp.headers, "Content-Type"),
            // The host assumes pushed chunks start at `offset`; a server that
            // ignored the Range request sends them from 0 — say so, and the
            // host drops the prefix.
            dataOffset: rangeHonored ? offset : 0
        },
        body: resp.body,
        release: ()=>task.cancel(),
        mapError: (e)=>markedError(e)
    };
}
// ---------------------------------------------------------------------------
// test / connect / instance lifecycle
// ---------------------------------------------------------------------------
/** Resolve the credentials for a test call: explicit values win; on edit a
 *  blank secret falls back to the stored one. */ function testCredentials(args) {
    const endpoint = args.endpoint.trim();
    const bucket = args.bucket.trim();
    const accessKeyId = args.accessKeyId.trim();
    const secretAccessKey = args.secretAccessKey ?? "";
    if (secretAccessKey !== "" || args.storageId == null) {
        return {
            conf: {
                alias: "",
                endpoint,
                region: (args.region ?? "").trim() || DEFAULT_REGION,
                bucket,
                accessKeyId,
                secretId: null,
                secretAccessKey: secretAccessKey === "" ? null : secretAccessKey
            },
            fresh: true
        };
    }
    const conf = configOf(args.storageId);
    return {
        conf: {
            ...conf,
            endpoint: endpoint !== "" ? endpoint : conf.endpoint,
            bucket: bucket !== "" ? bucket : conf.bucket,
            accessKeyId: accessKeyId !== "" ? accessKeyId : conf.accessKeyId
        },
        fresh: false
    };
}
async function testImpl(args) {
    try {
        const { conf } = testCredentials(args);
        // One-key list validates endpoint + bucket + keys + signature + clock
        // skew in a single round trip.
        await s3GetText(conf, null, [
            [
                "list-type",
                "2"
            ],
            [
                "max-keys",
                "1"
            ]
        ]);
        return {
            result: "SUCCESS"
        };
    } catch (e) {
        if (e instanceof S3HttpError && (e.status === 401 || e.status === 403)) {
            return {
                result: "UNAUTHORIZED"
            };
        }
        const msg = String(e?.message ?? e);
        if (isTimeoutMessage(msg)) return {
            result: "TIMEOUT"
        };
        return {
            result: "OTHER_ERROR"
        };
    }
}
/** Bucket naming: 2–63 chars from the S3 charset (lowercase-strict AWS rules
 *  relaxed to allow uppercase for permissive MinIO setups — the server
 *  rejects what it doesn't like). */ const BUCKET_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,61}[A-Za-z0-9]$/;
/**
 * Create or update an S3 instance. On create (no `storageId`), persist the
 * config + secret key, mint `s3:<uuid>`, and register the host storage row
 * (`context.createStorage` — the host pops the create form). On update,
 * rewrite the kv config; a blank `secretAccessKey` keeps the stored secret.
 */ function connectImpl(args) {
    const endpoint = args.endpoint.trim();
    const region = (args.region ?? "").trim() || DEFAULT_REGION;
    const bucket = args.bucket.trim();
    const alias = (args.alias ?? "").trim() || "S3";
    const accessKeyId = args.accessKeyId.trim();
    const secretAccessKey = args.secretAccessKey ?? "";
    // normalizeEndpoint throws on garbage endpoints — validate before
    // persisting anything.
    normalizeEndpoint(endpoint);
    if (!BUCKET_RE.test(bucket)) {
        throw new Error("s3: invalid bucket name (2-63 chars, letters/digits/./-/_)");
    }
    if (accessKeyId === "") {
        throw new Error("s3: access key id cannot be empty");
    }
    if (args.storageId != null) {
        // Update: keep the existing secret unless a new one is given.
        const conf = configOf(args.storageId);
        let secretId = conf.secretId;
        if (secretAccessKey !== "") {
            const newId = secret.put(secretAccessKey);
            if (secretId != null) secret.remove(secretId);
            secretId = newId;
        }
        const updated = {
            alias,
            endpoint,
            region,
            bucket,
            accessKeyId,
            secretId,
            secretAccessKey: secretAccessKey !== "" ? secretAccessKey : null
        };
        db.singleSet(kvKey(args.storageId), JSON.stringify(configToJson(updated)));
        instances.set(args.storageId, updated);
        external_ease_context.notifyChange();
        return {
            storageId: args.storageId,
            created: false
        };
    }
    // Create: the secret key is required.
    if (secretAccessKey === "") {
        throw new Error("s3: secret access key cannot be empty");
    }
    const instance = `s3:${dist_v4()}`;
    const secretId = secret.put(secretAccessKey);
    const conf = {
        alias,
        endpoint,
        region,
        bucket,
        accessKeyId,
        secretId,
        secretAccessKey
    };
    db.singleSet(kvKey(instance), JSON.stringify(configToJson(conf)));
    instances.set(instance, conf);
    // Register the host storage row; the upcall pops the create form.
    external_ease_context.createStorage(instance);
    return {
        storageId: instance,
        created: true
    };
}
function configToJson(conf) {
    return {
        alias: conf.alias,
        endpoint: conf.endpoint,
        region: conf.region,
        bucket: conf.bucket,
        accessKeyId: conf.accessKeyId,
        secretId: conf.secretId
    };
}
/** Remove an instance: drop its config (kv) + secret key, ask the host to
 *  delete the storage row, and reload the dashboard. Called from the host
 *  trash button (`storage:removeInstance` via `storage_plugin.remove_instance`). */ function removeInstance(args) {
    const conf = instances.get(args.storageId);
    let secretId = conf?.secretId;
    if (secretId === undefined) {
        const raw = db.singleGet(kvKey(args.storageId));
        if (raw != null) {
            try {
                secretId = JSON.parse(raw).secretId ?? null;
            } catch  {
                secretId = null;
            }
        }
    }
    if (secretId != null) {
        secret.remove(secretId);
    }
    db.singleDelete(kvKey(args.storageId));
    instances.delete(args.storageId);
    // Complete the disconnect on the host side: drop the storage row, then
    // reload so the dashboard + edit page reflect the removal.
    external_ease_context.removeStorage(args.storageId);
    external_ease_context.notifyChange();
}
// ---------------------------------------------------------------------------
// Register handlers
//
// The module lifecycle contract: the engine calls `start()` after eval (and
// runs the returned cleanup before the next load / at destroy). Handlers are
// per-instance and die with the instance, so no cleanup is needed.
// ---------------------------------------------------------------------------
function backend_start() {
    hostRpc.registerHandler(StorageListSig, (args)=>listImpl(configOf(args.storageId), args.dir).catch((e)=>{
            throw markedError(e);
        }));
    hostRpc.registerStream(StorageGetSig, (args)=>openGet(configOf(args.storageId), args.path, args.offset).catch((e)=>{
            throw markedError(e);
        }));
    viewRpc.registerHandler(S3TestSig, (args)=>testImpl(args));
    viewRpc.registerHandler(S3ConnectSig, (args)=>connectImpl(args));
    hostRpc.registerHandler(StorageRemoveInstanceSig, (args)=>{
        removeInstance(args);
    });
}

var __webpack_exports__start = __webpack_exports__.n;
export { __webpack_exports__start as start };

//# sourceMappingURL=backend.js.map