import { onEvent } from "tur:rpc";
import { db } from "ease";
// The require scope
var __webpack_require__ = {};

// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ start)
});

;// CONCATENATED MODULE: external "tur:rpc"

;// CONCATENATED MODULE: external "ease"

;// CONCATENATED MODULE: ./src/backend.ts
// Play Counts plugin — backend module (long-lived).
//
// Loaded by `KeepBackendService` into a headless tur instance stamped with
// `PluginId("com.ease.playcount")`. Subscribes to the `music:play` event on
// the plugin-event bus channel (fire-and-forget, one channel per plugin
// instance); the host (`PluginRepository.bindPlayerEvents`) calls
// `plugin.event { pluginId, type, payload }` for each play and the Rust
// side emits it to this handler via the plugin's RpcClient.
//
// Data model (KV multi-value, append-only):
//   key   = "plays:YYYY-MM-DD"
//   value = JSON `{ musicId, title, ts }`
// The view module (`view.ts` → `play-counts.ts`) reads the rows back via
// `db.multiGetAllMulti` and aggregates per musicId.


function pad2(n) {
    return n < 10 ? "0" + n : String(n);
}
/** Local-time day key, matching what the view's range selector expects. */ function dayKey(ts) {
    const d = new Date(ts);
    return `plays:${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
// The module lifecycle contract: the engine calls `start()` after eval (and
// runs the returned cleanup before the next load / at destroy). The event
// subscription dies with the instance, so no cleanup is needed.
function start() {
    onEvent("music:play", (args)=>{
        db.multiAppend(dayKey(args.ts), JSON.stringify({
            musicId: args.musicId,
            title: args.title,
            ts: args.ts
        }));
    });
}

var __webpack_exports__start = __webpack_exports__.n;
export { __webpack_exports__start as start };

//# sourceMappingURL=backend.js.map