import { request, requestStream } from "tur:net";
import { decodeUtf8 } from "tur:std";
import { endStream, errorStream, pushChunk, registerHandler } from "tur:rpc";
import { context, db, secret } from "ease";
// The require scope
var __webpack_require__ = {};

// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ start)
});

;// CONCATENATED MODULE: external "tur:net"

;// CONCATENATED MODULE: external "tur:std"

;// CONCATENATED MODULE: external "tur:rpc"

;// CONCATENATED MODULE: external "ease"

;// CONCATENATED MODULE: ./src/backend.ts
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// OneDrive storage provider — a headless JS plugin that serves `list` and
// `get` (streaming byte-range download) over the `tur:rpc` channel, plus
// OAuth add/remove instance ops. The host `JsStorageBackend` treats OneDrive
// like any other `StorageBackend`.
//
// Multi-instance: each configured OneDrive account is one *instance* named
// `onedrive:<uuid>` (the storage row's `plugin_storage_id`). Per-instance
// config lives in `ease.db` (this plugin's KV) under
// `storage:<instance>` = JSON `{ alias, secretId }`; the refresh token lives
// in `ease.secret` under that `secretId` (scope `plugin:com.ease.onedrive`).
// Access tokens are cached in module state; on a 401 the refresh token is
// rotated and persisted back to the secret store.
//
// Identity: this headless instance is created by `KeepBackendService` which
// stamps `PluginId("com.ease.onedrive")` into the per-instance data slot.
// `ease.*` bridge fns resolve the calling plugin from that slot — no
// pluginId argument is needed (or accepted) on any call here.
//
// Host handlers (under the `onedrive:` prefix):
//   - onedrive:list           { instance, dir }                  -> Entry[]
//   - onedrive:get            { instance, streamId, path, offset } -> { totalLength?, name?, contentType? }
//   - onedrive:oauth.url      {}                                 -> { url }
//   - onedrive:oauth.exchange { code, alias }                    -> { instance }
//   - onedrive:removeInstance { instance }                       -> {}
//
// Ported from the Rust implementation at
// `rust-libs/ease-remote-storage/src/impls/onedrive.rs`.




// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const ONEDRIVE_ROOT_API = "https://graph.microsoft.com/v1.0/me/drive";
const ONEDRIVE_API_BASE = "https://login.microsoftonline.com/common/oauth2/v2.0";
const ONEDRIVE_REDIRECT_URI = "easem://oauth2redirect/";
const CLIENT_ID = "5db0dade-b21c-4161-bd4f-027e0f3e4700";
const SCOPES = "Files.Read offline_access";
/** instance ("onedrive:<uuid>") -> state. Lazily loaded on first use. */ const instances = new Map();
class HttpError extends Error {
    constructor(status, message){
        super(message), _define_property(this, "status", void 0), this.status = status;
    }
}
function kvKey(instance) {
    return `storage:${instance}`;
}
function configOf(instance) {
    const st = instances.get(instance);
    if (st) return st;
    const raw = db.singleGet(kvKey(instance));
    if (raw == null) {
        throw new Error(`onedrive: no config for instance ${instance}`);
    }
    const cfg = JSON.parse(raw);
    const state = {
        alias: cfg.alias ?? instance,
        secretId: cfg.secretId,
        accessToken: null
    };
    instances.set(instance, state);
    return state;
}
/** Read this instance's current refresh token from the secret store. */ function loadRefreshToken(secretId) {
    const v = secret.get(secretId);
    if (v == null) {
        throw new Error(`onedrive: refresh token missing for secretId ${secretId}`);
    }
    return v;
}
/** Persist a (possibly rotated) refresh token to the secret store. */ function saveRefreshToken(secretId, token) {
    secret.remove(secretId);
    // re-put to replace — secret ids are immutable per row; we reuse the id by
    // deleting + re-inserting. (The secret store has no in-place update.)
    const newId = secret.put(token);
    if (newId !== secretId) {
        // The id shifted — update the config so future loads resolve it. This
        // is rare (only if the store hands out a different id after delete);
        // we patch both the kv and the in-memory state.
        instances.forEach((s)=>{
            if (s.secretId === secretId) s.secretId = newId;
        });
        patchConfigSecretId(secretId, newId);
    }
}
function patchConfigSecretId(oldId, newId) {
    // Find the instance whose config references oldId and rewrite it. We scan
    // the loaded instances (cheap; typically a handful).
    for (const [instance, st] of instances){
        if (st.secretId === newId) {
            db.singleSet(kvKey(instance), JSON.stringify({
                alias: st.alias,
                secretId: newId
            }));
        }
    }
}
// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------
function authHeaders(token) {
    return {
        Authorization: `bearer ${token}`
    };
}
function isAuthError(e) {
    return e instanceof HttpError && e.status === 401;
}
function formEncode(fields) {
    return Object.entries(fields).map(([k, v])=>`${k}=${encodeURIComponent(v)}`).join("&");
}
async function redeemToken(grantType, extra) {
    const body = formEncode({
        client_id: CLIENT_ID,
        redirect_uri: ONEDRIVE_REDIRECT_URI,
        grant_type: grantType,
        ...extra
    });
    const resp = await request({
        url: `${ONEDRIVE_API_BASE}/token`,
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body
    }).promise;
    if (!resp.ok) {
        throw new HttpError(resp.status, `token ${grantType} failed: ${resp.status} ${resp.statusText}`);
    }
    const j = JSON.parse(decodeUtf8(resp.body));
    return {
        access_token: j.access_token,
        refresh_token: j.refresh_token
    };
}
async function refreshAccess(instance) {
    const st = configOf(instance);
    const rt = loadRefreshToken(st.secretId);
    const t = await redeemToken("refresh_token", {
        refresh_token: rt
    });
    st.accessToken = t.access_token;
    // Persist the rotated refresh token.
    saveRefreshToken(st.secretId, t.refresh_token);
    return t.access_token;
}
async function ensureToken(instance) {
    const st = configOf(instance);
    if (st.accessToken) return st.accessToken;
    return refreshAccess(instance);
}
/** Run `fn` with a fresh access token; on 401 rotate once and retry. */ async function withRetry(instance, fn) {
    const token = await ensureToken(instance);
    try {
        return await fn(token);
    } catch (e) {
        if (isAuthError(e)) {
            const fresh = await refreshAccess(instance);
            return await fn(fresh);
        }
        throw e;
    }
}
function computeListUrl(dir) {
    const sub = dir === "/" ? "/root/children" : `/root:${dir}:/children`;
    return `${ONEDRIVE_ROOT_API}${sub}`;
}
async function listImpl(token, dir) {
    let url = computeListUrl(dir);
    const out = [];
    for(;;){
        const resp = await request({
            url,
            method: "GET",
            headers: authHeaders(token)
        }).promise;
        if (!resp.ok) {
            throw new HttpError(resp.status, `list: ${resp.status} ${resp.statusText}`);
        }
        const j = JSON.parse(decodeUtf8(resp.body));
        const value = j.value ?? [];
        for (const item of value){
            const name = item.name;
            const path = `${dir}/${name}`;
            if (item.file) {
                out.push({
                    name,
                    path,
                    size: item.size,
                    isDir: false
                });
            } else if (item.folder) {
                out.push({
                    name,
                    path,
                    isDir: true
                });
            }
        }
        if (typeof j["@odata.nextLink"] === "string") {
            url = j["@odata.nextLink"];
        } else {
            break;
        }
    }
    // dirs first, then by path — matches the Rust ordering.
    out.sort((a, b)=>{
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
        if (a.path < b.path) return -1;
        if (a.path > b.path) return 1;
        return 0;
    });
    return out;
}
// ---------------------------------------------------------------------------
// get (streaming byte-range download)
// ---------------------------------------------------------------------------
function parseTotalLength(headers) {
    // Prefer Content-Range's total (`bytes start-end/total`) — it gives the
    // full file size; Content-Length on a Range response is the partial length.
    const cr = headers["Content-Range"] ?? headers["content-range"];
    if (cr) {
        const m = /\/(\d+)\s*$/.exec(cr);
        if (m) return parseInt(m[1], 10);
    }
    const cl = headers["Content-Length"] ?? headers["content-length"];
    if (cl) return parseInt(cl, 10);
    return undefined;
}
async function getImpl(token, streamId, path, offset) {
    const url = `${ONEDRIVE_ROOT_API}/root:${path}:/content`;
    const headers = authHeaders(token);
    headers["Range"] = `bytes=${offset}-`;
    const resp = await requestStream({
        url,
        method: "GET",
        headers
    }).promise;
    if (!resp.ok) {
        errorStream(streamId, `get: ${resp.status} ${resp.statusText}`);
        return {};
    }
    const totalLength = parseTotalLength(resp.headers);
    const contentType = resp.headers["Content-Type"] ?? resp.headers["content-type"];
    const name = path.split("/").pop() || path;
    // Pump the body asynchronously: the host returns from open_stream as soon
    // as this metadata lands, then drains the stream as chunks arrive.
    (async ()=>{
        try {
            for await (const chunk of resp.body){
                pushChunk(streamId, chunk);
            }
            endStream(streamId);
        } catch (e) {
            errorStream(streamId, String(e?.message ?? e));
        }
    })();
    return {
        totalLength,
        name,
        contentType
    };
}
// ---------------------------------------------------------------------------
// OAuth + instance lifecycle
// ---------------------------------------------------------------------------
function authorizeUrl() {
    const q = formEncode({
        client_id: CLIENT_ID,
        response_type: "code",
        redirect_uri: ONEDRIVE_REDIRECT_URI,
        response_mode: "query",
        scope: SCOPES
    });
    return `${ONEDRIVE_API_BASE}/authorize?${q}`;
}
/** RFC 4122 v4 UUID (crypto.getRandomValues may be absent in boa; Math.random
 *  is plenty for non-adversarial instance-id minting). */ function uuid() {
    const hex = "0123456789abcdef";
    let out = "";
    for(let i = 0; i < 36; i++){
        if (i === 8 || i === 13 || i === 18 || i === 23) {
            out += "-";
        } else if (i === 14) {
            out += "4";
        } else if (i === 19) {
            out += hex[Math.random() * 4 | 0 | 8];
        } else {
            out += hex[Math.random() * 16 | 0];
        }
    }
    return out;
}
/**
 * Exchange an authorization code for tokens, mint a new `onedrive:<uuid>`
 * instance, persist its config + refresh token, and return the instance id.
 * `args.alias` is the user-facing display name.
 */ async function exchangeCode(args) {
    const t = await redeemToken("authorization_code", {
        code: args.code
    });
    const instance = `onedrive:${uuid()}`;
    const secretId = secret.put(t.refresh_token);
    const alias = args.alias && args.alias.length > 0 ? args.alias : "OneDrive";
    db.singleSet(kvKey(instance), JSON.stringify({
        alias,
        secretId
    }));
    // Prime the in-memory state so the first list/get skips a config reload.
    instances.set(instance, {
        alias,
        secretId,
        accessToken: t.access_token
    });
    return {
        instance
    };
}
/** Remove an instance: drop its config (kv) + its refresh-token secret, ask
 *  the host to delete the storage row, and reload the dashboard. Called from
 *  two paths — the view-side disconnect button (`onedrive:removeInstance`
 *  via `ease.rpc.call`) and the host trash button (which also deletes the
 *  row; `removeStorage` is idempotent so the overlap is harmless). */ function removeInstance(args) {
    const st = instances.get(args.instance);
    let secretId = st?.secretId;
    if (secretId === undefined) {
        const raw = db.singleGet(kvKey(args.instance));
        if (raw != null) {
            try {
                secretId = JSON.parse(raw).secretId;
            } catch  {
            /* ignore — config corrupt; still delete the kv row */ }
        }
    }
    if (secretId !== undefined) {
        secret.remove(secretId);
    }
    db.singleDelete(kvKey(args.instance));
    instances.delete(args.instance);
    // Complete the disconnect on the host side: drop the storage row, then
    // reload so the dashboard + edit page reflect the removal.
    context.removeStorage(args.instance);
    context.notifyChange();
}
// ---------------------------------------------------------------------------
// Register handlers
// ---------------------------------------------------------------------------
// The module lifecycle contract: the engine calls `start()` after eval (and
// runs the returned cleanup before the next load / at destroy). Handlers are
// per-instance and die with the instance, so no cleanup is needed.
function start() {
    registerHandler("onedrive:list", (args)=>withRetry(args.instance, (token)=>listImpl(token, args.dir)));
    registerHandler("onedrive:get", (args)=>{
        const { instance, streamId, path, offset } = args;
        return withRetry(instance, (token)=>getImpl(token, streamId, path, offset)).catch((e)=>{
            // surface non-401 failures as a stream error
            errorStream(streamId, String(e?.message ?? e));
            return {};
        });
    });
    registerHandler("onedrive:oauth.url", ()=>({
            url: authorizeUrl()
        }));
    registerHandler("onedrive:oauth.exchange", (args)=>exchangeCode(args));
    registerHandler("onedrive:removeInstance", (args)=>{
        removeInstance(args);
        return {};
    });
}

var __webpack_exports__start = __webpack_exports__.n;
export { __webpack_exports__start as start };

//# sourceMappingURL=backend.js.map