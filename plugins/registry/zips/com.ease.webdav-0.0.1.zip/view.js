import { Color, Column, Condition, Container, CrossAxisAlignment, HitTestBehavior, Input, MainAxisAlignment, MainAxisSize, PointerInteract, Row, SizedBox, Text, createTextEditingController, decodeUtf8, derive, encodeUtf8, mount, mutate, source as external_tur_std_source, view, viewportSize$ } from "tur:std";
import { context, db, rpc, themes } from "ease";
// The require scope
var __webpack_require__ = {};

// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ view_start)
});

;// CONCATENATED MODULE: ../infra/string-polyfill.ts
// ECMAScript Annex-B / legacy builtin polyfill for the tur (boa) runtime.
//
// boa skips deprecated Annex-B extras that real-world npm packages still
// call. Import this module FIRST from every bundle entry (side-effect
// import), before any dependency that might rely on these.
//
// Found the hard way: fast-xml-parser's `readTagExp` calls
// `String.prototype.substr` on every namespace-prefixed tag — with
// `removeNSPrefix: true` that is EVERY tag of a WebDAV multistatus body —
// and the resulting TypeError (swallowed by a `catch { return [] }` at the
// time) turned every WebDAV `storage:list` into a silent empty directory
// on device. Pinned by the `ease-tur-rpc` regression test
// `fxp_parses_real_multistatus_in_boa`.
// --- String.prototype.substr (Annex B; absent in boa) ----------------------
//
// Spec semantics: NaN start → 0; negative start counts from the end;
// start >= length → ""; omitted length → to the end; NaN / negative / zero
// length → "". Installed via defineProperty so the lib's (deprecated) TS
// declaration is untouched.
if (typeof String.prototype.substr !== "function") {
    Object.defineProperty(String.prototype, "substr", {
        value: function substr(start, length) {
            const s = String(this);
            const size = s.length;
            let begin = Number(start);
            if (Number.isNaN(begin)) begin = 0;
            if (begin < 0) begin = Math.max(size + begin, 0);
            if (begin >= size) return "";
            let end = size;
            if (length !== undefined) {
                const len = Number(length);
                if (Number.isNaN(len) || len <= 0) return "";
                end = Math.min(begin + len, size);
            }
            return s.substring(begin, end);
        },
        writable: true,
        configurable: true,
        enumerable: false
    });
}


;// CONCATENATED MODULE: external "tur:std"

;// CONCATENATED MODULE: ../infra/text-polyfill.ts
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// TextEncoder / TextDecoder polyfill for the tur (boa) runtime.
//
// boa implements ECMAScript but not the Web Platform text codecs. `tur:std`
// already ships the UTF-8 primitives (`encodeUtf8` / `decodeUtf8`), so these
// classes are thin WHATWG-shaped wrappers over them instead of another
// hand-rolled encoder. Import this module FIRST from every bundle entry
// (side-effect import) — npm dependencies bundled after it see the globals.
//
// Semantics notes:
// - `encode`: WHATWG replaces lone surrogates with U+FFFD; boa's
//   `encodeUtf8` renders them as literal `\uD800` text, so the input is
//   normalized with `String.prototype.toWellFormed()` (ES2024, implemented
//   by boa) first.
// - `encodeInto`: never splits a code point's multi-byte sequence — the cut
//   is walked back to a UTF-8 lead-byte boundary.
// - `decode`: `decodeUtf8` is strict (throws on invalid bytes), which maps
//   1:1 to the `fatal: true` option; the default non-fatal mode replaces
//   each invalid byte with U+FFFD by greedily re-decoding the longest valid
//   prefix (binary search).
// - `decode(bytes, { stream: true })` decodes each chunk independently (no
//   cross-call decoder state) — the same trade-off the common
//   `fast-text-encoding` polyfill makes.
// - UTF-8 labels only; any other label throws `RangeError`.

const UTF8_LABELS = [
    "utf-8",
    "utf8",
    "unicode-1-1-utf-8",
    "unicode11utf8",
    "unicode20utf8",
    "x-unicode20utf8"
];
/** View of a BufferSource as bytes, honoring byteOffset / byteLength. */ function toBytes(input) {
    if (input instanceof ArrayBuffer) return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
}
/** `String.prototype.toWellFormed()` (ES2024) — implemented by boa, but not
 *  declared in the ES2020 lib the plugins typecheck against, hence the
 *  local cast instead of a program-wide lib bump. */ function wellFormed(s) {
    return s.toWellFormed();
}
/** Non-fatal decode: U+FFFD per invalid byte, via longest-valid-prefix
 *  binary search over `decodeUtf8` (which is strict). */ function decodeLossy(bytes) {
    try {
        return decodeUtf8(bytes);
    } catch  {
        let out = "";
        let start = 0;
        while(start < bytes.length){
            let lo = 0;
            let hi = bytes.length - start;
            while(lo < hi){
                const mid = lo + hi + 1 >> 1;
                let ok = true;
                try {
                    decodeUtf8(bytes.subarray(start, start + mid));
                } catch  {
                    ok = false;
                }
                if (ok) lo = mid;
                else hi = mid - 1;
            }
            if (lo > 0) {
                out += decodeUtf8(bytes.subarray(start, start + lo));
                start += lo;
            } else {
                out += "\uFFFD";
                start += 1;
            }
        }
        return out;
    }
}
if (typeof globalThis.TextEncoder === "undefined") {
    class TextEncoder {
        get encoding() {
            return "utf-8";
        }
        encode(input) {
            const s = input == null ? "" : String(input);
            return encodeUtf8(wellFormed(s));
        }
        encodeInto(source, destination) {
            if (!(destination instanceof Uint8Array)) {
                throw new TypeError("encodeInto: destination must be a Uint8Array");
            }
            const bytes = encodeUtf8(wellFormed(String(source ?? "")));
            // Cut at a lead-byte boundary so no code point splits; a
            // continuation byte matches 10xxxxxx (0xC0 mask).
            let n = Math.min(bytes.length, destination.length);
            while(n > 0 && n < bytes.length && (bytes[n] & 0xc0) === 0x80)n--;
            destination.set(bytes.subarray(0, n));
            return {
                read: n === 0 ? 0 : decodeUtf8(bytes.subarray(0, n)).length,
                written: n
            };
        }
    }
    globalThis.TextEncoder = TextEncoder;
}
if (typeof globalThis.TextDecoder === "undefined") {
    class TextDecoder {
        get encoding() {
            return "utf-8";
        }
        decode(input, _options) {
            if (input == null) return "";
            let bytes = toBytes(input);
            if (!this.ignoreBOM && bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
                bytes = bytes.subarray(3);
            }
            return this.fatal ? decodeUtf8(bytes) : decodeLossy(bytes);
        }
        constructor(label, options){
            _define_property(this, "fatal", void 0);
            _define_property(this, "ignoreBOM", void 0);
            const norm = String(label ?? "utf-8").trim().toLowerCase();
            if (!UTF8_LABELS.includes(norm)) {
                throw new RangeError(`TextDecoder: unsupported encoding label '${label}' (UTF-8 only)`);
            }
            this.fatal = !!options?.fatal;
            this.ignoreBOM = !!options?.ignoreBOM;
        }
    }
    globalThis.TextDecoder = TextDecoder;
}

;// CONCATENATED MODULE: external "ease"

;// CONCATENATED MODULE: ./src/view.ts
// WebDAV storage view — the tur-rendered form shown both in the add-storage
// page (create mode) and when editing an existing WebDAV storage (edit mode).
//
// Mode is derived from `ease.context.storageId$`: `null` = create (no storage
// row yet), a real `plugin_storage_id` = edit. The view branches once at
// module load (the value is static for the instance lifetime).
//
// - Create: alias / address / anonymous / username / password fields plus
//   Test + Save buttons. Save calls the plugin backend (`webdav:connect`) via
//   `ease.rpc.call`; the backend persists the config + secret and registers
//   the host storage row (`ease.context.createStorage`), whose upcall pops
//   this page — there is no host-side "save" step.
//
// - Edit: fields prefilled from the plugin's `ease.db` config
//   (`storage:<instance>`); a blank password means "keep the stored one".
//   Save rewrites the config via `webdav:connect` (+ `context.notifyChange`
//   so the dashboard shows the new alias). Removal is handled by the host's
//   top-bar trash icon.
//
// This module is bundled to `view.js` (see `rspack.config.cjs`) and loaded by
// the plugin-storage view host in `EditStorage.kt`. It runs in an isolated
// view instance, separate from the headless backend instance that owns the
// `webdav:*` RPC handlers.
// TextEncoder/TextDecoder polyfill FIRST — npm deps may rely on them.




const PROVIDER = "webdav";
// Inherit the host app's Material 3 theme so the form matches the
// surrounding UI. `themes.color(name)` throws on unknown names — views load
// long after the host pushes its theme, so a miss is always a bug (typo /
// outdated plugin) and failing fast beats silently rendering a fallback.
const COLOR_PRIMARY = Color.hex(themes.color("primary"));
const COLOR_CARD = Color.hex(themes.color("surface"));
const COLOR_TEXT = Color.hex(themes.color("onSurface"));
const COLOR_TEXT_MUTED = Color.hex(themes.color("onSurfaceVariant"));
const COLOR_DIVIDER = Color.hex(themes.color("outlineVariant"));
const COLOR_ERROR = Color.hex(themes.color("error"));
const COLOR_WHITE = Color.hex("#FFFFFF");
// --- mode + prefilled config ---------------------------------------------
//
// No module-level mutable state: everything reactive is a declaration
// (`source` / `derive`), materialized into the instance store that
// `start({ store })` receives. The `hydrate$` mutation (dispatched from
// `start` BEFORE mount) writes the prefilled controllers into the controller
// sources; `Input` resolves a controller source at build time, so the
// hydrated instances are what get attached — the seeds below are
// placeholders that never reach an Input.
const isEdit$ = derive((ctx)=>ctx.get(context.storageId$) !== null);
// Local reactive state (declarations — materialized into the instance store
// that `start({ store })` received).
const anonymous = external_tur_std_source(false);
const busy = external_tur_std_source(false);
const statusText = external_tur_std_source("");
const statusIsError = external_tur_std_source(false);
const aliasController$ = external_tur_std_source(createTextEditingController({
    initialText: ""
}));
const addrController$ = external_tur_std_source(createTextEditingController({
    initialText: ""
}));
const usernameController$ = external_tur_std_source(createTextEditingController({
    initialText: ""
}));
// Never replaced — a blank password means "keep the stored one".
const passwordController$ = external_tur_std_source(createTextEditingController({
    initialText: ""
}));
const hydrate$ = mutate((ctx)=>{
    const storageId = ctx.get(context.storageId$);
    const isEdit = storageId !== null;
    let initialAlias = "";
    let initialAddr = "";
    let initialUsername = "";
    let initialAnon = false;
    if (isEdit) {
        const raw = db.singleGet(`storage:${storageId}`);
        if (raw != null) {
            try {
                const cfg = JSON.parse(raw);
                initialAlias = cfg.alias ?? "";
                initialAddr = cfg.addr ?? "";
                initialUsername = cfg.username ?? "";
                initialAnon = !!cfg.isAnonymous;
            } catch  {
            /* corrupt config — start blank */ }
        }
    }
    ctx.set(aliasController$, createTextEditingController({
        initialText: initialAlias
    }));
    ctx.set(addrController$, createTextEditingController({
        initialText: initialAddr
    }));
    ctx.set(usernameController$, createTextEditingController({
        initialText: initialUsername
    }));
    // The `anonymous` source declaration is seeded `false` at eval time;
    // write the hydrated value into the store (before mount, so the first
    // render sees it). Writes are equality-gated, so false→false is a no-op.
    ctx.set(anonymous, initialAnon);
});
const setStatus$ = mutate((ctx, text, isError)=>{
    ctx.set(statusText, text);
    ctx.set(statusIsError, isError);
});
// --- widgets ---------------------------------------------------------------
function FieldLabel({ text }) {
    return Text({
        text,
        fontSize: 13,
        color: COLOR_TEXT_MUTED
    });
}
function TextField(opts) {
    return Container({
        color: COLOR_CARD,
        borderColor: COLOR_DIVIDER,
        borderWidth: 1,
        borderRadius: 12,
        padding: 10,
        children: [
            Input({
                // The engine resolves a controller READABLE at build time
                // (`editable_text/element.rs` falls back to `controller_atom`
                // when no plain controller was given); the published typings
                // only declare the plain form — hence the cast.
                controller: opts.controller,
                placeholder: opts.placeholder,
                fontSize: 15,
                color: COLOR_TEXT,
                placeholderColor: COLOR_TEXT_MUTED,
                cursorColor: COLOR_PRIMARY,
                ...opts.obscure ? {
                    obscureText: true
                } : {}
            })
        ]
    });
}
/** Tappable "anonymous sign-in" toggle row (a bordered box fills when on).
 *  The box / label colors are reactive `Val`s so they repaint without a
 *  root-view rebuild. */ function AnonymousToggle() {
    return PointerInteract({
        behavior: HitTestBehavior.Opaque,
        onClick: mutate((ctx)=>{
            ctx.set(anonymous, !ctx.get(anonymous));
        }),
        child: Row({
            mainAlignment: MainAxisAlignment.Start,
            crossAlignment: CrossAxisAlignment.Center,
            mainAxisSize: MainAxisSize.Min,
            children: [
                Container({
                    width: 18,
                    height: 18,
                    borderRadius: 5,
                    borderWidth: 1,
                    borderColor: checkBorder$,
                    color: checkFill$
                }),
                SizedBox({
                    width: 8
                }),
                Text({
                    text: "匿名登录",
                    fontSize: 14,
                    color: checkText$
                })
            ]
        })
    });
}
function ActionButton(opts) {
    return PointerInteract({
        behavior: HitTestBehavior.Opaque,
        onClick: opts.onClick$,
        child: Container(opts.primary ? {
            color: COLOR_PRIMARY,
            borderRadius: 24,
            padding: 14,
            children: [
                Text({
                    text: opts.label,
                    fontSize: 15,
                    color: COLOR_WHITE
                })
            ]
        } : {
            color: COLOR_CARD,
            borderColor: COLOR_PRIMARY,
            borderWidth: 1,
            borderRadius: 24,
            padding: 14,
            children: [
                Text({
                    text: opts.label,
                    fontSize: 15,
                    color: COLOR_PRIMARY
                })
            ]
        })
    });
}
const collectArgs$ = mutate((ctx)=>{
    const isAnon = ctx.get(anonymous);
    const isEdit = ctx.get(isEdit$);
    const storageId = ctx.get(context.storageId$);
    return {
        ...isEdit && storageId != null ? {
            storageId
        } : {},
        addr: (ctx.get(addrController$).text ?? "").trim(),
        alias: (ctx.get(aliasController$).text ?? "").trim(),
        username: isAnon ? "" : (ctx.get(usernameController$).text ?? "").trim(),
        password: isAnon ? "" : ctx.get(passwordController$).text ?? "",
        isAnonymous: isAnon
    };
});
function validate(args, isEdit) {
    if (args.addr === "") return "服务器地址不能为空";
    if (args.alias === "") return "服务器名称 (别名) 不能为空";
    if (!args.isAnonymous && args.username === "") return "用户名不能为空";
    if (!args.isAnonymous && args.password === "" && !isEdit) return "密码不能为空";
    return null;
}
const runTest$ = mutate((ctx, _ev)=>{
    const args = ctx.set(collectArgs$);
    const invalid = validate(args, ctx.get(isEdit$));
    if (invalid != null) {
        ctx.set(setStatus$, invalid, true);
        return;
    }
    ctx.set(busy, true);
    ctx.set(setStatus$, "测试中...", false);
    // boa runs native async functions; since tur #212 async composition is
    // plain `await` (the `launch` generator driver is gone).
    void (async ()=>{
        try {
            const r = await rpc.call("webdav:test", args);
            if (r.result === "SUCCESS") {
                ctx.set(setStatus$, "测试成功", false);
            } else if (r.result === "UNAUTHORIZED") {
                ctx.set(setStatus$, "测试错误：认证错误", true);
            } else if (r.result === "TIMEOUT") {
                ctx.set(setStatus$, "测试错误：超时", true);
            } else {
                ctx.set(setStatus$, "测试错误：其他错误", true);
            }
        } catch (e) {
            ctx.set(setStatus$, `测试错误：${String(e?.message ?? e)}`, true);
        } finally{
            ctx.set(busy, false);
        }
    })();
});
const save$ = mutate((ctx, _ev)=>{
    const args = ctx.set(collectArgs$);
    const invalid = validate(args, ctx.get(isEdit$));
    if (invalid != null) {
        ctx.set(setStatus$, invalid, true);
        return;
    }
    ctx.set(busy, true);
    ctx.set(setStatus$, "", false);
    void (async ()=>{
        try {
            await rpc.call("webdav:connect", args);
            if (ctx.get(isEdit$)) {
                // The backend already rewrote the kv + notified the host;
                // show confirmation (create mode pops via the host upcall).
                ctx.set(setStatus$, "已保存", false);
            }
        } catch (e) {
            ctx.set(setStatus$, String(e?.message ?? e), true);
        } finally{
            ctx.set(busy, false);
        }
    })();
});
// --- root ------------------------------------------------------------------
// NOTE: `view(fn)` builds ONCE — the thunk is not reactive. All dynamic UI
// therefore goes through reactive props: `Val<T>` positions accept Readables
// (`Source` / `Derived`) and re-render when they change; `Condition` swaps
// its child. Reads inside `derive` closures go through the store ctx.
const anonChecked$ = derive((ctx)=>ctx.get(anonymous));
const showCreds$ = derive((ctx)=>!ctx.get(anonymous));
const statusVisible$ = derive((ctx)=>ctx.get(statusText) !== "");
const statusIsError$ = derive((ctx)=>ctx.get(statusIsError));
const checkFill$ = derive((ctx)=>ctx.get(anonymous) ? COLOR_PRIMARY : COLOR_CARD);
const checkBorder$ = derive((ctx)=>ctx.get(anonymous) ? COLOR_PRIMARY : COLOR_DIVIDER);
const checkText$ = derive((ctx)=>ctx.get(anonymous) ? COLOR_TEXT : COLOR_TEXT_MUTED);
const statusColor$ = derive((ctx)=>ctx.get(statusIsError) ? COLOR_ERROR : COLOR_TEXT_MUTED);
const rootView = view(()=>{
    // NOTE: `@tur-ng/std`'s d.ts references `Derived` without importing it, so
    // `viewportSize$` degrades to `any`/`unknown` at the call site; cast to the
    // documented `{ width, height }` shape. The reads are `derive` closures so
    // the page tracks viewport changes (the thunk itself runs once at mount).
    const vp$ = viewportSize$;
    return Container({
        color: COLOR_CARD,
        width: derive((ctx)=>ctx.get(vp$).width),
        height: derive((ctx)=>ctx.get(vp$).height),
        padding: 4,
        children: [
            Column({
                crossAlignment: CrossAxisAlignment.Stretch,
                mainAxisSize: MainAxisSize.Min,
                children: [
                    FieldLabel({
                        text: "服务器名称 (别名)"
                    }),
                    SizedBox({
                        height: 6
                    }),
                    TextField({
                        controller: aliasController$,
                        placeholder: "WebDAV"
                    }),
                    SizedBox({
                        height: 16
                    }),
                    FieldLabel({
                        text: "服务器地址"
                    }),
                    SizedBox({
                        height: 6
                    }),
                    TextField({
                        controller: addrController$,
                        placeholder: "https://example.com/dav"
                    }),
                    SizedBox({
                        height: 16
                    }),
                    AnonymousToggle(),
                    SizedBox({
                        height: 16
                    }),
                    Condition({
                        condition: showCreds$,
                        child: ()=>Column({
                                crossAlignment: CrossAxisAlignment.Stretch,
                                mainAxisSize: MainAxisSize.Min,
                                children: [
                                    FieldLabel({
                                        text: "用户名"
                                    }),
                                    SizedBox({
                                        height: 6
                                    }),
                                    TextField({
                                        controller: usernameController$,
                                        placeholder: ""
                                    }),
                                    SizedBox({
                                        height: 16
                                    }),
                                    FieldLabel({
                                        text: "密码"
                                    }),
                                    SizedBox({
                                        height: 6
                                    }),
                                    TextField({
                                        controller: passwordController$,
                                        placeholder: derive((ctx)=>ctx.get(isEdit$) ? "留空保持不变" : ""),
                                        obscure: true
                                    }),
                                    SizedBox({
                                        height: 16
                                    })
                                ]
                            })
                    }),
                    Row({
                        mainAlignment: MainAxisAlignment.Start,
                        crossAlignment: CrossAxisAlignment.Center,
                        mainAxisSize: MainAxisSize.Min,
                        children: [
                            ActionButton({
                                label: "测试",
                                primary: false,
                                onClick$: runTest$
                            }),
                            SizedBox({
                                width: 12
                            }),
                            ActionButton({
                                label: derive((ctx)=>ctx.get(isEdit$) ? "保存" : "连接"),
                                primary: true,
                                onClick$: save$
                            })
                        ]
                    }),
                    SizedBox({
                        height: 10
                    }),
                    Condition({
                        condition: statusVisible$,
                        child: ()=>Text({
                                text: statusText,
                                fontSize: 13,
                                color: statusColor$
                            })
                    })
                ]
            })
        ]
    });
});
// Module lifecycle contract: mount inside `start({ store })` (the engine
// runs the returned cleanup before the next load / at destroy; it hands us
// the instance-owned store — one per instance since tur #207, no
// `createStore`). Hydration is dispatched BEFORE mount: `Input` resolves
// its controller source at build time, so the prefilled controllers are
// what get attached. The root-tree lifecycle is engine-owned — `mount`
// replaces any existing root and module teardown clears it — so no cleanup
// is returned.
function view_start({ store }) {
    store.set(hydrate$);
    mount(rootView);
}

var __webpack_exports__start = __webpack_exports__.n;
export { __webpack_exports__start as start };

//# sourceMappingURL=view.js.map