import { Color, Column, Condition, Container, CrossAxisAlignment, HitTestBehavior, Input, MainAxisAlignment, MainAxisSize, PointerInteract, Row, SizedBox, Text, createTextEditingController, decodeUtf8, derive, encodeUtf8, mount, mutate, source as external_tur_std_source, view, viewportSize$ } from "tur:std";
import { context, db as external_ease_db, oauth, themes } from "ease";
// The require scope
var __webpack_require__ = {};

// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ view_start)
});

;// CONCATENATED MODULE: ../infra/string-polyfill.ts
// ECMAScript Annex-B / legacy builtin polyfill for the tur (boa) runtime.
//
// boa skips deprecated Annex-B extras that real-world npm packages still
// call. Import this module FIRST from every bundle entry (side-effect
// import), before any dependency that might rely on these.
//
// Found the hard way: fast-xml-parser's `readTagExp` calls
// `String.prototype.substr` on every namespace-prefixed tag — with
// `removeNSPrefix: true` that is EVERY tag of a WebDAV multistatus body —
// and the resulting TypeError (swallowed by a `catch { return [] }` at the
// time) turned every WebDAV `storage:list` into a silent empty directory
// on device. Pinned by the `ease-tur-rpc` regression test
// `fxp_parses_real_multistatus_in_boa`.
// --- String.prototype.substr (Annex B; absent in boa) ----------------------
//
// Spec semantics: NaN start → 0; negative start counts from the end;
// start >= length → ""; omitted length → to the end; NaN / negative / zero
// length → "". Installed via defineProperty so the lib's (deprecated) TS
// declaration is untouched.
if (typeof String.prototype.substr !== "function") {
    Object.defineProperty(String.prototype, "substr", {
        value: function substr(start, length) {
            const s = String(this);
            const size = s.length;
            let begin = Number(start);
            if (Number.isNaN(begin)) begin = 0;
            if (begin < 0) begin = Math.max(size + begin, 0);
            if (begin >= size) return "";
            let end = size;
            if (length !== undefined) {
                const len = Number(length);
                if (Number.isNaN(len) || len <= 0) return "";
                end = Math.min(begin + len, size);
            }
            return s.substring(begin, end);
        },
        writable: true,
        configurable: true,
        enumerable: false
    });
}


;// CONCATENATED MODULE: external "tur:std"

;// CONCATENATED MODULE: ../infra/text-polyfill.ts
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// TextEncoder / TextDecoder polyfill for the tur (boa) runtime.
//
// boa implements ECMAScript but not the Web Platform text codecs. `tur:std`
// already ships the UTF-8 primitives (`encodeUtf8` / `decodeUtf8`), so these
// classes are thin WHATWG-shaped wrappers over them instead of another
// hand-rolled encoder. Import this module FIRST from every bundle entry
// (side-effect import) — npm dependencies bundled after it see the globals.
//
// Semantics notes:
// - `encode`: WHATWG replaces lone surrogates with U+FFFD; boa's
//   `encodeUtf8` renders them as literal `\uD800` text, so the input is
//   normalized with `String.prototype.toWellFormed()` (ES2024, implemented
//   by boa) first.
// - `encodeInto`: never splits a code point's multi-byte sequence — the cut
//   is walked back to a UTF-8 lead-byte boundary.
// - `decode`: `decodeUtf8` is strict (throws on invalid bytes), which maps
//   1:1 to the `fatal: true` option; the default non-fatal mode replaces
//   each invalid byte with U+FFFD by greedily re-decoding the longest valid
//   prefix (binary search).
// - `decode(bytes, { stream: true })` decodes each chunk independently (no
//   cross-call decoder state) — the same trade-off the common
//   `fast-text-encoding` polyfill makes.
// - UTF-8 labels only; any other label throws `RangeError`.

const UTF8_LABELS = [
    "utf-8",
    "utf8",
    "unicode-1-1-utf-8",
    "unicode11utf8",
    "unicode20utf8",
    "x-unicode20utf8"
];
/** View of a BufferSource as bytes, honoring byteOffset / byteLength. */ function toBytes(input) {
    if (input instanceof ArrayBuffer) return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
}
/** `String.prototype.toWellFormed()` (ES2024) — implemented by boa, but not
 *  declared in the ES2020 lib the plugins typecheck against, hence the
 *  local cast instead of a program-wide lib bump. */ function wellFormed(s) {
    return s.toWellFormed();
}
/** Non-fatal decode: U+FFFD per invalid byte, via longest-valid-prefix
 *  binary search over `decodeUtf8` (which is strict). */ function decodeLossy(bytes) {
    try {
        return decodeUtf8(bytes);
    } catch  {
        let out = "";
        let start = 0;
        while(start < bytes.length){
            let lo = 0;
            let hi = bytes.length - start;
            while(lo < hi){
                const mid = lo + hi + 1 >> 1;
                let ok = true;
                try {
                    decodeUtf8(bytes.subarray(start, start + mid));
                } catch  {
                    ok = false;
                }
                if (ok) lo = mid;
                else hi = mid - 1;
            }
            if (lo > 0) {
                out += decodeUtf8(bytes.subarray(start, start + lo));
                start += lo;
            } else {
                out += "\uFFFD";
                start += 1;
            }
        }
        return out;
    }
}
if (typeof globalThis.TextEncoder === "undefined") {
    class TextEncoder {
        get encoding() {
            return "utf-8";
        }
        encode(input) {
            const s = input == null ? "" : String(input);
            return encodeUtf8(wellFormed(s));
        }
        encodeInto(source, destination) {
            if (!(destination instanceof Uint8Array)) {
                throw new TypeError("encodeInto: destination must be a Uint8Array");
            }
            const bytes = encodeUtf8(wellFormed(String(source ?? "")));
            // Cut at a lead-byte boundary so no code point splits; a
            // continuation byte matches 10xxxxxx (0xC0 mask).
            let n = Math.min(bytes.length, destination.length);
            while(n > 0 && n < bytes.length && (bytes[n] & 0xc0) === 0x80)n--;
            destination.set(bytes.subarray(0, n));
            return {
                read: n === 0 ? 0 : decodeUtf8(bytes.subarray(0, n)).length,
                written: n
            };
        }
    }
    globalThis.TextEncoder = TextEncoder;
}
if (typeof globalThis.TextDecoder === "undefined") {
    class TextDecoder {
        get encoding() {
            return "utf-8";
        }
        decode(input, _options) {
            if (input == null) return "";
            let bytes = toBytes(input);
            if (!this.ignoreBOM && bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
                bytes = bytes.subarray(3);
            }
            return this.fatal ? decodeUtf8(bytes) : decodeLossy(bytes);
        }
        constructor(label, options){
            _define_property(this, "fatal", void 0);
            _define_property(this, "ignoreBOM", void 0);
            const norm = String(label ?? "utf-8").trim().toLowerCase();
            if (!UTF8_LABELS.includes(norm)) {
                throw new RangeError(`TextDecoder: unsupported encoding label '${label}' (UTF-8 only)`);
            }
            this.fatal = !!options?.fatal;
            this.ignoreBOM = !!options?.ignoreBOM;
        }
    }
    globalThis.TextDecoder = TextDecoder;
}

;// CONCATENATED MODULE: external "ease"

;// CONCATENATED MODULE: ./src/oauth-pending.ts
// OAuth pending-slot helpers — shared by view.ts (writes the slot before
// `ease.oauth.start`) and backend.ts (consumes it in the `oauth:exchange`
// handler). The host never sees any of this: business data keyed by the
// host-minted flow id lives entirely in the plugin's KV.
/** KV key for one in-flight OAuth flow's pending data. */ function pendingKey(oauthId) {
    return `oauth:${oauthId}`;
}
/** Read (without consuming) a flow's pending slot, or null if absent. */ function readPending(db, oauthId) {
    const raw = db.singleGet(pendingKey(oauthId));
    if (raw == null) return null;
    try {
        return JSON.parse(raw);
    } catch  {
        return null;
    }
}
/** Consume a flow's pending slot: read + delete. Returns null if absent. */ function takePending(db, oauthId) {
    const pending = readPending(db, oauthId);
    db.singleDelete(pendingKey(oauthId));
    return pending;
}

;// CONCATENATED MODULE: ./src/view.ts
// OneDrive storage view — the tur-rendered form shown both in the add-storage
// page (create mode) and when editing an existing OneDrive storage (edit mode).
//
// Mode is derived from `ease.context.storageId$`: `null` = create (no storage
// row yet), a real `plugin_storage_id` = edit. The view branches once at
// module load (the value is static for the instance lifetime).
//
// - Create: an alias input + a "Connect your account" button. Tapping it
//   mints a flow id (`oauth.new()`), stashes the alias in the plugin's own
//   KV keyed by it (`oauth:<id>`), and fires `oauth.start(oauthId)` (a
//   fire-and-forget Rust→Kotlin upcall); the host fetches the authorize URL
//   from the backend, stashes `(pluginId, oauthId)`, and opens the system
//   browser. The `easem://oauth2redirect` callback in `MainActivity`
//   completes the exchange — the backend's `oauth:exchange` handler consumes
//   the pending slot — and mints the storage row; there is no "save" step on
//   the host side, and the alias never crosses the host.
//
// - Edit: the alias input is prefilled from the plugin's `ease.db` config
//   (`storage:<instance>` = `{ alias, secretId }`); a Save button writes it
//   back via `db.singleSet` + `context.notifyChange()` (host reloads the
//   dashboard so the new alias shows). Removal is handled by the host's
//   top-bar trash icon (which routes to the backend's
//   `storage:removeInstance` — kv + secret wipe + host row delete), so no
//   in-view disconnect button.
//
// This module is bundled to `view.js` (see `rspack.config.cjs`) and loaded by
// the plugin-storage view host in `EditStorage.kt`. It runs in an isolated
// view instance, separate from the headless backend instance that owns the
// `storage:*` / `oauth:*` RPC handlers.
// TextEncoder/TextDecoder polyfill FIRST — npm deps may rely on them.





// Inherit the host app's Material 3 theme so the form matches the
// surrounding UI. `themes.color(name)` throws on unknown names — views load
// long after the host pushes its theme, so a miss is always a bug (typo /
// outdated plugin) and failing fast beats silently rendering a fallback.
const COLOR_PRIMARY = Color.hex(themes.color("primary"));
const COLOR_CARD = Color.hex(themes.color("surface"));
const COLOR_TEXT = Color.hex(themes.color("onSurface"));
const COLOR_TEXT_MUTED = Color.hex(themes.color("onSurfaceVariant"));
const COLOR_DIVIDER = Color.hex(themes.color("outlineVariant"));
const COLOR_WHITE = Color.hex("#FFFFFF");
// --- mode + prefilled config ---------------------------------------------
//
// No module-level mutable state: everything reactive is a declaration
// (`source` / `derive`), materialized into the instance store that
// `start({ store })` receives. The `hydrate$` mutation (dispatched from
// `start` BEFORE mount) writes the prefilled alias controller + secret id
// into the sources; `Input` resolves a controller source at build time, so
// the hydrated instance is what gets attached — the seed below is a
// placeholder that never reaches an Input.
const isEdit$ = derive((ctx)=>ctx.get(context.storageId$) !== null);
const aliasController$ = external_tur_std_source(createTextEditingController({
    initialText: ""
}));
const existingSecretId$ = external_tur_std_source(null);
const hydrate$ = mutate((ctx)=>{
    const storageId = ctx.get(context.storageId$);
    const isEdit = storageId !== null;
    // In edit mode, hydrate the alias + secretId from the plugin's kv config
    // so the field is prefilled and Save preserves the existing secret
    // reference.
    let initialAlias = "";
    let secretId = null;
    if (isEdit) {
        const raw = external_ease_db.singleGet(`storage:${storageId}`);
        if (raw != null) {
            try {
                const cfg = JSON.parse(raw);
                initialAlias = cfg.alias ?? "";
                secretId = cfg.secretId ?? null;
            } catch  {
            /* corrupt config — start blank */ }
        }
    }
    ctx.set(aliasController$, createTextEditingController({
        initialText: initialAlias
    }));
    ctx.set(existingSecretId$, secretId);
});
function FieldLabel({ text }) {
    return Text({
        text,
        fontSize: 13,
        color: COLOR_TEXT_MUTED
    });
}
function AliasField() {
    return Container({
        color: COLOR_CARD,
        borderColor: COLOR_DIVIDER,
        borderWidth: 1,
        borderRadius: 12,
        padding: 10,
        children: [
            Input({
                // The engine resolves a controller READABLE at build time
                // (`editable_text/element.rs` falls back to `controller_atom`
                // when no plain controller was given); the published typings
                // only declare the plain form — hence the cast.
                controller: aliasController$,
                placeholder: "OneDrive",
                fontSize: 15,
                color: COLOR_TEXT,
                placeholderColor: COLOR_TEXT_MUTED,
                cursorColor: COLOR_PRIMARY
            })
        ]
    });
}
const connect$ = mutate((ctx, _ev)=>{
    // Business data (the alias) stays plugin-owned: stash it in our
    // KV keyed by a freshly minted flow id, then fire the flow. The
    // `oauth:exchange` handler in backend.ts consumes the slot.
    const alias = ctx.get(aliasController$).text ?? "";
    const oauthId = oauth["new"]();
    external_ease_db.singleSet(pendingKey(oauthId), JSON.stringify({
        alias: alias.length > 0 ? alias : null
    }));
    oauth.start(oauthId);
});
function ConnectButton() {
    return PointerInteract({
        behavior: HitTestBehavior.Opaque,
        onClick: connect$,
        child: Container({
            color: COLOR_PRIMARY,
            borderRadius: 24,
            padding: 14,
            children: [
                Text({
                    text: "连接你的账户",
                    fontSize: 15,
                    color: COLOR_WHITE
                })
            ]
        })
    });
}
const save$ = mutate((ctx, _ev)=>{
    const storageId = ctx.get(context.storageId$);
    if (storageId === null) return;
    const alias = ctx.get(aliasController$).text ?? "";
    // Preserve the existing secretId; only the alias is editable here.
    external_ease_db.singleSet(`storage:${storageId}`, JSON.stringify({
        alias,
        secretId: ctx.get(existingSecretId$)
    }));
    // Reload the host list so the dashboard picks up the new alias.
    context.notifyChange();
});
function SaveButton() {
    return PointerInteract({
        behavior: HitTestBehavior.Opaque,
        onClick: save$,
        child: Container({
            color: COLOR_PRIMARY,
            borderRadius: 24,
            padding: 14,
            children: [
                Text({
                    text: "保存",
                    fontSize: 15,
                    color: COLOR_WHITE
                })
            ]
        })
    });
}
const rootView = view(()=>{
    // NOTE: `@tur-ng/std`'s d.ts references `Derived` without importing it, so
    // `viewportSize$` degrades to `any`/`unknown` at the call site; cast to the
    // documented `{ width, height }` shape. The reads are `derive` closures so
    // the page tracks viewport changes (the thunk itself runs once at mount).
    const vp$ = viewportSize$;
    const actionRow = Row({
        mainAlignment: MainAxisAlignment.Start,
        crossAlignment: CrossAxisAlignment.Center,
        mainAxisSize: MainAxisSize.Min,
        children: [
            Condition({
                condition: isEdit$,
                child: ()=>SaveButton(),
                elseChild: ()=>ConnectButton()
            })
        ]
    });
    return Container({
        color: COLOR_CARD,
        width: derive((ctx)=>ctx.get(vp$).width),
        height: derive((ctx)=>ctx.get(vp$).height),
        padding: 4,
        children: [
            Column({
                crossAlignment: CrossAxisAlignment.Stretch,
                mainAxisSize: MainAxisSize.Min,
                children: [
                    FieldLabel({
                        text: "服务器名称 (别名)"
                    }),
                    SizedBox({
                        height: 6
                    }),
                    AliasField(),
                    SizedBox({
                        height: 16
                    }),
                    actionRow
                ]
            })
        ]
    });
});
// Module lifecycle contract: mount inside `start({ store })` (the engine
// runs the returned cleanup before the next load / at destroy; it hands us
// the instance-owned store — one per instance since tur #207, no
// `createStore`). Hydration is dispatched BEFORE mount: `Input` resolves
// its controller source at build time, so the prefilled alias controller is
// what gets attached. The root-tree lifecycle is engine-owned — `mount`
// replaces any existing root and module teardown clears it — so no cleanup
// is returned.
function view_start({ store }) {
    store.set(hydrate$);
    mount(rootView);
}

var __webpack_exports__start = __webpack_exports__.n;
export { __webpack_exports__start as start };

//# sourceMappingURL=view.js.map