import { decodeUtf8, encodeUtf8 } from "tur:std";
import { request, requestStream } from "tur:net";
import { hostRpc } from "tur:rpc";
import { context, db as external_ease_db, secret } from "ease";
// The require scope
var __webpack_require__ = {};

// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ backend_start)
});

;// CONCATENATED MODULE: ../infra/string-polyfill.ts
// ECMAScript Annex-B / legacy builtin polyfill for the tur (boa) runtime.
//
// boa skips deprecated Annex-B extras that real-world npm packages still
// call. Import this module FIRST from every bundle entry (side-effect
// import), before any dependency that might rely on these.
//
// Found the hard way: fast-xml-parser's `readTagExp` calls
// `String.prototype.substr` on every namespace-prefixed tag — with
// `removeNSPrefix: true` that is EVERY tag of a WebDAV multistatus body —
// and the resulting TypeError (swallowed by a `catch { return [] }` at the
// time) turned every WebDAV `storage:list` into a silent empty directory
// on device.
// --- String.prototype.substr (Annex B; absent in boa) ----------------------
//
// Spec semantics: NaN start → 0; negative start counts from the end;
// start >= length → ""; omitted length → to the end; NaN / negative / zero
// length → "". Installed via defineProperty so the lib's (deprecated) TS
// declaration is untouched.
if (typeof String.prototype.substr !== "function") {
    Object.defineProperty(String.prototype, "substr", {
        value: function substr(start, length) {
            const s = String(this);
            const size = s.length;
            let begin = Number(start);
            if (Number.isNaN(begin)) begin = 0;
            if (begin < 0) begin = Math.max(size + begin, 0);
            if (begin >= size) return "";
            let end = size;
            if (length !== undefined) {
                const len = Number(length);
                if (Number.isNaN(len) || len <= 0) return "";
                end = Math.min(begin + len, size);
            }
            return s.substring(begin, end);
        },
        writable: true,
        configurable: true,
        enumerable: false
    });
}


;// CONCATENATED MODULE: external "tur:std"

;// CONCATENATED MODULE: ../infra/text-polyfill.ts
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// TextEncoder / TextDecoder polyfill for the tur (boa) runtime.
//
// boa implements ECMAScript but not the Web Platform text codecs. `tur:std`
// already ships the UTF-8 primitives (`encodeUtf8` / `decodeUtf8`), so these
// classes are thin WHATWG-shaped wrappers over them instead of another
// hand-rolled encoder. Import this module FIRST from every bundle entry
// (side-effect import) — npm dependencies bundled after it see the globals.
//
// Semantics notes:
// - `encode`: WHATWG replaces lone surrogates with U+FFFD; boa's
//   `encodeUtf8` renders them as literal `\uD800` text, so the input is
//   normalized with `String.prototype.toWellFormed()` (ES2024, implemented
//   by boa) first.
// - `encodeInto`: never splits a code point's multi-byte sequence — the cut
//   is walked back to a UTF-8 lead-byte boundary.
// - `decode`: `decodeUtf8` is strict (throws on invalid bytes), which maps
//   1:1 to the `fatal: true` option; the default non-fatal mode replaces
//   each invalid byte with U+FFFD by greedily re-decoding the longest valid
//   prefix (binary search).
// - `decode(bytes, { stream: true })` decodes each chunk independently (no
//   cross-call decoder state) — the same trade-off the common
//   `fast-text-encoding` polyfill makes.
// - UTF-8 labels only; any other label throws `RangeError`.

const UTF8_LABELS = [
    "utf-8",
    "utf8",
    "unicode-1-1-utf-8",
    "unicode11utf8",
    "unicode20utf8",
    "x-unicode20utf8"
];
/** View of a BufferSource as bytes, honoring byteOffset / byteLength. */ function toBytes(input) {
    if (input instanceof ArrayBuffer) return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
}
/** `String.prototype.toWellFormed()` (ES2024) — implemented by boa, but not
 *  declared in the ES2020 lib the plugins typecheck against, hence the
 *  local cast instead of a program-wide lib bump. */ function wellFormed(s) {
    return s.toWellFormed();
}
/** Non-fatal decode: U+FFFD per invalid byte, via longest-valid-prefix
 *  binary search over `decodeUtf8` (which is strict). */ function decodeLossy(bytes) {
    try {
        return decodeUtf8(bytes);
    } catch  {
        let out = "";
        let start = 0;
        while(start < bytes.length){
            let lo = 0;
            let hi = bytes.length - start;
            while(lo < hi){
                const mid = lo + hi + 1 >> 1;
                let ok = true;
                try {
                    decodeUtf8(bytes.subarray(start, start + mid));
                } catch  {
                    ok = false;
                }
                if (ok) lo = mid;
                else hi = mid - 1;
            }
            if (lo > 0) {
                out += decodeUtf8(bytes.subarray(start, start + lo));
                start += lo;
            } else {
                out += "\uFFFD";
                start += 1;
            }
        }
        return out;
    }
}
if (typeof globalThis.TextEncoder === "undefined") {
    class TextEncoder {
        get encoding() {
            return "utf-8";
        }
        encode(input) {
            const s = input == null ? "" : String(input);
            return encodeUtf8(wellFormed(s));
        }
        encodeInto(source, destination) {
            if (!(destination instanceof Uint8Array)) {
                throw new TypeError("encodeInto: destination must be a Uint8Array");
            }
            const bytes = encodeUtf8(wellFormed(String(source ?? "")));
            // Cut at a lead-byte boundary so no code point splits; a
            // continuation byte matches 10xxxxxx (0xC0 mask).
            let n = Math.min(bytes.length, destination.length);
            while(n > 0 && n < bytes.length && (bytes[n] & 0xc0) === 0x80)n--;
            destination.set(bytes.subarray(0, n));
            return {
                read: n === 0 ? 0 : decodeUtf8(bytes.subarray(0, n)).length,
                written: n
            };
        }
    }
    globalThis.TextEncoder = TextEncoder;
}
if (typeof globalThis.TextDecoder === "undefined") {
    class TextDecoder {
        get encoding() {
            return "utf-8";
        }
        decode(input, _options) {
            if (input == null) return "";
            let bytes = toBytes(input);
            if (!this.ignoreBOM && bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
                bytes = bytes.subarray(3);
            }
            return this.fatal ? decodeUtf8(bytes) : decodeLossy(bytes);
        }
        constructor(label, options){
            _define_property(this, "fatal", void 0);
            _define_property(this, "ignoreBOM", void 0);
            const norm = String(label ?? "utf-8").trim().toLowerCase();
            if (!UTF8_LABELS.includes(norm)) {
                throw new RangeError(`TextDecoder: unsupported encoding label '${label}' (UTF-8 only)`);
            }
            this.fatal = !!options?.fatal;
            this.ignoreBOM = !!options?.ignoreBOM;
        }
    }
    globalThis.TextDecoder = TextDecoder;
}

;// CONCATENATED MODULE: external "tur:net"

;// CONCATENATED MODULE: external "tur:rpc"

;// CONCATENATED MODULE: ../infra/host-ops.ts
// Host contract op sigs — the typed catalog of ops the Rust host invokes on
// plugin backends (`hostRpc.registerHandler` / `hostRpc.registerStream`).
// Each sig binds the wire op string to its args and result shapes, so
// providers register without hand-declaring arg types; extract a shape
// elsewhere via `EaseRpcOpArg<typeof StorageListSig>` /
// `EaseRpcOpResult<typeof StorageListSig>`.
//
// SOURCE OF TRUTH: the shapes mirror the Rust call sites —
// - storage contract: `rust-libs/ease-js-storage/src/lib.rs` (args, entry
//   decode, stream meta decode),
// - OAuth flow: `rust-libs/ease-client-backend/src/bridge/dispatch.rs`
//   (`oauth.url` / `oauth.exchange` arms),
// - lyric parsing: `rust-libs/ease-client-backend/src/services/lyrics/mod.rs`
// — update both sides together. Ops are contract literals, identical names
// for every provider; identity (`pluginId`, `storageId`, `oauthId`) rides
// the payload, typed `string` (the host routes it — a provider-side literal
// guard would only restate the manifest id).
//
// This module is plain bundled TS (imported relatively by plugins, like the
// polyfills): the runtime value of a sig is just `{ op }`, so no host
// provisioning is involved.
// ---------------------------------------------------------------------------
// Host op sigs
// ---------------------------------------------------------------------------
/** `storage:list` — directory listing. */ const StorageListSig = {
    op: "storage:list"
};
/** `storage:get` — streaming byte-range download; the Result slot is the
 *  stream meta shape (see `registerStream`). */ const StorageGetSig = {
    op: "storage:get"
};
/** `storage:removeInstance` — drop this instance's config + secrets; the
 *  host ignores the reply. */ const StorageRemoveInstanceSig = {
    op: "storage:removeInstance"
};
/** `oauth:url` — the authorize URL for the host to open in the browser. */ const OauthUrlSig = {
    op: "oauth:url"
};
/** `oauth:exchange` — redeem the browser callback's code; the host reads the
 *  minted `storageId` back to (re)bind the storage row. */ const OauthExchangeSig = {
    op: "oauth:exchange"
};
/** `lyric:parse` — parse candidate lyric bytes; `null` means "not mine /
 *  unrecognized content" and the host falls through to the next parser. */ const LyricParseSig = (/* unused pure expression or super */ null && ({
    op: "lyric:parse"
}));

;// CONCATENATED MODULE: external "ease"

;// CONCATENATED MODULE: ./src/oauth-pending.ts
// OAuth pending-slot helpers — shared by view.ts (writes the slot before
// `ease.oauth.start`) and backend.ts (consumes it in the `oauth:exchange`
// handler). The host never sees any of this: business data keyed by the
// host-minted flow id lives entirely in the plugin's KV.
/** KV key for one in-flight OAuth flow's pending data. */ function pendingKey(oauthId) {
    return `oauth:${oauthId}`;
}
/** Read (without consuming) a flow's pending slot, or null if absent. */ function readPending(db, oauthId) {
    const raw = db.singleGet(pendingKey(oauthId));
    if (raw == null) return null;
    try {
        return JSON.parse(raw);
    } catch  {
        return null;
    }
}
/** Consume a flow's pending slot: read + delete. Returns null if absent. */ function takePending(db, oauthId) {
    const pending = readPending(db, oauthId);
    db.singleDelete(pendingKey(oauthId));
    return pending;
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/uuid@14.0.2/node_modules/uuid/dist/rng.js
const rnds8 = new Uint8Array(16);
function rng() {
    return crypto.getRandomValues(rnds8);
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/uuid@14.0.2/node_modules/uuid/dist/stringify.js

const byteToHex = [];
for (let i = 0; i < 256; ++i) {
    byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] +
        byteToHex[arr[offset + 1]] +
        byteToHex[arr[offset + 2]] +
        byteToHex[arr[offset + 3]] +
        '-' +
        byteToHex[arr[offset + 4]] +
        byteToHex[arr[offset + 5]] +
        '-' +
        byteToHex[arr[offset + 6]] +
        byteToHex[arr[offset + 7]] +
        '-' +
        byteToHex[arr[offset + 8]] +
        byteToHex[arr[offset + 9]] +
        '-' +
        byteToHex[arr[offset + 10]] +
        byteToHex[arr[offset + 11]] +
        byteToHex[arr[offset + 12]] +
        byteToHex[arr[offset + 13]] +
        byteToHex[arr[offset + 14]] +
        byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset);
    if (!validate(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
/* export default */ const dist_stringify = ((/* unused pure expression or super */ null && (stringify)));

;// CONCATENATED MODULE: ./node_modules/.pnpm/uuid@14.0.2/node_modules/uuid/dist/v4.js


function v4(options, buf, offset) {
    if (!buf && !options && crypto.randomUUID) {
        return crypto.randomUUID();
    }
    return _v4(options, buf, offset);
}
function _v4(options, buf, offset) {
    options = options || {};
    const rnds = options.random ?? options.rng?.() ?? rng();
    if (rnds.length < 16) {
        throw new Error('Random bytes length must be >= 16');
    }
    rnds[6] = (rnds[6] & 0x0f) | 0x40;
    rnds[8] = (rnds[8] & 0x3f) | 0x80;
    if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
            throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for (let i = 0; i < 16; ++i) {
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return unsafeStringify(rnds);
}
/* export default */ const dist_v4 = (v4);

;// CONCATENATED MODULE: ./src/backend.ts
function backend_define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// OneDrive storage provider — a headless JS plugin that serves `list` and
// `get` (streaming byte-range download) over the `tur:rpc` channel, plus
// OAuth add/remove instance ops. The host `JsStorageBackend` treats OneDrive
// like any other `StorageBackend`.
//
// Multi-instance: each configured OneDrive account is one *instance* named
// `onedrive:<uuid>` (the storage row's `plugin_storage_id`). Per-instance
// config lives in `ease.db` (this plugin's KV) under
// `storage:<instance>` = JSON `{ alias, secretId }`; the refresh token lives
// in `ease.secret` under that `secretId` (scope `plugin:com.ease.onedrive`).
// Access tokens are cached in module state; on a 401 the refresh token is
// rotated and persisted back to the secret store.
//
// Identity: this headless instance is created by `KeepBackendService` which
// stamps `PluginId("com.ease.onedrive")` into the per-instance data slot.
// `ease.*` bridge fns resolve the calling plugin from that slot — no
// pluginId argument is needed (or accepted) on any call here.
//
// Handlers — contract literals under hostRpc scope: identical op names for
// every storage provider, identity riding the payload (`pluginId` = this
// manifest's id; `storageId` = the `plugin_storage_id` instance) — typed by
// the shared sigs in `../../infra/host-ops.ts`. The OAuth flow is host-bridged
// (the view fires `ease.oauth.start`, the host comes
// back through the `oauth.url` / `oauth.exchange` bridges):
//   - storage:list           { pluginId, storageId, dir }          -> Entry[]
//   - storage:get            { pluginId, storageId, path, offset } -> registerStream: meta
//     { totalLength?, name?, contentType? } + credit-gated body
//   - oauth:url              { pluginId, oauthId }                 -> { url }
//   - oauth:exchange         { pluginId, oauthId, code }           -> { storageId }
//   - storage:removeInstance { pluginId, storageId }               -> {}
// The connect-form alias never crosses the host: the view stashes it in
// this plugin's KV under `oauth:<oauthId>` (see `oauth-pending.ts`) and the
// `oauth:exchange` handler consumes it.
//
// Ported from the Rust implementation at
// `rust-libs/ease-remote-storage/src/impls/onedrive.rs`.
// TextEncoder/TextDecoder polyfill FIRST — npm deps below may rely on them.









// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const ONEDRIVE_ROOT_API = "https://graph.microsoft.com/v1.0/me/drive";
const ONEDRIVE_API_BASE = "https://login.microsoftonline.com/common/oauth2/v2.0";
const ONEDRIVE_REDIRECT_URI = "easem://oauth2redirect/";
const CLIENT_ID = "5db0dade-b21c-4161-bd4f-027e0f3e4700";
const SCOPES = "Files.Read offline_access";
/** instance ("onedrive:<uuid>") -> state. Lazily loaded on first use. */ const instances = new Map();
class HttpError extends Error {
    constructor(status, message){
        super(message), backend_define_property(this, "status", void 0), this.status = status;
    }
}
function kvKey(instance) {
    return `storage:${instance}`;
}
function configOf(instance) {
    const st = instances.get(instance);
    if (st) return st;
    const raw = external_ease_db.singleGet(kvKey(instance));
    if (raw == null) {
        throw new Error(`onedrive: no config for instance ${instance}`);
    }
    const cfg = JSON.parse(raw);
    const state = {
        alias: cfg.alias ?? instance,
        secretId: cfg.secretId,
        accessToken: null
    };
    instances.set(instance, state);
    return state;
}
/** Read this instance's current refresh token from the secret store. */ function loadRefreshToken(secretId) {
    const v = secret.get(secretId);
    if (v == null) {
        throw new Error(`onedrive: refresh token missing for secretId ${secretId}`);
    }
    return v;
}
/** Persist a (possibly rotated) refresh token to the secret store. */ function saveRefreshToken(secretId, token) {
    secret.remove(secretId);
    // re-put to replace — secret ids are immutable per row; we reuse the id by
    // deleting + re-inserting. (The secret store has no in-place update.)
    const newId = secret.put(token);
    if (newId !== secretId) {
        // The id shifted — update the config so future loads resolve it. This
        // is rare (only if the store hands out a different id after delete);
        // we patch both the kv and the in-memory state.
        instances.forEach((s)=>{
            if (s.secretId === secretId) s.secretId = newId;
        });
        patchConfigSecretId(secretId, newId);
    }
}
function patchConfigSecretId(oldId, newId) {
    // Find the instance whose config references oldId and rewrite it. We scan
    // the loaded instances (cheap; typically a handful).
    for (const [instance, st] of instances){
        if (st.secretId === newId) {
            external_ease_db.singleSet(kvKey(instance), JSON.stringify({
                alias: st.alias,
                secretId: newId
            }));
        }
    }
}
// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------
function authHeaders(token) {
    return {
        Authorization: `bearer ${token}`
    };
}
function isAuthError(e) {
    return e instanceof HttpError && e.status === 401;
}
function formEncode(fields) {
    return Object.entries(fields).map(([k, v])=>`${k}=${encodeURIComponent(v)}`).join("&");
}
async function redeemToken(grantType, extra) {
    const body = formEncode({
        client_id: CLIENT_ID,
        redirect_uri: ONEDRIVE_REDIRECT_URI,
        grant_type: grantType,
        ...extra
    });
    const resp = await request({
        url: `${ONEDRIVE_API_BASE}/token`,
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body
    }).promise;
    if (!resp.ok) {
        throw new HttpError(resp.status, `token ${grantType} failed: ${resp.status} ${resp.statusText}`);
    }
    const j = JSON.parse(decodeUtf8(resp.body));
    return {
        access_token: j.access_token,
        refresh_token: j.refresh_token
    };
}
async function refreshAccess(instance) {
    const st = configOf(instance);
    const rt = loadRefreshToken(st.secretId);
    const t = await redeemToken("refresh_token", {
        refresh_token: rt
    });
    st.accessToken = t.access_token;
    // Persist the rotated refresh token.
    saveRefreshToken(st.secretId, t.refresh_token);
    return t.access_token;
}
async function ensureToken(instance) {
    const st = configOf(instance);
    if (st.accessToken) return st.accessToken;
    return refreshAccess(instance);
}
/** Run `fn` with a fresh access token; on 401 rotate once and retry. */ async function withRetry(instance, fn) {
    const token = await ensureToken(instance);
    try {
        return await fn(token);
    } catch (e) {
        if (isAuthError(e)) {
            const fresh = await refreshAccess(instance);
            return await fn(fresh);
        }
        throw e;
    }
}
// ---------------------------------------------------------------------------
// list
// ---------------------------------------------------------------------------
function computeListUrl(dir) {
    const sub = dir === "/" ? "/root/children" : `/root:${dir}:/children`;
    return `${ONEDRIVE_ROOT_API}${sub}`;
}
async function listImpl(token, dir) {
    let url = computeListUrl(dir);
    const out = [];
    for(;;){
        const resp = await request({
            url,
            method: "GET",
            headers: authHeaders(token)
        }).promise;
        if (!resp.ok) {
            throw new HttpError(resp.status, `list: ${resp.status} ${resp.statusText}`);
        }
        const j = JSON.parse(decodeUtf8(resp.body));
        const value = j.value ?? [];
        for (const item of value){
            const name = item.name;
            const path = `${dir}/${name}`;
            if (item.file) {
                out.push({
                    name,
                    path,
                    size: item.size,
                    isDir: false
                });
            } else if (item.folder) {
                out.push({
                    name,
                    path,
                    isDir: true
                });
            }
        }
        if (typeof j["@odata.nextLink"] === "string") {
            url = j["@odata.nextLink"];
        } else {
            break;
        }
    }
    // dirs first, then by path — matches the Rust ordering.
    out.sort((a, b)=>{
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
        if (a.path < b.path) return -1;
        if (a.path > b.path) return 1;
        return 0;
    });
    return out;
}
// ---------------------------------------------------------------------------
// get (streaming byte-range download)
// ---------------------------------------------------------------------------
function parseTotalLength(headers) {
    // Prefer Content-Range's total (`bytes start-end/total`) — it gives the
    // full file size; Content-Length on a Range response is the partial length.
    const cr = headers["Content-Range"] ?? headers["content-range"];
    if (cr) {
        const m = /\/(\d+)\s*$/.exec(cr);
        if (m) return parseInt(m[1], 10);
    }
    const cl = headers["Content-Length"] ?? headers["content-length"];
    if (cl) return parseInt(cl, 10);
    return undefined;
}
/**
 * Streaming get opener: one ranged request per stream. The dispatcher pumps
 * `body` with host-granted credits; `release` cancels the Task on any pump
 * exit (host cancel included). OneDrive honors Range, so no `dataOffset`.
 */ async function openGet(token, path, offset) {
    const url = `${ONEDRIVE_ROOT_API}/root:${path}:/content`;
    const headers = authHeaders(token);
    headers["Range"] = `bytes=${offset}-`;
    const t = requestStream({
        url,
        method: "GET",
        headers
    });
    const resp = await t.promise;
    if (resp.status >= 400) {
        // Fail the RPC itself so the host's `get` returns Err and withRetry's
        // 401 rotation can kick in — the error rides the reply, not the
        // stream.
        t.cancel();
        throw new HttpError(resp.status, `get: ${resp.status} ${resp.statusText}`);
    }
    const totalLength = parseTotalLength(resp.headers);
    const contentType = resp.headers["Content-Type"] ?? resp.headers["content-type"];
    const name = path.split("/").pop() || path;
    return {
        meta: {
            totalLength,
            name,
            contentType
        },
        body: resp.body,
        release: ()=>t.cancel()
    };
}
// ---------------------------------------------------------------------------
// OAuth + instance lifecycle
// ---------------------------------------------------------------------------
function authorizeUrl() {
    const q = formEncode({
        client_id: CLIENT_ID,
        response_type: "code",
        redirect_uri: ONEDRIVE_REDIRECT_URI,
        response_mode: "query",
        scope: SCOPES
    });
    return `${ONEDRIVE_API_BASE}/authorize?${q}`;
}
/**
 * Exchange an authorization code for tokens, mint a new `onedrive:<uuid>`
 * storage instance, persist its config + refresh token, and return its id.
 * The user-facing alias comes from this flow's pending slot
 * (`oauth:<oauthId>`, stashed by the view before `ease.oauth.start`) —
 * never from the host.
 */ async function exchangeCode(args) {
    const t = await redeemToken("authorization_code", {
        code: args.code
    });
    const instance = `onedrive:${dist_v4()}`;
    const secretId = secret.put(t.refresh_token);
    const pending = takePending(external_ease_db, args.oauthId);
    const alias = pending?.alias && pending.alias.length > 0 ? pending.alias : "OneDrive";
    external_ease_db.singleSet(kvKey(instance), JSON.stringify({
        alias,
        secretId
    }));
    // Prime the in-memory state so the first list/get skips a config reload.
    instances.set(instance, {
        alias,
        secretId,
        accessToken: t.access_token
    });
    return {
        storageId: instance
    };
}
/** Remove an instance: drop its config (kv) + its refresh-token secret, ask
 *  the host to delete the storage row, and reload the dashboard. Called only
 *  from the host — the edit view's top-bar trash icon and the storages-page
 *  trash both route through `context.removeStorage` / the host's
 *  `storage_plugin.remove_instance` bridge, which invokes this op
 *  (`storage:removeInstance`, hostRpc scope) before deleting the row. */ function removeInstance(args) {
    const st = instances.get(args.storageId);
    let secretId = st?.secretId;
    if (secretId === undefined) {
        const raw = external_ease_db.singleGet(kvKey(args.storageId));
        if (raw != null) {
            try {
                secretId = JSON.parse(raw).secretId;
            } catch  {
            /* ignore — config corrupt; still delete the kv row */ }
        }
    }
    if (secretId !== undefined) {
        secret.remove(secretId);
    }
    external_ease_db.singleDelete(kvKey(args.storageId));
    instances.delete(args.storageId);
    // Complete the disconnect on the host side: drop the storage row, then
    // reload so the dashboard + edit page reflect the removal.
    context.removeStorage(args.storageId);
    context.notifyChange();
}
// ---------------------------------------------------------------------------
// Register handlers
// ---------------------------------------------------------------------------
// The module lifecycle contract: the engine calls `start()` after eval (and
// runs the returned cleanup before the next load / at destroy). Handlers are
// per-instance and die with the instance, so no cleanup is needed.
function backend_start() {
    hostRpc.registerHandler(StorageListSig, (args)=>withRetry(args.storageId, (token)=>listImpl(token, args.dir)));
    hostRpc.registerStream(StorageGetSig, (args)=>withRetry(args.storageId, (token)=>openGet(token, args.path, args.offset)));
    hostRpc.registerHandler(OauthUrlSig, ()=>({
            url: authorizeUrl()
        }));
    hostRpc.registerHandler(OauthExchangeSig, (args)=>exchangeCode(args));
    hostRpc.registerHandler(StorageRemoveInstanceSig, (args)=>{
        removeInstance(args);
    });
}

var __webpack_exports__start = __webpack_exports__.n;
export { __webpack_exports__start as start };

//# sourceMappingURL=backend.js.map