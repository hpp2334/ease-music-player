import { decodeUtf8, encodeUtf8 } from "tur:std";
import { hostRpc } from "tur:rpc";
// The require scope
var __webpack_require__ = {};

// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  n: () => (/* binding */ backend_start)
});

;// CONCATENATED MODULE: ../infra/string-polyfill.ts
// ECMAScript Annex-B / legacy builtin polyfill for the tur (boa) runtime.
//
// boa skips deprecated Annex-B extras that real-world npm packages still
// call. Import this module FIRST from every bundle entry (side-effect
// import), before any dependency that might rely on these.
//
// Found the hard way: fast-xml-parser's `readTagExp` calls
// `String.prototype.substr` on every namespace-prefixed tag — with
// `removeNSPrefix: true` that is EVERY tag of a WebDAV multistatus body —
// and the resulting TypeError (swallowed by a `catch { return [] }` at the
// time) turned every WebDAV `storage:list` into a silent empty directory
// on device.
// --- String.prototype.substr (Annex B; absent in boa) ----------------------
//
// Spec semantics: NaN start → 0; negative start counts from the end;
// start >= length → ""; omitted length → to the end; NaN / negative / zero
// length → "". Installed via defineProperty so the lib's (deprecated) TS
// declaration is untouched.
if (typeof String.prototype.substr !== "function") {
    Object.defineProperty(String.prototype, "substr", {
        value: function substr(start, length) {
            const s = String(this);
            const size = s.length;
            let begin = Number(start);
            if (Number.isNaN(begin)) begin = 0;
            if (begin < 0) begin = Math.max(size + begin, 0);
            if (begin >= size) return "";
            let end = size;
            if (length !== undefined) {
                const len = Number(length);
                if (Number.isNaN(len) || len <= 0) return "";
                end = Math.min(begin + len, size);
            }
            return s.substring(begin, end);
        },
        writable: true,
        configurable: true,
        enumerable: false
    });
}


;// CONCATENATED MODULE: external "tur:std"

;// CONCATENATED MODULE: ../infra/text-polyfill.ts
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
// TextEncoder / TextDecoder polyfill for the tur (boa) runtime.
//
// boa implements ECMAScript but not the Web Platform text codecs. `tur:std`
// already ships the UTF-8 primitives (`encodeUtf8` / `decodeUtf8`), so these
// classes are thin WHATWG-shaped wrappers over them instead of another
// hand-rolled encoder. Import this module FIRST from every bundle entry
// (side-effect import) — npm dependencies bundled after it see the globals.
//
// Semantics notes:
// - `encode`: WHATWG replaces lone surrogates with U+FFFD; boa's
//   `encodeUtf8` renders them as literal `\uD800` text, so the input is
//   normalized with `String.prototype.toWellFormed()` (ES2024, implemented
//   by boa) first.
// - `encodeInto`: never splits a code point's multi-byte sequence — the cut
//   is walked back to a UTF-8 lead-byte boundary.
// - `decode`: `decodeUtf8` is strict (throws on invalid bytes), which maps
//   1:1 to the `fatal: true` option; the default non-fatal mode replaces
//   each invalid byte with U+FFFD by greedily re-decoding the longest valid
//   prefix (binary search).
// - `decode(bytes, { stream: true })` decodes each chunk independently (no
//   cross-call decoder state) — the same trade-off the common
//   `fast-text-encoding` polyfill makes.
// - UTF-8 labels only; any other label throws `RangeError`.

const UTF8_LABELS = [
    "utf-8",
    "utf8",
    "unicode-1-1-utf-8",
    "unicode11utf8",
    "unicode20utf8",
    "x-unicode20utf8"
];
/** View of a BufferSource as bytes, honoring byteOffset / byteLength. */ function toBytes(input) {
    if (input instanceof ArrayBuffer) return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
}
/** `String.prototype.toWellFormed()` (ES2024) — implemented by boa, but not
 *  declared in the ES2020 lib the plugins typecheck against, hence the
 *  local cast instead of a program-wide lib bump. */ function wellFormed(s) {
    return s.toWellFormed();
}
/** Non-fatal decode: U+FFFD per invalid byte, via longest-valid-prefix
 *  binary search over `decodeUtf8` (which is strict). */ function decodeLossy(bytes) {
    try {
        return decodeUtf8(bytes);
    } catch  {
        let out = "";
        let start = 0;
        while(start < bytes.length){
            let lo = 0;
            let hi = bytes.length - start;
            while(lo < hi){
                const mid = lo + hi + 1 >> 1;
                let ok = true;
                try {
                    decodeUtf8(bytes.subarray(start, start + mid));
                } catch  {
                    ok = false;
                }
                if (ok) lo = mid;
                else hi = mid - 1;
            }
            if (lo > 0) {
                out += decodeUtf8(bytes.subarray(start, start + lo));
                start += lo;
            } else {
                out += "\uFFFD";
                start += 1;
            }
        }
        return out;
    }
}
if (typeof globalThis.TextEncoder === "undefined") {
    class TextEncoder {
        get encoding() {
            return "utf-8";
        }
        encode(input) {
            const s = input == null ? "" : String(input);
            return encodeUtf8(wellFormed(s));
        }
        encodeInto(source, destination) {
            if (!(destination instanceof Uint8Array)) {
                throw new TypeError("encodeInto: destination must be a Uint8Array");
            }
            const bytes = encodeUtf8(wellFormed(String(source ?? "")));
            // Cut at a lead-byte boundary so no code point splits; a
            // continuation byte matches 10xxxxxx (0xC0 mask).
            let n = Math.min(bytes.length, destination.length);
            while(n > 0 && n < bytes.length && (bytes[n] & 0xc0) === 0x80)n--;
            destination.set(bytes.subarray(0, n));
            return {
                read: n === 0 ? 0 : decodeUtf8(bytes.subarray(0, n)).length,
                written: n
            };
        }
    }
    globalThis.TextEncoder = TextEncoder;
}
if (typeof globalThis.TextDecoder === "undefined") {
    class TextDecoder {
        get encoding() {
            return "utf-8";
        }
        decode(input, _options) {
            if (input == null) return "";
            let bytes = toBytes(input);
            if (!this.ignoreBOM && bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
                bytes = bytes.subarray(3);
            }
            return this.fatal ? decodeUtf8(bytes) : decodeLossy(bytes);
        }
        constructor(label, options){
            _define_property(this, "fatal", void 0);
            _define_property(this, "ignoreBOM", void 0);
            const norm = String(label ?? "utf-8").trim().toLowerCase();
            if (!UTF8_LABELS.includes(norm)) {
                throw new RangeError(`TextDecoder: unsupported encoding label '${label}' (UTF-8 only)`);
            }
            this.fatal = !!options?.fatal;
            this.ignoreBOM = !!options?.ignoreBOM;
        }
    }
    globalThis.TextDecoder = TextDecoder;
}

;// CONCATENATED MODULE: external "tur:rpc"

;// CONCATENATED MODULE: ./node_modules/.pnpm/js-base64@3.9.3/node_modules/js-base64/base64.mjs
/**
 *  base64.ts
 *
 *  Licensed under the BSD 3-Clause License.
 *    http://opensource.org/licenses/BSD-3-Clause
 *
 *  References:
 *    http://en.wikipedia.org/wiki/Base64
 *
 * @author Dan Kogai (https://github.com/dankogai)
 */
const version = '3.9.3';
/**
 * @deprecated use lowercase `version`.
 */
const VERSION = version;
const _TD = typeof TextDecoder === 'function' ? new TextDecoder('utf-8', { ignoreBOM: true }) : undefined;
const _TE = typeof TextEncoder === 'function' ? new TextEncoder() : undefined;
const b64ch = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
const b64chs = Array.prototype.slice.call(b64ch);
const b64tab = ((a) => {
    let tab = {};
    a.forEach((c, i) => tab[c] = i);
    return tab;
})(b64chs);
const b64re = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/;
const _fromCC = String.fromCharCode.bind(String);
const _U8Afrom = typeof Uint8Array.from === 'function'
    ? Uint8Array.from.bind(Uint8Array)
    : (it) => new Uint8Array(Array.prototype.slice.call(it, 0));
const _mkUriSafe = (src) => src
    .replace(/=/g, '').replace(/[+\/]/g, (m0) => m0 == '+' ? '-' : '_');
const _tidyB64 = (s) => s.replace(/[^A-Za-z0-9\+\/]/g, '');
/**
 * polyfill version of `btoa`
 */
const btoaPolyfill = (bin) => {
    // console.log('polyfilled');
    let u32, c0, c1, c2, asc = '';
    const pad = bin.length % 3;
    for (let i = 0; i < bin.length;) {
        if ((c0 = bin.charCodeAt(i++)) > 255 ||
            (c1 = bin.charCodeAt(i++)) > 255 ||
            (c2 = bin.charCodeAt(i++)) > 255)
            throw new TypeError('invalid character found');
        u32 = (c0 << 16) | (c1 << 8) | c2;
        asc += b64chs[u32 >> 18 & 63]
            + b64chs[u32 >> 12 & 63]
            + b64chs[u32 >> 6 & 63]
            + b64chs[u32 & 63];
    }
    return pad ? asc.slice(0, pad - 3) + "===".substring(pad) : asc;
};
/**
 * does what `window.btoa` of web browsers do.
 * @param {String} bin binary string
 * @returns {string} Base64-encoded string
 */
const _btoa = typeof btoa === 'function' ? (bin) => btoa(bin)
    : btoaPolyfill;
const _fromUint8Array = typeof Uint8Array.prototype.toBase64 === 'function' ? (u8a) => u8a.toBase64()
    : (u8a) => {
        // cf. https://stackoverflow.com/questions/12710001/how-to-convert-uint8-array-to-base64-encoded-string/12713326#12713326
        const maxargs = 0x1000;
        let strs = [];
        for (let i = 0, l = u8a.length; i < l; i += maxargs) {
            strs.push(_fromCC.apply(null, u8a.subarray(i, i + maxargs)));
        }
        return _btoa(strs.join(''));
    };
/**
 * converts a Uint8Array to a Base64 string.
 * @param {boolean} [urlsafe] URL-and-filename-safe a la RFC4648 §5
 * @returns {string} Base64 string
 */
const fromUint8Array = (u8a, urlsafe = false) => urlsafe ? _mkUriSafe(_fromUint8Array(u8a)) : _fromUint8Array(u8a);
// This trick is found broken https://github.com/dankogai/js-base64/issues/130
// const utob = (src: string) => unescape(encodeURIComponent(src));
// reverting good old fationed regexp
const cb_utob = (c) => {
    if (c.length < 2) {
        var cc = c.charCodeAt(0);
        return cc < 0x80 ? c
            : cc < 0x800 ? (_fromCC(0xc0 | (cc >>> 6))
                + _fromCC(0x80 | (cc & 0x3f)))
                : (_fromCC(0xe0 | ((cc >>> 12) & 0x0f))
                    + _fromCC(0x80 | ((cc >>> 6) & 0x3f))
                    + _fromCC(0x80 | (cc & 0x3f)));
    }
    else {
        var cc = 0x10000
            + (c.charCodeAt(0) - 0xD800) * 0x400
            + (c.charCodeAt(1) - 0xDC00);
        return (_fromCC(0xf0 | ((cc >>> 18) & 0x07))
            + _fromCC(0x80 | ((cc >>> 12) & 0x3f))
            + _fromCC(0x80 | ((cc >>> 6) & 0x3f))
            + _fromCC(0x80 | (cc & 0x3f)));
    }
};
const re_utob = /[\uD800-\uDBFF][\uDC00-\uDFFF]|[^\x00-\x7F]/g;
/**
 * @deprecated should have been internal use only.
 * @param {string} src UTF-8 string
 * @returns {string} UTF-16 string
 */
const utob = (u) => u.replace(re_utob, cb_utob);
//
const _encode = _TE
    ? (s) => _fromUint8Array(_TE.encode(s))
    : (s) => _btoa(utob(s));
/**
 * converts a UTF-8-encoded string to a Base64 string.
 * @param {boolean} [urlsafe] if `true` make the result URL-safe
 * @returns {string} Base64 string
 */
const encode = (src, urlsafe = false) => urlsafe
    ? _mkUriSafe(_encode(src))
    : _encode(src);
/**
 * converts a UTF-8-encoded string to URL-safe Base64 RFC4648 §5.
 * @returns {string} Base64 string
 */
const base64_encodeURI = (src) => encode(src, true);
// This trick is found broken https://github.com/dankogai/js-base64/issues/130
// const btou = (src: string) => decodeURIComponent(escape(src));
// reverting good old fationed regexp
const re_btou = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g;
const cb_btou = (cccc) => {
    switch (cccc.length) {
        case 4:
            var cp = ((0x07 & cccc.charCodeAt(0)) << 18)
                | ((0x3f & cccc.charCodeAt(1)) << 12)
                | ((0x3f & cccc.charCodeAt(2)) << 6)
                | (0x3f & cccc.charCodeAt(3)), offset = cp - 0x10000;
            return (_fromCC((offset >>> 10) + 0xD800)
                + _fromCC((offset & 0x3FF) + 0xDC00));
        case 3:
            return _fromCC(((0x0f & cccc.charCodeAt(0)) << 12)
                | ((0x3f & cccc.charCodeAt(1)) << 6)
                | (0x3f & cccc.charCodeAt(2)));
        default:
            return _fromCC(((0x1f & cccc.charCodeAt(0)) << 6)
                | (0x3f & cccc.charCodeAt(1)));
    }
};
/**
 * @deprecated should have been internal use only.
 * @param {string} src UTF-16 string
 * @returns {string} UTF-8 string
 */
const btou = (b) => b.replace(re_btou, cb_btou);
/**
 * polyfill version of `atob`
 */
const atobPolyfill = (asc) => {
    // console.log('polyfilled');
    asc = asc.replace(/\s+/g, '');
    if (!b64re.test(asc))
        throw new TypeError('malformed base64.');
    asc += '=='.slice(2 - (asc.length & 3));
    let u24, r1, r2;
    let binArray = []; // use array to avoid minor gc in loop
    for (let i = 0; i < asc.length;) {
        u24 = b64tab[asc.charAt(i++)] << 18
            | b64tab[asc.charAt(i++)] << 12
            | (r1 = b64tab[asc.charAt(i++)]) << 6
            | (r2 = b64tab[asc.charAt(i++)]);
        if (r1 === 64) {
            binArray.push(_fromCC(u24 >> 16 & 255));
        }
        else if (r2 === 64) {
            binArray.push(_fromCC(u24 >> 16 & 255, u24 >> 8 & 255));
        }
        else {
            binArray.push(_fromCC(u24 >> 16 & 255, u24 >> 8 & 255, u24 & 255));
        }
    }
    return binArray.join('');
};
/**
 * does what `window.atob` of web browsers do.
 * @param {String} asc Base64-encoded string
 * @returns {string} binary string
 */
const _atob = typeof atob === 'function' ? (asc) => atob(_tidyB64(asc))
    : atobPolyfill;
//
const _toUint8Array = typeof Uint8Array.fromBase64 === 'function'
    ? (a) => Uint8Array.fromBase64(a) : (a) => _U8Afrom(_atob(a).split('').map(c => c.charCodeAt(0)));
/**
 * converts a Base64 string to a Uint8Array.
 */
const toUint8Array = (a) => _toUint8Array(_unURI(a));
//
const _decode = _TD
    ? (a) => _TD.decode(_toUint8Array(a))
    : (a) => btou(_atob(a));
const _unURI = (a) => _tidyB64(a.replace(/[-_]/g, (m0) => m0 == '-' ? '+' : '/'));
/**
 * converts a Base64 string to a UTF-8 string.
 * @param {String} src Base64 string.  Both normal and URL-safe are supported
 * @returns {string} UTF-8 string
 */
const decode = (src) => _decode(_unURI(src));
/**
 * check if a value is a valid Base64 string
 * @param {String} src a value to check
  */
const isValid = (src) => {
    if (typeof src !== 'string')
        return false;
    const s = src.replace(/\s+/g, '').replace(/={0,2}$/, '');
    return !/[^\s0-9a-zA-Z\+/]/.test(s) || !/[^\s0-9a-zA-Z\-_]/.test(s);
};
//
const _noEnum = (v) => {
    return {
        value: v, enumerable: false, writable: true, configurable: true
    };
};
/**
 * extend String.prototype with relevant methods
 */
const extendString = function () {
    const _add = (name, body) => Object.defineProperty(String.prototype, name, _noEnum(body));
    _add('fromBase64', function () { return decode(this); });
    _add('toBase64', function (urlsafe) { return encode(this, urlsafe); });
    _add('toBase64URI', function () { return encode(this, true); });
    _add('toBase64URL', function () { return encode(this, true); });
    _add('toUint8Array', function () { return toUint8Array(this); });
};
/**
 * extend Uint8Array.prototype with relevant methods
 */
const extendUint8Array = function () {
    const _add = (name, body) => Object.defineProperty(Uint8Array.prototype, name, _noEnum(body));
    _add('toBase64', function (urlsafe) { return fromUint8Array(this, urlsafe); });
    _add('toBase64URI', function () { return fromUint8Array(this, true); });
    _add('toBase64URL', function () { return fromUint8Array(this, true); });
};
/**
 * extend Builtin prototypes with relevant methods
 */
const extendBuiltins = () => {
    extendString();
    extendUint8Array();
};
const gBase64 = {
    version: version,
    VERSION: VERSION,
    atob: _atob,
    atobPolyfill: atobPolyfill,
    btoa: _btoa,
    btoaPolyfill: btoaPolyfill,
    fromBase64: decode,
    toBase64: encode,
    encode: encode,
    encodeURI: base64_encodeURI,
    encodeURL: base64_encodeURI,
    utob: utob,
    btou: btou,
    decode: decode,
    isValid: isValid,
    fromUint8Array: fromUint8Array,
    toUint8Array: toUint8Array,
    extendString: extendString,
    extendUint8Array: extendUint8Array,
    extendBuiltins: extendBuiltins
};



;// CONCATENATED MODULE: ./src/parsers.ts
// Pure lyric-format parsers — no `tur:*` / `ease` imports in this module so
// it is unit-testable under plain Node (`pnpm test` -> scripts/selftest.ts).
//
// The three grammars (LRC, SRT, WebVTT) are implemented by a small
// hand-written lexer/parser: character scanning only, zero regex literals.
// (Earlier takes, kept in git history for reference: a regex-based port of
// the app's old Rust lrc-nom parser, then delegation to the `lrc-kit` /
// `@plussub/srt-vtt-parser` npm libs.)
//
// Semantics:
//   - LRC: info tags (`[ti:…]`, `[offset:…]`, …) pass through as metadata
//     and are never applied (`[offset:+500]` stays a verbatim string).
//     Multi-timestamp lines expand to one entry per timestamp; the first
//     tag decides the line kind, one info tag per line. Enhanced-LRC word
//     timings (`<mm:ss.xx> word`, plus the Foobar2000 `[mm:ss.xx] word`
//     shape) are stripped from the text. `[:]` is a comment; unknown tags
//     and untagged lines are skipped (lenient). Fractions scale by digit
//     count (`.5` = `.50` = `.500` = 500 ms, longer runs truncate). No
//     timed lines -> null ("not mine").
//   - SRT/WebVTT: cue start times; a parseable cue end becomes the
//     per-line `durationMs`. VTT NOTE/STYLE/REGION blocks are skipped, as
//     are optional cue id lines (SRT index / VTT identifier). Multi-line
//     cue text joins with a space; inline markup and `&nbsp;` are
//     stripped. Timestamps tolerate 2 or 3 fields, the SRT comma or the
//     VTT dot, and 1-3 fraction digits. No cues -> null.
// ---------------------------------------------------------------------------
// Contract types (host ↔ plugin)
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Character utilities — the lexer toolkit (regex-free by design)
// ---------------------------------------------------------------------------
function isDigits(s) {
    if (s === "") return false;
    for(let i = 0; i < s.length; i += 1){
        const c = s.charCodeAt(i);
        if (c < 0x30 || c > 0x39) return false;
    }
    return true;
}
/** Split on `\n`, `\r\n` or a lone `\r` (every line terminator in the wild). */ function splitLines(text) {
    const out = [];
    for (const chunk of text.split("\n")){
        if (chunk.includes("\r")) {
            for (const piece of chunk.split("\r"))out.push(piece);
        } else {
            out.push(chunk);
        }
    }
    return out;
}
/** Drop a leading UTF-8 BOM — it would poison LRC's first-line tags and
 *  defeat the `WEBVTT` header sniffing. */ function stripBom(text) {
    return text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
}
/** Collapse whitespace runs to single spaces and trim both ends. */ function collapseSpaces(text) {
    let out = "";
    let pending = false;
    for (const c of text){
        if (c === " " || c === "\t" || c === "\n" || c === "\r") {
            pending = out !== "";
        } else {
            out += pending ? " " + c : c;
            pending = false;
        }
    }
    return out;
}
/**
 * Parse one `[hh:]mm:ss[,.]frac` timestamp into whole milliseconds.
 * Accepts the SRT comma and the VTT/LRC dot, 2 or 3 fields, and scales the
 * fraction by its digit count. Returns null when not well-formed — callers
 * use that both to reject and to classify (`parseLrc` distinguishes time
 * tags from info tags this way).
 */ function parseTimestamp(str) {
    const parts = str.trim().split(":");
    if (parts.length < 2 || parts.length > 3) return null;
    const head = parts.slice(0, parts.length - 1); // [hh?,] mm
    const tail = parts[parts.length - 1]; // ss[,.]frac
    const sep = Math.max(tail.lastIndexOf(","), tail.lastIndexOf("."));
    if (sep < 0) return null;
    const sec = tail.slice(0, sep);
    const frac = tail.slice(sep + 1);
    if (!isDigits(sec) || !isDigits(frac)) return null;
    for (const p of head){
        if (!isDigits(p)) return null;
    }
    let ms = Number(sec) * 1000;
    const f = frac.slice(0, 3);
    ms += Number(f) * (f.length === 1 ? 100 : f.length === 2 ? 10 : 1);
    ms += Number(head[head.length - 1]) * 60000;
    if (head.length === 2) ms += Number(head[0]) * 3600000;
    return ms;
}
// ---------------------------------------------------------------------------
// LRC
// ---------------------------------------------------------------------------
// LRC info-tag key -> contract metadata key (`length` / `offset` pass
// through verbatim — the host keeps them as strings, exactly like the old
// Rust parser did).
const LRC_META_KEYS = {
    ar: "artist",
    al: "album",
    ti: "title",
    au: "lyricist",
    by: "author"
};
/** Lexer: consecutive `[inner]` groups from the start of a line. */ function takeLeadingTags(line) {
    const tags = [];
    let rest = line;
    while(rest.startsWith("[")){
        const close = rest.indexOf("]");
        if (close < 0) break; // unclosed bracket — not a tag
        tags.push(rest.slice(1, close));
        rest = rest.slice(close + 1);
    }
    return {
        tags,
        rest
    };
}
/**
 * Strip enhanced-LRC word timings from line text: the A2 extension
 * `<mm:ss.xx> word` and the Foobar2000 `[mm:ss.xx] word` shape. Bracket
 * groups whose content is not a timestamp pass through verbatim.
 */ function stripWordTags(text) {
    let out = "";
    let i = 0;
    while(i < text.length){
        const c = text[i];
        if (c === "<" || c === "[") {
            const close = c === "<" ? ">" : "]";
            const end = text.indexOf(close, i + 1);
            if (end > i + 1 && parseTimestamp(text.slice(i + 1, end)) !== null) {
                i = end + 1;
                continue;
            }
        }
        out += c;
        i += 1;
    }
    return out;
}
function parseLrc(text) {
    const meta = {};
    const lines = [];
    for (const rawLine of splitLines(stripBom(text))){
        const line = rawLine.trim();
        if (line === "") continue;
        const { tags, rest } = takeLeadingTags(line);
        if (tags.length === 0) continue; // untagged line — lenient skip
        const first = tags[0];
        if (parseTimestamp(first) !== null) {
            // Timed line: every leading tag is a timestamp candidate, each
            // seeding one entry that carries the word-tag-stripped text.
            const lineText = stripWordTags(rest).trim();
            if (lineText === "") continue;
            for (const tag of tags){
                const ms = parseTimestamp(tag);
                if (ms !== null) lines.push({
                    timeMs: ms,
                    text: lineText
                });
            }
            continue;
        }
        // Info line: `[key:value]` — the first tag decides, one per line.
        const colon = first.indexOf(":");
        if (colon < 0) continue; // e.g. `[00]` — not valid info either
        const key = first.slice(0, colon).trim();
        const value = first.slice(colon + 1).trim();
        if (key === "" && value === "") continue; // `[:]` comment
        const mapped = LRC_META_KEYS[key];
        if (mapped) meta[mapped] = value;
        else if (key === "length" || key === "offset") meta[key] = value;
    // Unrecognized tag — ignored.
    }
    if (lines.length === 0) return null; // nothing timed parsed — "not mine"
    lines.sort((a, b)=>a.timeMs - b.timeMs);
    const result = {
        lines
    };
    if (Object.keys(meta).length > 0) result.metadata = meta;
    return result;
}
// ---------------------------------------------------------------------------
// SRT / WebVTT
// ---------------------------------------------------------------------------
function isArrowLine(line) {
    return line.includes("-->");
}
/** First whitespace-delimited token — the cue-end timestamp; VTT cue
 *  settings (`align:start line:90%`) and SRT legacy coordinates follow. */ function firstToken(s) {
    const t = s.trimStart();
    let end = t.length;
    for (const ws of [
        " ",
        "\t"
    ]){
        const k = t.indexOf(ws);
        if (k >= 0 && k < end) end = k;
    }
    return t.slice(0, end);
}
/** `from --> to [settings]` -> `{ from, to }`; `to` is null when the end
 *  timestamp is unparseable, `from` null rejects the whole cue. */ function parseTimingLine(line) {
    const arrow = line.indexOf("-->");
    const from = parseTimestamp(line.slice(0, arrow));
    if (from === null) return null;
    const to = parseTimestamp(firstToken(line.slice(arrow + 3)));
    return {
        from,
        to
    };
}
function isVttBlockKeyword(line) {
    const t = line.trim().toUpperCase();
    return t === "NOTE" || t === "STYLE" || t === "REGION" || t.startsWith("NOTE ") || t.startsWith("STYLE ") || t.startsWith("REGION ");
}
/** Strip VTT/SRT inline markup (`<i>`, `<b>`, `<c.className>`, `<v Speaker>`…).
 *  A `<` with no closing `>` (e.g. the lyric `love <3`) passes through. */ function stripAngleTags(text) {
    let out = "";
    let i = 0;
    while(i < text.length){
        const c = text[i];
        if (c === "<") {
            const end = text.indexOf(">", i + 1);
            if (end > i + 1) {
                i = end + 1;
                continue;
            }
        }
        out += c;
        i += 1;
    }
    return out;
}
function stripCueTags(text) {
    // `&nbsp;` -> plain space first, so entity spaces collapse with the rest.
    return collapseSpaces(stripAngleTags(text.split("&nbsp;").join(" ")));
}
function parseSubtitle(text) {
    const rows = splitLines(stripBom(text));
    const isVtt = rows.length > 0 && rows[0].startsWith("WEBVTT");
    const cues = [];
    let i = 0;
    if (isVtt) {
        // Skip the header block (`WEBVTT` line + optional metadata lines)
        // up to the first blank line.
        while(i < rows.length && rows[i].trim() !== "")i += 1;
    }
    while(i < rows.length){
        const line = rows[i];
        if (line.trim() === "") {
            i += 1;
            continue;
        }
        if (isVtt && isVttBlockKeyword(line)) {
            i += 1;
            while(i < rows.length && rows[i].trim() !== "")i += 1;
            continue;
        }
        // A cue starts at its timing line; an optional id line (SRT index /
        // VTT identifier) may precede it. Cue text never contains `-->`,
        // so the arrow is a reliable anchor.
        let timing = null;
        if (isArrowLine(line)) {
            timing = parseTimingLine(line);
        } else if (i + 1 < rows.length && isArrowLine(rows[i + 1])) {
            timing = parseTimingLine(rows[i + 1]);
            i += 1;
        }
        if (timing === null) {
            i += 1; // resync: scan forward for the next cue
            continue;
        }
        i += 1;
        const textRows = [];
        while(i < rows.length && rows[i].trim() !== "" && !isArrowLine(rows[i])){
            textRows.push(rows[i]);
            i += 1;
        }
        cues.push({
            from: timing.from,
            to: timing.to,
            text: textRows.join(" ")
        });
    }
    const lines = [];
    for (const cue of cues){
        const lineText = stripCueTags(cue.text);
        if (lineText === "") continue;
        const entry = {
            timeMs: cue.from,
            text: lineText
        };
        // Cue end -> per-line duration (optional in the contract; the host
        // currently derives it from the next line's start and ignores ours,
        // but it is free to send and correct for sparse subtitles).
        if (cue.to !== null && cue.to > cue.from) entry.durationMs = cue.to - cue.from;
        lines.push(entry);
    }
    if (lines.length === 0) return null;
    lines.sort((a, b)=>a.timeMs - b.timeMs);
    return {
        lines
    };
}

;// CONCATENATED MODULE: ./src/backend.ts
// Lyric-format parsers — a headless JS plugin serving the app's entire
// lyric parsing (there is no built-in Rust parser). One `lyric:parse`
// host-RPC handler serves every `contributions.lyricParsers` entry of
// this manifest; `parserId` (the contribution id) rides the payload and
// routes to the format implementation:
//
// hostRpc — the Rust host invokes this (services/lyrics/dispatch.rs):
//   - lyric:parse  { pluginId, parserId, fileName, size, contentBase64 }
//     -> { lines: [{ timeMs, durationMs?, text }], metadata? } | null
//     `null` = "not mine / unrecognized content" — the host falls through
//     to the next parser claiming the extension.
//
// Formats (implementations in ./parsers.ts — a hand-written, regex-free
// lexer/parser, no parsing dependencies):
//   - lrc      LRC (metadata tags pass through unapplied; enhanced-LRC
//              word timings stripped from the text)
//   - subtitle SRT + WebVTT (cue start times, plus per-line durationMs
//              from the cue end)
//
// All results are pre-sorted by time; the host clamps, rounds, caps and
// sorts again (defensive on both sides).
// TextEncoder/TextDecoder polyfill FIRST — npm deps below may rely on them.





const PARSERS = {
    lrc: parseLrc,
    subtitle: parseSubtitle
};
function backend_start() {
    hostRpc.registerHandler("lyric:parse", (args)=>{
        const parser = PARSERS[args.parserId];
        if (!parser) return null;
        const bytes = gBase64.toUint8Array(args.contentBase64);
        const text = new TextDecoder().decode(bytes);
        // A parse error thrown here rejects the RPC call host-side (logged,
        // next parser tried); `null` means "unrecognized content" with the
        // same fall-through.
        const result = parser(text);
        return result;
    });
}

var __webpack_exports__start = __webpack_exports__.n;
export { __webpack_exports__start as start };

//# sourceMappingURL=backend.js.map